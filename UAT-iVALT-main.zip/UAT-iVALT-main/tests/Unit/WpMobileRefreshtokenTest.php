<?php

namespace Tests\Unit;

use Mockery;
use Tests\TestCase;

class WpMobileRefreshtokenTest extends TestCase
{
    protected $userMock;

    protected $userDeviceTokenMock;

    /**
     * Set up the test environment, disable middleware, and set up mocks.
     */
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->setupMocks();
    }

    /**
     * Tear down the test environment and close mockery.
     */
    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    /**
     * Set up the necessary mocks for the tests.
     */
    private function setupMocks(): void
    {
        $this->userMock = Mockery::mock('alias:App\Models\User');
        $this->userDeviceTokenMock = Mockery::mock('alias:App\Models\UserDeviceTokens');
    }

    /**
     * Test the response when required parameters are missing.
     */
    public function test_missing_required_parameters()
    {
        $response = $this->postJson('api/wp/mobile/refresh/token', []);

        $response->assertStatus(400)
            ->assertJson([
                'error' => [
                    'title'  => 'Missing Required Parameters.',
                    'status' => 400,
                ],
            ]);
    }

    /**
     * Test the response when an invalid mobile number is provided.
     */
    public function test_invalid_mobile_number()
    {
        $this->setupUserMock('6781234590', null);

        $response = $this->postJson('api/wp/mobile/refresh/token', [
            'mobile' => '6781234590',
            'token'  => 'c2mBqUk9SI6MouA-AMbRlF:APA91bFGMcrPP9bdVNoituELtZaf22yuQDktGf4QGYMYeOb3ijmPt2mlKDETI-dpBdKb_1SM-x72IfYC8B4QkMIn8rOAeaiTPREzwew4XB__-1t2iFqjWjycDd1k_Z-s6KTWjyMBRn8Z',
            'imei'   => '1d5b84a0a20caec8',
        ]);

        $response->assertStatus(404)
            ->assertJson([
                'error' => [
                    'title'  => 'Not Found',
                    'status' => 404,
                    'detail' => 'The mobile number provided (6781234590) is not registered with iValt.',
                ],
            ]);
    }

    /**
     * Test the response when a valid mobile number is provided but with no matching IMEI.
     */
    public function test_valid_mobile_number_with_no_matching_imei()
    {
        $this->setupUserMock('1234567890', collect(['id' => 1]));
        $this->setupUserDeviceTokenMock('ghjghjggi', null);

        $response = $this->postJson('api/wp/mobile/refresh/token', [
            'mobile' => '1234567890',
            'token'  => 'valid_token',
            'imei'   => 'ghjghjggi',
        ]);

        $response->assertStatus(404)
            ->assertJson([
                'error' => [
                    'title'  => 'Not Found',
                    'status' => 404,
                    'detail' => 'Provided imei is not valid.',
                ],
            ]);
    }

    /**
     * Test the response when both a valid mobile number and IMEI are provided.
     */
    public function test_valid_mobile_number_and_imei()
    {
        $this->setupUserMock('7837582588', collect(['id' => 1]));
        $this->setupUserDeviceTokenMock('1d5b84a0a20caec8', collect(['id' => 1]));

        $this->userDeviceTokenMock->shouldReceive('update')->once()->andReturn(true);
        $this->userMock->shouldReceive('update')
            ->with(['device_token' => 'abcdefghijklmnopqrstuvwxyz', 'imei' => '1d5b84a0a20caec8'])
            ->once()
            ->andReturn(true);

        $response = $this->postJson('api/wp/mobile/refresh/token', [
            'mobile' => '7837582588',
            'token'  => 'abcdefghijklmnopqrstuvwxyz',
            'imei'   => '1d5b84a0a20caec8',
        ]);

        $response->assertStatus(200)
            ->assertJson([
                'data' => [
                    'message' => 'Device token updated successfully.',
                ],
            ]);
    }

    /**
     * Helper method to set up user mock.
     */
    private function setupUserMock(string $mobile, $returnValue): void
    {
        $this->userMock->shouldReceive('where')->with('mobile', $mobile)->andReturnSelf();
        $this->userMock->shouldReceive('first')->andReturn($returnValue);
    }

    /**
     * Helper method to set up user device token mock.
     */
    private function setupUserDeviceTokenMock(string $imei, $returnValue): void
    {
        $this->userDeviceTokenMock->shouldReceive('where')
            ->with('imei', '=', $imei)
            ->andReturnSelf();
        $this->userDeviceTokenMock->shouldReceive('first')->once()->andReturn($returnValue);
    }
}
