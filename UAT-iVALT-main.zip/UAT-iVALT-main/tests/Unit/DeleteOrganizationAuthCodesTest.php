<?php

namespace Tests\Unit;

use Mockery;
use Tests\TestCase;

class DeleteOrganizationAuthCodesTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function test_organization_not_found()
    {
        $orgId = 1;
        $authCodeId = 1;

        // Mock Organization model
        $orgModelMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $orgModelMock->shouldReceive('find')->with($orgId)->andReturn(null);

        $response = $this->json('DELETE', "/api/organization/{$orgId}/delete/auth-code/{$authCodeId}");

        $response->assertStatus(404)->assertJson([
            'error' => [
                'title'  => 'Not Found',
                'detail' => 'Organization not found',
            ],
        ]);
    }

    public function test_auth_code_not_found()
    {
        $orgId = 1;
        $authCodeId = 1;

        // Mock Organization model
        $orgModelMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $orgModelMock->shouldReceive('find')->with($orgId)->andReturn($orgModelMock);

        // Mock authCodes relationship method
        $authCodeMock = Mockery::mock('alias:App\Models\Organization\OrganizationAuthCode');
        $authCodeMock->shouldReceive('find')->with($authCodeId)->andReturn(null);

        $orgModelMock->shouldReceive('authCodes')->andReturn($authCodeMock);

        $response = $this->json('DELETE', "/api/organization/{$orgId}/delete/auth-code/{$authCodeId}");

        $response->assertStatus(404)->assertJson([
            'error' => [
                'title'  => 'Not Found',
                'detail' => 'Org Auth Code not found.',
            ],
        ]);
    }

    public function test_successful_auth_code_deletion()
    {
        $orgId = 1;
        $authCodeId = 1;

        // Mock Organization model
        $orgModelMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $orgModelMock->shouldReceive('find')->with($orgId)->andReturn($orgModelMock);

        // Mock authCodes relationship method
        $authCodeMock = Mockery::mock('alias:App\Models\Organization\OrganizationAuthCode');
        $authCodeMock->shouldReceive('find')->with($authCodeId)->andReturn($authCodeMock);
        $authCodeMock->shouldReceive('delete')->andReturn(true);
        $authCodeMock->id = $authCodeId;

        $orgModelMock->shouldReceive('authCodes')->andReturn($authCodeMock);

        $response = $this->json('DELETE', "/api/organization/{$orgId}/delete/auth-code/{$authCodeId}");

        $response->assertStatus(200)->assertJson([
            'data' => [
                'status'  => true,
                'message' => 'Org Auth Code deleted successfully.',
            ],

        ]);
    }
}
