<?php

namespace Tests\Unit;

use App\Models\User;
use Mockery;
use Tests\TestCase;

class DeleteProfileTest extends TestCase
{
    public function test_missing_required_parameters()
    {
        $response = $this->json('POST', 'api/delete-profile', [
            'country_code' => '+91',
        ]);

        $response->assertStatus(400)
            ->assertJson([
                'error' => [
                    'title'  => 'Missing Required Parameters',
                    'status' => 400,
                ],
            ]);
    }

    public function test_mobile_number_not_found()
    {
        $this->userMock->shouldReceive('where')->andReturnSelf();
        $this->userMock->shouldReceive('exists')->andReturn(false);

        $response = $this->json('POST', 'api/delete-profile', [
            'country_code' => '1',
            'mobile'       => '1234567890',
        ]);

        $response->assertStatus(404)
            ->assertJson([
                'error' => [
                    'title'  => 'Not Found',
                    'status' => 404,
                    'detail' => 'The mobile number provided (1234567890) was not found.',
                ],
            ]);
    }

    public function test_successful_profile_deletion()
    {
        $this->userMock->shouldReceive('where')->andReturnSelf();
        $this->userMock->shouldReceive('exists')->andReturn(true);
        $this->userMock->shouldReceive('delete')->andReturn(true);

        $response = $this->json('POST', 'api/delete-profile', [
            'country_code' => '+91',
            'mobile'       => '6283974746',
        ]);

        $response->assertStatus(200)
            ->assertJson([
                'data' => [
                    'status'  => true,
                    'message' => 'Profile successfully deleted.',
                ],
            ]);
    }

    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
        // Mock the User model
        $this->userMock = Mockery::mock('overload:'.User::class);
        $this->app->instance(User::class, $this->userMock);
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }
}
