<?php

namespace Tests\Unit;

use Mockery;
use Tests\TestCase;

class ValidateGlobalRESTAuthTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function test_mobile_not_found()
    {
        // Arrange: Prepare the request data with valid 'mobile' and 'auth_token'
        $mobile = '1234567890';
        $authToken = 'sample_auth_token';
        $requestParams = ['mobile' => $mobile, 'auth_token' => $authToken];
        $webAuth = Mockery::mock('alias:App\Models\WebAuth');

        // Mock WebAuth::where()->first() to return null
        $webAuth->shouldReceive('where')
            ->with(['mobile' => $mobile])
            ->andReturnSelf();
        $webAuth->shouldReceive('first')
            ->once()
            ->andReturn(null);

        // Act: Perform the API call
        $response = $this->json('POST', '/api/validate/global/rest/auth', $requestParams);

        // Assert: Check that the response indicates the mobile number was not found
        $response->assertStatus(404)
            ->assertJson([
                'error' => [
                    'status' => 404,
                    'detail' => "The mobile number provided ($mobile) was not found.",
                ],
            ]);
    }

    public function test_unprocessable_request()
    {
        // Arrange: Prepare the request data with valid 'mobile' and 'auth_token'
        $mobile = '1234567890';
        $authToken = 'sample_auth_token';
        $requestParams = ['mobile' => $mobile, 'auth_token' => $authToken];

        // Mock WebAuth::where()->first() to return a mock WebAuth model
        $webAuthMock = Mockery::mock('alias:App\Models\WebAuth');
        $webAuthMock->login_status = 0;

        $webAuthMock->shouldReceive('where')
            ->with(['mobile' => $mobile])
            ->andReturnSelf();
        $webAuthMock->shouldReceive('first')
            ->once()
            ->andReturn($webAuthMock);
        // Mock WebAuth::delete()
        $webAuthMock->shouldReceive('delete')
            ->once();

        // Act: Perform the API call
        $response = $this->json('POST', '/api/validate/global/rest/auth', $requestParams);

        // Assert: Check that the response indicates an unprocessable request
        $response->assertStatus(422)
            ->assertJson([
                'error' => [
                    'status' => 422,
                    'detail' => "The mobile number ($mobile) was not in a valid state. Please initiate the Biometric Auth Request again before checking results.",
                ],
            ]);
    }

    public function test_successful_authentication()
    {
        // Arrange: Prepare the request data with valid 'mobile' and 'auth_token'
        $mobile = '1234567890';
        $authToken = 'sample_auth_token';
        $requestParams = ['mobile' => $mobile, 'auth_token' => $authToken];

        // Mock WebAuth::where()->first() to return a mock WebAuth model
        $webAuthMock = Mockery::mock('alias:App\Models\WebAuth');
        $webAuthMock->login_status = 1;

        $webAuthMock->shouldReceive('where')
            ->with(['mobile' => $mobile])
            ->andReturnSelf();
        $webAuthMock->shouldReceive('first')
            ->once()
            ->andReturn($webAuthMock);
        // Mock WebAuth::delete()
        $webAuthMock->shouldReceive('delete')
            ->once();

        // Mock the route for redirection
        $this->app['router']->getRoutes()->refreshNameLookups();
        $this->app['router']->get('api/merchant/redirect', ['as' => 'api.merchant.redirect', function () {
            return response()->json(['redirect' => true]);
        }]);

        // Act: Perform the API call
        $response = $this->json('POST', '/api/validate/global/rest/auth', $requestParams);

        // Assert: Check that the response indicates successful authentication
        $response->assertStatus(200)
            ->assertJson([
                'data' => [
                    'status'  => 'true',
                    'message' => 'Biometric Authentication successfully done.',
                ],
            ]);
    }
}
