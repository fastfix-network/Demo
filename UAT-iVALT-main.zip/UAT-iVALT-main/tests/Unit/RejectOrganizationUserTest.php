<?php

namespace Tests\Unit;

use Mockery;
use Tests\TestCase;

class RejectOrganizationUserTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function test_organization_not_found()
    {
        $orgId = 1;
        $userId = 1;

        // Mock Organization model
        $orgModelMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $orgModelMock->shouldReceive('find')->with($orgId)->andReturn(null);

        $response = $this->json('POST', "/api/organization/{$orgId}/user/{$userId}/reject");

        $response->assertStatus(404)->assertJson([
            'error' => [
                'status' => 404,
                'detail' => 'Organization not found',
            ],
        ]);
    }

    public function test_user_not_found_in_pending_list()
    {
        $orgId = 1;
        $userId = 1;

        // Mock Organization model
        $orgModelMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $orgModelMock->shouldReceive('find')->with($orgId)->andReturn($orgModelMock);

        // Mock pendingUsers() relationship
        $pendingUsersMock = Mockery::mock();
        $orgModelMock->shouldReceive('pendingUsers')->andReturn($pendingUsersMock);
        $pendingUsersMock->shouldReceive('find')->with($userId)->andReturn(null);

        $response = $this->json('POST', "/api/organization/{$orgId}/user/{$userId}/reject");

        $response->assertStatus(404)->assertJson([
            'error' => [
                'status' => 404,
                'detail' => 'User not found',
            ],
        ]);
    }

    public function test_user_rejected_successfully()
    {
        $orgId = 1;
        $userId = 1;

        // Mock Organization model
        $orgModelMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $orgModelMock->shouldReceive('find')->with($orgId)->andReturn($orgModelMock);

        // Mock pendingUsers() relationship
        $pendingUsersMock = Mockery::mock();
        $orgModelMock->shouldReceive('pendingUsers')->andReturn($pendingUsersMock);

        // Mock the user returned by the pendingUsers() relationship
        $userMock = Mockery::mock('alias:App\Models\User');
        $userMock->id = $userId;

        // Ensure the find method on pendingUsers returns the user mock
        $pendingUsersMock->shouldReceive('find')->with($userId)->andReturn($userMock);

        // Correctly mock the updateExistingPivot method to expect the user ID
        $pendingUsersMock->shouldReceive('updateExistingPivot')->with($userId, ['is_active' => 1], false)->andReturn(true);

        // Perform the request
        $response = $this->json('POST', "/api/organization/{$orgId}/user/{$userId}/reject");

        // Assert the response
        $response->assertStatus(200)->assertJson([
            'data' => [
                'status'  => true,
                'message' => 'User rejected successfully.',
            ],
        ]);
    }
}
