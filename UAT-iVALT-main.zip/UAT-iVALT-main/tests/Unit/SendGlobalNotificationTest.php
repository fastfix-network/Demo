<?php

namespace Tests\Unit;

use App\Http\Controllers\NotificationController;
use App\Models\User;
use App\Models\WebAuth;
use Mockery;
use Tests\TestCase;

class SendGlobalNotificationTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    // 1. Missing Required Parameters Test Case
    public function test_Missing_Required_Parameters()
    {
        $data = []; // Empty data to simulate missing parameters

        $response = $this->json('POST', '/api/send/notification', $data);

        // Assert
        $response->assertStatus(400)
            ->assertJson([
                'error' => [
                    'status' => 400,
                    'title'  => 'Missing Required Parameters',
                ],
            ]);
    }

    public function test_User_Found_And_Notification_Sent_Successfully()
    {
        $data = [
            'mobile'      => '919876543210',
            'requestFrom' => 'TestApp',
        ];

        // Mock the User model
        $userMock = Mockery::mock('alias:App\Models\User');
        $userMock->device_token = 'some_device_token';
        $userMock->user_id = 1;

        // Mock the 'with', 'where', and 'first' methods for User model
        $userMock->shouldReceive('with')
            ->once()
            ->with('device_tokens')
            ->andReturnSelf();
        $userMock->shouldReceive('where')
            ->once()
            ->with(['mobile_with_country_code' => $data['mobile']])
            ->andReturnSelf();
        $userMock->shouldReceive('first')
            ->once()
            ->andReturn($userMock);

        // Mock the WebAuth model
        $webAuthMock = Mockery::mock('alias:App\Models\WebAuth');
        $webAuthMock->shouldReceive('where')
            ->once()
            ->andReturnSelf();
        $webAuthMock->shouldReceive('delete')
            ->once()
            ->andReturn(true);

        // Mock the Firebase Messaging
        $messagingMock = Mockery::mock('overload:Kreait\Firebase\Messaging');
        $cloudMessageMock = Mockery::mock('overload:Kreait\Firebase\Messaging\CloudMessage');
        $notificationMock = Mockery::mock('overload:Kreait\Firebase\Messaging\Notification');
        $notificationMock->shouldReceive('create')
            ->once()
            ->with('iVALT', 'Notification message')
            ->andReturnSelf();
        $cloudMessageMock->shouldReceive('withTarget')
            ->once()
            ->andReturnSelf();
        $cloudMessageMock->shouldReceive('withNotification')
            ->once()
            ->with($notificationMock)
            ->andReturnSelf();
        $messagingMock->shouldReceive('send')
            ->once()
            ->with($cloudMessageMock)
            ->andReturn(['status' => 'success']);

        // Mock the Firebase Facade to return the mocked messaging
        $firebaseMock = Mockery::mock('alias:Kreait\Laravel\Firebase\Facades\Firebase');
        $firebaseMock->shouldReceive('messaging')
            ->once()
            ->andReturn($messagingMock);

        // Mock the NotificationController
        $notificationControllerMock = Mockery::mock(NotificationController::class);
        $notificationControllerMock->shouldReceive('sendNotificationForAuth')
            ->once()
            ->with($userMock, 'iVALT', $data['mobile'], $data['requestFrom'])
            ->andReturn(response()->json(['message' => 'Notification sent successfully'], 200));

        // Bind the mocked NotificationController and Firebase service to the app
        $this->app->instance(NotificationController::class, $notificationControllerMock);
        $this->app->instance('Kreait\Laravel\Firebase\Facades\Firebase', $firebaseMock);

        // Act: Make the API request
        $response = $this->json('POST', '/api/send/notification', $data);

        // Assert: Verify the response
        $response->assertStatus(200)
            ->assertJson([
                'message' => 'Notification sent successfully',
            ]);
    }

    public function test_User_Not_Found()
    {
        $data = [
            'mobile'      => '919876543210',
            'requestFrom' => 'TestApp',
        ];

        // Mock the User model
        $userMock = Mockery::mock('alias:App\Models\User');
        $userMock->shouldReceive('with->where->first')
            ->andReturn(null); // Simulate user not found

        // Act
        $response = $this->json('POST', '/api/send/notification', $data);

        // Assert
        $response->assertStatus(404)
            ->assertJson([
                'error' => [
                    'status' => 404,
                    'title'  => 'Not Found',
                ],
            ]);
    }

    public function test_Notification_Sending_Failed()
    {
        $data = [
            'mobile'      => '919876543210',
            'requestFrom' => 'TestApp',
        ];

        // Create a mock for the User model
        $userMock = Mockery::mock('alias:App\Models\User');
        $userMock->device_token = 'some_device_token';
        $userMock->user_id = 1;

        // Mock the User query with 'with' and 'where' chained methods
        $userMock->shouldReceive('with')->andReturnSelf();
        $userMock->shouldReceive('where')->with(['mobile_with_country_code' => $data['mobile']])->andReturnSelf();
        $userMock->shouldReceive('first')->andReturn($userMock);

        // Mock the WebAuth model to delete old records without any database interaction
        $webAuthMock = Mockery::mock('alias:App\Models\WebAuth');
        $webAuthMock->shouldReceive('where')
            ->with('mobile_with_country_code', $data['mobile'])
            ->andReturnSelf(); // Return the mock for chaining
        $webAuthMock->shouldReceive('delete')->andReturn(true); // Prevent actual database interaction

        // Mock the NotificationController, but simulate failure in sending notification
        $notificationMock = Mockery::mock(NotificationController::class);
        $notificationMock->shouldReceive('sendNotificationForAuth')
            ->with($userMock, 'iVALT', $data['mobile'], $data['requestFrom'])
            ->andThrow(new \Exception('Failed to send notification')); // Simulate failure

        $this->app->instance(NotificationController::class, $notificationMock);

        // Act
        $response = $this->json('POST', '/api/send/notification', $data);

        // Assert that the notification failed and a 500 status is returned
        $response->assertStatus(500)
            ->assertJson([
                'error' => [
                    'status' => 500,
                    'title'  => 'Failed to send Biometric Auth Request.',
                ],
            ]);
    }
}
