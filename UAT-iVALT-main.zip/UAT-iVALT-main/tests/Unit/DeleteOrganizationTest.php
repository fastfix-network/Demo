<?php

use App\Models\Organization\Organization;
use Tests\TestCase;

class DeleteOrganizationTest extends TestCase
{
    public function testDeleteOrganizationSuccess()
    {
        // Mock the organization model
        $organizationMock = Mockery::mock('alias:App\Models\Organization\Organization');

        // Mock the related models (relation results)
        $usersRelationMock = Mockery::mock();
        $pendingUsersRelationMock = Mockery::mock();
        $geoGeoFencesRelationMock = Mockery::mock();
        $organizationMock->shouldReceive('find')
            ->with(1)
            ->andReturn($organizationMock);

        // Setup the mock behavior for users() method
        $organizationMock->shouldReceive('users')
            ->andReturn($usersRelationMock);
        $usersRelationMock->shouldReceive('count')
            ->andReturn(0);
        $usersRelationMock->shouldReceive('detach')
            ->andReturn(true);
        $usersRelationMock->shouldReceive('delete')
            ->andReturn(true);

        // Setup the mock behavior for pendingUsers() method
        $organizationMock->shouldReceive('pendingUsers')
            ->andReturn($pendingUsersRelationMock);
        $pendingUsersRelationMock->shouldReceive('count')
            ->andReturn(0);
        $pendingUsersRelationMock->shouldReceive('detach')
            ->andReturn(true);
        $pendingUsersRelationMock->shouldReceive('delete')
            ->andReturn(true);

        // Setup the mock behavior for geoGeoFences() method
        $organizationMock->shouldReceive('geoGeoFences')
            ->andReturn($geoGeoFencesRelationMock);
        $geoGeoFencesRelationMock->shouldReceive('delete')
            ->andReturn(true);

        // Mock the delete method on the Organization model
        $organizationMock->shouldReceive('delete')
            ->andReturn(true);

        // Bind the mock instance in the container
        $this->app->instance(Organization::class, $organizationMock);

        // Act
        $response = $this->json('DELETE', '/api/organization/delete/1');

        // Assert
        $response->assertStatus(200)
            ->assertJson([
                'data' => [
                    'status'  => true,
                    'message' => 'Organization deleted successfully.',
                ],
            ]);
    }

    public function testDeleteOrganizationFailure()
    {
        // Mock the organization model
        $organizationMock = Mockery::mock('alias:App\Models\Organization\Organization');

        // Mock the related models (relation results)
        $usersRelationMock = Mockery::mock();
        $pendingUsersRelationMock = Mockery::mock();
        $geoGeoFencesRelationMock = Mockery::mock();

        $organizationMock->shouldReceive('find')
            ->with(1)
            ->andReturn($organizationMock);

        // Setup the mock behavior for users() method
        $organizationMock->shouldReceive('users')
            ->andReturn($usersRelationMock);
        $usersRelationMock->shouldReceive('count')
            ->andReturn(0);
        $usersRelationMock->shouldReceive('detach')
            ->andReturn(true);
        $usersRelationMock->shouldReceive('delete')
            ->andReturn(true);

        // Setup the mock behavior for pendingUsers() method
        $organizationMock->shouldReceive('pendingUsers')
            ->andReturn($pendingUsersRelationMock);
        $pendingUsersRelationMock->shouldReceive('count')
            ->andReturn(0);
        $pendingUsersRelationMock->shouldReceive('detach')
            ->andReturn(true);
        $pendingUsersRelationMock->shouldReceive('delete')
            ->andReturn(true);

        // Setup the mock behavior for geoGeoFences() method
        $organizationMock->shouldReceive('geoGeoFences')
            ->andReturn($geoGeoFencesRelationMock);
        $geoGeoFencesRelationMock->shouldReceive('delete')
            ->andReturn(true);

        // Mock the delete method on the Organization model
        $organizationMock->shouldReceive('delete')
            ->andReturn(false);

        // Bind the mock instance in the container
        $this->app->instance(Organization::class, $organizationMock);

        $response = $this->json('DELETE', '/api/organization/delete/1');

        // Assert
        $response->assertStatus(404)
            ->assertJson([
                'error' => [
                    'status' => 404,
                    'title'  => 'Operation failed',
                    'detail' => 'Something went wrong!',
                ],
            ]);
    }

    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }
}
