<?php

namespace Tests\Unit;

use Mockery;
use Tests\TestCase;

class GetSingleOrganizationGeoFencesTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function test_organization_not_found()
    {
        $orgModelMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $orgId = 1;
        $orgModelMock->shouldReceive('find')->with($orgId)->andReturn(null);

        $response = $this->json('GET', '/api/organization/'.$orgId.'/geo-fence/1');
        $response->assertStatus(404)->assertJson([
            'error' => [
                'title'  => 'Not Found',
                'detail' => 'Organization not found',
            ],
        ]);
    }

    public function test_geo_fence_not_found()
    {
        $orgModelMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $geoFencesMock = Mockery::mock();
        $orgId = 1;
        $geoFencesId = 100;
        $orgModelMock->name = 'Test ORG';

        $orgModelMock->shouldReceive('find')->with($orgId)->andReturn($orgModelMock);
        $orgModelMock->shouldReceive('geoGeoFences')->andReturn($geoFencesMock);

        $geoFencesMock->shouldReceive('find')->with($geoFencesId)->andReturn(null);

        $response = $this->json('GET', '/api/organization/'.$orgId.'/geo-fence/'.$geoFencesId);

        // Assert that the status is 404 and the response contains the expected error message
        $response->assertStatus(404)->assertJson([
            'error' => [

                'title'  => 'Not Found',
                'detail' => 'Geo Fences not found for '.$orgModelMock->name,
            ],
        ]);
    }

    public function test_successful_geo_fence_retrieval()
    {
        $orgModelMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $geoFencesMock = Mockery::mock();
        $orgId = 1;
        $geoFencesId = 100;

        $orgModelMock->shouldReceive('find')->with($orgId)->andReturn($orgModelMock);
        $orgModelMock->shouldReceive('geoGeoFences->find')->with($geoFencesId)->andReturn($geoFencesMock);

        $geoFencesMock->shouldReceive('getAttribute')->with('id')->andReturn($geoFencesId);

        $response = $this->json('GET', '/api/organization/'.$orgId.'/geo-fence/'.$geoFencesId);

        // Assert that the status is 200 and the response contains the expected data
        $response->assertStatus(200)->assertJson([
            'data' => [
                'status'  => true,
                'message' => 'Users fetched successfully',
            ],
        ]);
    }
}
