<?php

namespace Tests\Unit;

use Mockery;
use Tests\TestCase;

class SetEnrollmentTest extends TestCase
{
    protected $enrollmentService;

    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutExceptionHandling();
        $this->withoutMiddleware();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    /**
     * Test missing mobile parameter.
     *
     * @return void
     */
    public function test_missing_mobile_parameter()
    {
        $response = $this->json('POST', 'api/enrolstatus', []);

        $response->assertStatus(400)->assertJson([
            'error' => [
                'title'  => 'Missing Required Parameters',
                'status' => 400,
            ],
        ]);
    }

    /**
     * Test user not found.
     *
     * @return void
     */
    public function test_user_not_found()
    {
        $userMock = Mockery::mock('alias:App\Models\User');
        $userMock->shouldReceive('where')->with('mobile', '0987654321')->andReturnSelf(); // This will return the mock object itself, allowing chaining of `first()`

        $userMock->shouldReceive('first')->andReturn(null);

        $response = $this->postJson('api/enrolstatus', [
            'mobile' => '0987654321',
        ]);

        $response->assertStatus(404)->assertJson([
            'error' => [
                'status' => 404,
                'title'  => 'Not Found',
                'detail' => 'The mobile number provided (0987654321) is not registered with iValt.',
            ],
        ]);
    }

    /**
     * Test user already enrolled.
     *
     * @return void
     */
    public function test_user_already_enrolled()
    {
        $userMock = Mockery::mock('alias:App\Models\User');
        $userMock->shouldReceive('where')->with('mobile', '6283974746')->andReturnSelf();

        $userMock->shouldReceive('first')->andReturn((object) ['is_enrolled' => 1]);

        $userMock->shouldReceive('update')->andReturn(true);

        $response = $this->postJson('api/enrolstatus', [
            'mobile' => '6283974746',
        ]);

        $response->assertStatus(200)->assertJson([
            'data' => [
                'status'  => true,
                'message' => 'User is enrolled.',
                'details' => [
                    'is_enrolled'        => 1,
                    'blockChainResponse' => null,
                ],
            ],
        ]);
    }

    public function test_successful_enrollment()
    {
        // Create a mock for the User model
        $userMock = Mockery::mock('alias:App\Models\User');
        $userMock->shouldReceive('where')->with('mobile', '6283974746')->andReturnSelf();

        // The initial state of the user before update (not enrolled)
        $userMock->shouldReceive('first')->andReturn((object) ['is_enrolled' => 0])->once();

        // Mock the `update` method
        $userMock
            ->shouldReceive('update')
            ->with(['is_enrolled' => 1])
            ->andReturn(true)
            ->once();

        // After calling `update`, `first` should now return a user with `is_enrolled` set to 1
        $userMock->shouldReceive('first')->andReturn((object) ['is_enrolled' => 1])->once(); // Called after the update

        // Perform the request
        $response = $this->postJson('api/enrolstatus', [
            'mobile' => '6283974746',
        ]);

        $response->assertStatus(200)->assertJson([
            'data' => [
                'status'  => true,
                'message' => 'User is enrolled.',
                'details' => [
                    'is_enrolled'        => 1,
                    'blockChainResponse' => null,
                ],
            ],
        ]);
    }
}
