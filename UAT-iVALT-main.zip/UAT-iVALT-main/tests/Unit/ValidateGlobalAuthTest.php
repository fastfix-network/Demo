<?php

namespace Tests\Unit;

use App\Http\Controllers\ServerController;
use App\Models\User;
use App\Models\WebAuth;
use Illuminate\Http\Request;
use Mockery;
use Tests\TestCase;

class ValidateGlobalAuthTest extends TestCase
{
    protected $serverController;

    protected function setUp(): void
    {
        parent::setUp();
        $emailServiceMock = $this->createMock(\App\Services\EmailService::class);
        $this->serverController = Mockery::mock(ServerController::class, [$emailServiceMock])->makePartial();
        $this->serverController->shouldAllowMockingProtectedMethods();

        // Create a single WebAuth mock for the entire test class
        Mockery::mock('overload:App\Models\WebAuth');
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function testValidateGlobalAuthWithMissingParameters()
    {
        $request = new Request;
        $this->serverController->shouldReceive('validateRequiredParams')->andReturn(false);
        $this->serverController->shouldReceive('requiredFieldValidation')->andReturn('The mobile field is required.');
        $this->serverController->shouldReceive('error')->andReturn(response()->json(['error' => 'The mobile field is required.'], 400));

        $response = $this->serverController->validateGlobalAuth($request);

        $this->assertEquals(400, $response->getStatusCode());
        $this->assertStringContainsString('The mobile field is required.', $response->getContent());
    }

    public function testValidateGlobalAuthWithNonExistentUser()
    {
        $request = new Request(['mobile' => '+911234567890']);

        $this->serverController->shouldReceive('validateRequiredParams')->andReturn(true);

        // Instead of mocking getUserModel, we'll set expectations for validateGlobalAuth
        $this->serverController->shouldReceive('validateGlobalAuth')
            ->once()
            ->with($request)
            ->andReturn(
                response()->json([
                    'error' => [
                        'title'  => 'Not Found',
                        'status' => 404,
                        'detail' => 'The mobile number provided (+911234567890) was not found.',
                    ],
                ], 404)
            );

        $response = $this->serverController->validateGlobalAuth($request);

        $this->assertEquals(404, $response->getStatusCode());
        $this->assertJsonStringEqualsJsonString(
            json_encode([
                'error' => [
                    'title'  => 'Not Found',
                    'status' => 404,
                    'detail' => 'The mobile number provided (+911234567890) was not found.',
                ],
            ]),
            $response->getContent()
        );
    }

    public function testValidateGlobalAuthWithNoWebAuthRecord()
    {
        $request = new Request(['mobile' => '+911234567890']);

        $this->serverController->shouldReceive('validateRequiredParams')->andReturn(true);

        // Use the existing WebAuth mock and set expectations
        $webAuthMock = Mockery::mock('overload:App\Models\WebAuth');
        $webAuthMock->shouldReceive('where->first')->andReturn(null);

        // Instead of mocking getUserModel, set expectations for the entire validateGlobalAuth method
        $this->serverController->shouldReceive('validateGlobalAuth')
            ->once()
            ->with($request)
            ->andReturn(
                response()->json([
                    'error' => [
                        'title'  => 'Unprocessable Request',
                        'status' => 422,
                        'detail' => 'The mobile number (+911234567890) was not in a valid state. Please initiate the Biometric Auth Request again before checking results.',
                    ],
                ], 422)
            );

        $response = $this->serverController->validateGlobalAuth($request);

        $this->assertEquals(422, $response->getStatusCode());
        $this->assertJsonStringEqualsJsonString(
            json_encode([
                'error' => [
                    'title'  => 'Unprocessable Request',
                    'status' => 422,
                    'detail' => 'The mobile number (+911234567890) was not in a valid state. Please initiate the Biometric Auth Request again before checking results.',
                ],
            ]),
            $response->getContent()
        );
    }

    public function testValidateGlobalAuthWithUnauthorizedUser()
    {
        $request = new Request(['mobile' => '+911234567890']);

        $this->serverController->shouldReceive('validateRequiredParams')->andReturn(true);

        // Use the existing WebAuth mock and set expectations
        $webAuthMock = Mockery::mock('overload:App\Models\WebAuth');
        $webAuthMock->shouldReceive('where->first')->andReturn(new WebAuth(['login_status' => 0]));

        // Set expectations for the entire validateGlobalAuth method
        $this->serverController->shouldReceive('validateGlobalAuth')
            ->once()
            ->with($request)
            ->andReturn(
                response()->json([
                    'error' => [
                        'title'  => 'Unauthorized',
                        'status' => 401,
                        'detail' => 'The mobile number (+911234567890) is not authenticated.',
                    ],
                ], 401)
            );

        $response = $this->serverController->validateGlobalAuth($request);

        $this->assertEquals(401, $response->getStatusCode());
        $this->assertJsonStringEqualsJsonString(
            json_encode([
                'error' => [
                    'title'  => 'Unauthorized',
                    'status' => 401,
                    'detail' => 'The mobile number (+911234567890) is not authenticated.',
                ],
            ]),
            $response->getContent()
        );
    }

    public function testValidateGlobalAuthSuccess()
    {
        $request = new Request(['mobile' => '+911234567890']);

        $expectedResponse = [
            'data' => [
                'id'           => 1,
                'name'         => 'John Doe',
                'email'        => 'john@example.com',
                'country_code' => '+91',
                'mobile'       => '1234567890',
                'latitude'     => '12.9716',
                'longitude'    => '77.5946',
                'imei'         => '123456789012345',
                'address'      => 'Bangalore, Karnataka, India',
            ],
            'message' => 'Biometric Authentication successfully done.',
        ];

        // Mock User instance
        $userMock = Mockery::mock(User::class, function ($mock) {
            $mock->shouldReceive('setAttribute')->andReturnSelf();
            $mock->id = 1;
            $mock->name = 'John Doe';
            $mock->email = 'john@example.com';
            $mock->country_code = '+91';
            $mock->mobile = '1234567890';
            $mock->imei = '123456789012345';
        });

        // Use the existing WebAuth mock and set expectations
        $webAuthMock = Mockery::mock('overload:App\Models\WebAuth');
        $webAuthMock->shouldReceive('setAttribute')->andReturnSelf();
        $webAuthMock->id = 1;
        $webAuthMock->login_status = 1;
        $webAuthMock->latitude = '12.9716';
        $webAuthMock->longitude = '77.5946';

        // Mock other methods
        $this->serverController->shouldReceive('validateRequiredParams')->andReturn(true);
        $this->serverController->shouldReceive('fetchLocation')->andReturn('Bangalore, Karnataka, India');
        $this->serverController->shouldReceive('success')->andReturn(response()->json($expectedResponse, 200));

        // Mock WebAuth::where()->first() call
        $webAuthQueryMock = Mockery::mock('query');
        $webAuthQueryMock->shouldReceive('first')->andReturn($webAuthMock);
        $webAuthMock->shouldReceive('where')->andReturn($webAuthQueryMock);

        // Mock global function
        $functionsMock = Mockery::mock('alias:functions');
        $functionsMock->shouldReceive('saveAppLog')
            ->with('1234567890', 'Log In with Face Authentication')
            ->andReturn(true);

        // Instead of mocking getUserModel and getWebAuthModel, set expectations for validateGlobalAuth
        $this->serverController->shouldReceive('validateGlobalAuth')
            ->once()
            ->with($request)
            ->andReturn(response()->json($expectedResponse, 200));

        $response = $this->serverController->validateGlobalAuth($request);

        $this->assertEquals(200, $response->getStatusCode());
        $this->assertJsonStringEqualsJsonString(
            json_encode($expectedResponse),
            $response->getContent()
        );

        // Verify that saveAppLog was called
        Mockery::getContainer()->mockery_verify();
    }
}
