<?php

namespace Tests\Unit;

use Mockery;
use Tests\TestCase;

class StoreOrganizationAuthCodesTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function test_organization_not_found()
    {
        $orgId = 1;

        // Mock Organization model
        $orgModelMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $orgModelMock->shouldReceive('find')->with($orgId)->andReturn(null);

        $response = $this->json('POST', "/api/organization/{$orgId}/create/auth-code");

        $response->assertStatus(404)->assertJson([
            'error' => [
                'title'  => 'Not Found',
                'detail' => 'Organization not found',
            ],
        ]);
    }

    public function test_missing_required_parameters()
    {
        $orgId = 1;

        $orgModelMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $orgModelMock->shouldReceive('find')->with($orgId)->andReturn($orgModelMock);

        $response = $this->json('POST', "/api/organization/{$orgId}/create/auth-code", []);

        $response->assertStatus(400)->assertJson([
            'error' => [
                'status' => '400',
                'title'  => 'Missing Required Parameters',
            ],
        ]);
    }

    public function test_auth_code_already_exists()
    {
        $orgId = 1;
        $request = ['client_id' => 'first_client_id', 'client_secret' => 'first_client_secret'];

        // Mock Organization model
        $orgModelMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $orgModelMock->shouldReceive('find')->with($orgId)->andReturn($orgModelMock);

        // Mock authCodes relationship method
        $authCodeMock = Mockery::mock('alias:App\Models\Organization\OrganizationAuthCode');
        $authCodeMock->shouldReceive('count')->andReturn(1);

        $orgModelMock->shouldReceive('authCodes')->andReturn($authCodeMock);

        $response = $this->json('POST', "/api/organization/{$orgId}/create/auth-code", $request);

        $response->assertStatus(404)->assertJson([
            'error' => [
                'title'  => 'Auth Code Exists!',
                'detail' => 'Org Auth Code already exists.',
            ],
        ]);
    }

    public function test_successful_auth_code_creation()
    {
        $orgId = 1;
        $requestData = ['client_id' => 'new_client_id', 'client_secret' => 'new_client_secret'];

        // Mock Organization model
        $orgModelMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $orgModelMock->shouldReceive('find')->with($orgId)->andReturn($orgModelMock);

        // Mock authCodes relationship method
        $authCodeMock = Mockery::mock('alias:App\Models\Organization\OrganizationAuthCode');
        $authCodeMock->shouldReceive('count')->andReturn(0);
        $orgModelMock->id = $orgId;
        $orgModelMock->shouldReceive('authCodes')->andReturn($authCodeMock);
        $authCodeMock->shouldReceive('create')
            ->with(array_merge($requestData, ['organization_id' => $orgId]))
            ->andReturn((object) ['id' => 1, 'client_id' => 'new_client_id', 'client_secret' => 'new_client_secret']);

        $response = $this->json('POST', "/api/organization/{$orgId}/create/auth-code", $requestData);

        $response->assertStatus(200)->assertJson([
            'data' => [
                'status'  => 'success',
                'message' => 'Org Auth Code created successfully.',
            ],
        ]);
    }
}
