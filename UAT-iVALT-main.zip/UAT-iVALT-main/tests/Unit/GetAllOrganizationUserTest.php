<?php

namespace Tests\Unit;

use App\Models\Organization\Organization;
use App\Models\User;
use Mockery;
use Tests\Testcase;

class GetAllOrganizationUserTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();

    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function testGetAllOrganizationUserSuccess()
    {
        // Arrange
        $orgId = 1;

        $organizationMock = Mockery::mock('overload:App\Models\Organization\Organization');
        $userMock = Mockery::mock('overload:App\Models\User');
        $organizationMock->shouldReceive('find')
            ->with(1)
            ->andReturn($organizationMock);

        $organizationMock->shouldReceive('getAttribute')
            ->with('users')
            ->andReturn(collect([$userMock]));

        $userMock->shouldReceive('load')
            ->with('timeSlots')
            ->andReturnSelf();

        $organizationMock->shouldReceive('users')
            ->andReturn($userMock);

        $this->app->instance(Organization::class, $organizationMock);
        $this->app->instance(User::class, $userMock);

        // Act
        $response = $this->json('GET', "/api/organization/{$orgId}/users");

        // Assert
        $response->assertStatus(200)
            ->assertJson([
                'data' => [
                    'status'  => true,
                    'message' => 'Users fetched successfully',
                    // Include expected user data here, if needed
                ],
            ]);
    }

    public function testGetAllOrganizationUserNoUsers()
    {
        // Arrange
        $orgId = 1;
        $organizationMock = Mockery::mock('overload:App\Models\Organization\Organization');
        $organizationMock->shouldReceive('find')
            ->with($orgId)
            ->andReturn(null);

        $this->app->instance(Organization::class, $organizationMock);

        // Act
        $response = $this->json('GET', "/api/organization/{$orgId}/users");

        // Assert
        $response->assertStatus(404)
            ->assertJson([
                'error' => [
                    'title'  => 'Not Found',
                    'status' => 404,
                    'detail' => 'Organization not found',

                ],
            ]);
    }
}
