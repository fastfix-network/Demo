<?php

namespace Tests\Unit;

use App\Models\User;
use Illuminate\Foundation\Testing\WithFaker;
use Mockery;
use Tests\TestCase;

class UpdateProfileTest extends TestCase
{
    use WithFaker;

    protected function setUp(): void
    {
        parent::setUp();

        // Mock the User model
        $this->userMock = Mockery::mock('overload:'.User::class);
        $this->app->instance(User::class, $this->userMock);
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function test_missing_required_parameters()
    {
        $response = $this->json('POST', 'api/update-profile', [
            'country_code' => '+91',
            'mobile'       => '6283974746',
        ]);

        $response->assertStatus(400)
            ->assertJson([
                'error' => [
                    'title'  => 'Missing Required Parameters',
                    'status' => 400,
                ],
            ]);
    }

    public function test_name_exceeds_maximum_length()
    {
        $response = $this->json('POST', 'api/update-profile', [
            'country_code' => '1',
            'mobile'       => '6283974746545',
            'name'         => 'ThisNameIsWayTooLong---',
        ]);

        $response->assertStatus(403)
            ->assertJson([
                'error' => [
                    'title'  => 'Not Found',
                    'status' => 403,
                    'detail' => 'Name should not be greater than 20 characters.',
                ],

            ]);
    }

    public function test_mobile_number_not_found()
    {
        $this->userMock->shouldReceive('where')->andReturnSelf();
        $this->userMock->shouldReceive('exists')->andReturn(false);

        $response = $this->json('POST', 'api/update-profile', [
            'country_code' => '1',
            'mobile'       => '1234567890',
            'name'         => 'John Doe',
        ]);

        $response->assertStatus(404)
            ->assertJson([
                'error' => [
                    'title'  => 'Not Found',
                    'status' => 404,
                    'detail' => 'The mobile number provided (1234567890) was not found.',
                ],
            ]);
    }

    public function test_successful_profile_update()
    {
        $this->userMock->shouldReceive('where')->andReturnSelf();
        $this->userMock->shouldReceive('exists')->andReturn(true);
        $this->userMock->shouldReceive('update')->andReturn(true);

        $response = $this->json('POST', 'api/update-profile', [
            'country_code' => '+91',
            'mobile'       => '6283974746',
            'name'         => 'Bikramjeet',
        ]);

        $response->assertStatus(200)
            ->assertJson([
                'data' => [
                    'status'  => true,
                    'message' => 'Profile successfully updated.',
                ],
            ]);
    }
}
