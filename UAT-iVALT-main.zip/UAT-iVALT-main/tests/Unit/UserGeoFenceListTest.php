<?php

namespace Tests\Unit;

use Mockery;
use Tests\TestCase;

class UserGeoFenceListTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function test_user_not_found()
    {
        // Arrange
        $userId = 1;

        // Mock User::find() to return null
        $userMock = Mockery::mock('alias:App\Models\User');
        $userMock
            ->shouldReceive('find')
            ->with($userId)
            ->andReturn(null);

        // Act: Perform the API call
        $response = $this->json('GET', "/api/user/{$userId}/geofences");

        // Assert: Check that the response indicates the user was not found
        $response->assertStatus(404)
            ->assertJson([
                'error' => [
                    'status' => 404,
                    'detail' => 'User not found',
                ],
            ]);
    }

    public function test_user_found_orgGeoFences_not_found()
    {
        // Arrange
        $userId = 1;

        $userMock = Mockery::mock('alias:App\Models\User');
        $organizationGeoFencesMock = Mockery::mock('alias:App\Models\Organization\OrganizationGeoFences');
        $userMock
            ->shouldReceive('find')
            ->with($userId)
            ->andReturn($userMock);

        // Mock orgGeoFences method to return null or an empty collection
        $userMock
            ->shouldReceive('orgGeoFences')
            ->andReturn(null);

        // Act: Perform the API call
        $response = $this->json('GET', "/api/user/{$userId}/geofences");

        // Assert: Check that the response indicates the orgGeoFences were not found
        $response->assertStatus(404)
            ->assertJson([
                'error' => [
                    'status' => 404,
                    'detail' => 'User orgGeoFences not found',
                ],
            ]);
    }

    public function test_successful_orgGeoFences_retrieval()
    {
        // Arrange
        $userId = 1;
        $orgGeoFences = [
            ['organization_id' => 1, 'name' => 'GeoFence 1', 'latitude' => '40.712776', 'longitude' => '-74.005974', 'radius' => 100, 'is_active' => true],
            ['organization_id' => 1, 'name' => 'GeoFence 2', 'latitude' => '34.052235', 'longitude' => '-118.243683', 'radius' => 200, 'is_active' => true],
        ]; // Example geofences

        $userMock = Mockery::mock('alias:App\Models\User');
        $orgGeoFencesMock = Mockery::mock('alias:App\Models\Organization\OrganizationGeoFences');
        $userMock
            ->shouldReceive('find')
            ->with($userId)
            ->andReturn($userMock);

        // Mock orgGeoFences method to return a collection of geofences
        $userMock
            ->shouldReceive('orgGeoFences')
            ->andReturn($orgGeoFencesMock);

        // Act: Perform the API call
        $response = $this->json('GET', "/api/user/{$userId}/geofences");

        // Assert: Check that the response indicates a successful retrieval
        $response->assertStatus(200)
            ->assertJson([
                'data' => [
                    'status'  => true,
                    'message' => 'User orgGeoFences list.',
                ],

            ]);
    }
}
