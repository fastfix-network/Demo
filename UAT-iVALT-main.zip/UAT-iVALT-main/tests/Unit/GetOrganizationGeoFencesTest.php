<?php

namespace Tests\Unit;

use Mockery;
use Tests\TestCase;

class GetOrganizationGeoFencesTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function test_successful_geo_fences_retrieval()
    {

        $orgModelMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $geoFencesMock = Mockery::mock();
        $orgId = 1;
        $orgModelMock->shouldReceive('find')->with($orgId)->andReturn($orgModelMock);

        $orgModelMock->shouldReceive('geoGeoFences')->andReturn($geoFencesMock);

        // Mock the get() method on the geoGeoFences relationship to return a collection
        $geoFencesMock->shouldReceive('get')->andReturn(collect([
            ['id' => 1, 'name' => 'GeoFence 1'],
            ['id' => 2, 'name' => 'GeoFence 2'],
        ]));

        // Send a GET request to the API endpoint
        $response = $this->json('GET', '/api/organization/'.$orgId.'/geo-fences');

        // Assert that the status is 200 and the response contains the expected data
        $response->assertStatus(200)->assertJson([
            'data' => [
                'status'  => true,
                'message' => 'Geo fences fetched successfully',
            ],
        ]);
    }

    public function test_organization_not_found()
    {

        $orgModelMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $orgId = 1;
        $orgModelMock->shouldReceive('find')->with($orgId)->andReturn(null);

        // Send a GET request to the API endpoint
        $response = $this->json('GET', '/api/organization/'.$orgId.'/geo-fences');

        $response->assertStatus(404)->assertJson([
            'error' => [
                'title'  => 'Not Found',
                'detail' => 'Organization not found',
            ],
        ]);
    }

    public function test_geo_fences_not_found()
    {

        $orgModelMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $orgId = 1;
        $orgModelMock->shouldReceive('find')->with($orgId)->andReturn($orgModelMock);
        $orgModelMock->name = 'Test ORG';

        $geoFencesMock = Mockery::mock();
        $orgModelMock->shouldReceive('geoGeoFences')->andReturn($geoFencesMock);
        $geoFencesMock->shouldReceive('get')->andReturn(collect()); // Return an empty collection
        $response = $this->json('GET', '/api/organization/'.$orgId.'/geo-fences');
        $response->assertStatus(404)->assertJson([
            'error' => [
                'title'  => 'Not Found',
                'detail' => 'Geo fences not found for '.$orgModelMock->name,
            ],
        ]);
    }
}
