<?php

namespace Tests\Unit;

use Mockery;
use Tests\TestCase;

class StoreOrganizationGeoFencesTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function test_successful_geo_fences_creation()
    {
        $orgId = 1;
        $geoFenceData = [
            'name'      => 'Test GeoFence',
            'latitude'  => '12.345678',
            'longitude' => '98.765432',
            'radius'    => '100',
            'is_active' => true,
        ];

        $orgModelMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $geoFencesMock = Mockery::mock('alias:App\Models\Organization\OrganizationGeoFences');

        $orgModelMock->id = $orgId;
        $orgModelMock->shouldReceive('find')->with($orgId)->andReturn($orgModelMock);
        $orgModelMock->shouldReceive('getAttribute')->with('id')->andReturn($orgId);
        $orgModelMock->shouldReceive('geoGeoFences')->andReturn($geoFencesMock);
        $geoFencesMock->shouldReceive('create')->with($geoFenceData + ['organization_id' => $orgId])->andReturn($geoFencesMock);

        $response = $this->json('POST', '/api/organization/'.$orgId.'/create/geo-fence', $geoFenceData);

        $response->assertStatus(200)->assertJson([

            'data' => [
                'status'  => true,
                'message' => 'Geo fences created successfully.',
            ],
        ]);
    }

    public function test_missing_required_parameters()
    {
        $orgId = 1;
        $orgModelMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $orgModelMock->shouldReceive('find')->with($orgId)->andReturn($orgModelMock);

        $response = $this->json('POST', '/api/organization/'.$orgId.'/create/geo-fence', []);

        $response->assertStatus(400)->assertJson([
            'error' => [
                'status' => 400,
                'title'  => 'Missing Required Parameters',

            ],
        ]);
    }

    public function test_organization_not_found()
    {
        $orgId = 1;

        $orgModelMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $orgModelMock->shouldReceive('find')->with($orgId)->andReturn(null);

        $response = $this->json('POST', '/api/organization/'.$orgId.'/create/geo-fence');

        $response->assertStatus(404)->assertJson([
            'error' => [
                'title'  => 'Not Found',
                'detail' => 'Organization not found',
            ],
        ]);
    }

    public function test_geo_fences_not_created()
    {
        $orgId = 1;
        $geoFenceData = [
            'name'      => 'Test GeoFence',
            'latitude'  => '12.345678',
            'longitude' => '98.765432',
            'radius'    => '100',
            'is_active' => true,
        ];

        $orgModelMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $geoFencesMock = Mockery::mock('alias:App\Models\Organization\OrganizationGeoFences');
        $orgModelMock->id = $orgId;
        $orgModelMock->name = 'Test ORG';

        $orgModelMock->shouldReceive('find')->with($orgId)->andReturn($orgModelMock);
        $orgModelMock->shouldReceive('getAttribute')->with('id')->andReturn($orgId);
        $orgModelMock->shouldReceive('getAttribute')->with('name')->andReturn('Test ORG');
        $orgModelMock->shouldReceive('geoGeoFences')->andReturn($geoFencesMock);
        $geoFencesMock->shouldReceive('create')->with($geoFenceData + ['organization_id' => $orgId])->andReturn(null);

        $response = $this->json('POST', '/api/organization/'.$orgId.'/create/geo-fence', $geoFenceData);

        $response->assertStatus(404)->assertJson([
            'error' => [
                'status' => 404,
                'title'  => 'Not Found',
                'detail' => 'Geo fences not created for '.$orgModelMock->name,
            ],
        ]);
    }
}
