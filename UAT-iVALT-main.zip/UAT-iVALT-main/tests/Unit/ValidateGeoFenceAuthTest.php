<?php

namespace Tests\Unit;

use Carbon\Carbon;
use Mockery;
use Tests\TestCase;

class ValidateGeoFenceAuthTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function test_missing_required_parameters()
    {
        $response = $this->json('POST', '/api/validate-geo-fence-auth', [
            // Missing 'mobile' parameter
        ]);

        $response->assertStatus(400);
        $response->assertJson([
            'error' => [
                'status' => '400',
                'title'  => 'Missing Required Parameters',
            ],
        ]);
    }

    public function test_mobile_number_not_found()
    {
        // Mocking WebAuth model
        $webAuthMock = Mockery::mock('alias:App\Models\WebAuth');
        $webAuthMock->shouldReceive('where')
            ->with(['mobile_with_country_code' => '1234567890'])
            ->andReturn($webAuthMock);
        $webAuthMock->shouldReceive('first')->andReturn(null);

        $response = $this->json('POST', '/api/validate-geo-fence-auth', [
            'mobile' => '1234567890',
        ]);

        $response->assertStatus(404);
        $response->assertJson([
            'error' => [
                'status' => '404',
                'title'  => 'Not Found',
            ],
        ]);
    }

    public function test_login_status_invalid()
    {
        // Mocking WebAuth model
        $webAuthMock = Mockery::mock('alias:App\Models\WebAuth');
        $webAuthMock->shouldReceive('where')
            ->with(['mobile_with_country_code' => '1234567890'])
            ->andReturn($webAuthMock);
        $webAuthMock->shouldReceive('first')->andReturn((object) ['login_status' => 0]);

        $response = $this->json('POST', '/api/validate-geo-fence-auth', [
            'mobile' => '1234567890',
        ]);

        $response->assertStatus(422);
        $response->assertJson([
            'error' => [
                'status' => '422',
                'title'  => 'Unprocessable Request',
            ],
        ]);
    }

    public function test_user_not_found()
    {
        // Mocking WebAuth model
        $webAuthMock = Mockery::mock('alias:App\Models\WebAuth');
        $webAuthMock->shouldReceive('where')
            ->with(['mobile_with_country_code' => '1234567890'])
            ->andReturn($webAuthMock);
        $webAuthMock->shouldReceive('first')->andReturn((object) ['login_status' => 1]);

        // Mocking User model
        $userMock = Mockery::mock('alias:App\Models\User');
        $userMock->shouldReceive('where')
            ->with(['mobile_with_country_code' => '1234567890'])
            ->andReturn($userMock);
        $userMock->shouldReceive('first')->andReturn(null);

        $response = $this->json('POST', '/api/validate-geo-fence-auth', [
            'mobile' => '1234567890',
        ]);

        $response->assertStatus(404);
        $response->assertJson([
            'error' => [
                'status' => '404',
                'title'  => 'Not Found',
            ],
        ]);
    }

    public function test_successful_geo_fence_auth()
    {
        // Mock WebAuth model
        $webAuthMock = Mockery::mock('alias:App\Models\WebAuth');
        $webAuthMock->shouldReceive('where')
            ->with(['mobile_with_country_code' => '1234567890'])
            ->andReturn($webAuthMock);
        $webAuthMock->shouldReceive('first')->andReturn((object) [
            'id' => 1,

            'mobile_with_country_code' => '1234567890',
            'login_status'             => 1,
            'timezone'                 => json_encode(['value' => 'America/New_York']),
            'time'                     => Carbon::now()->toDateTimeString(),
            'latitude'                 => 40.7128,
            'longitude'                => -74.0060,
            'full_address'             => '123 Main St, New York, NY', // Added full_address
        ]);

        // Mock Organization model
        $organizationMock = Mockery::mock('alias:App\Models\Organization');
        $organizationMock->shouldReceive('with')
            ->with(['geoGeoFences', 'users'])
            ->andReturn($organizationMock);

        // Mock User model with orgGeoFences and organizations relationships
        $userMock = Mockery::mock('alias:App\Models\User');
        $userMock->shouldReceive('where')
            ->with(['mobile_with_country_code' => '1234567890'])
            ->andReturn($userMock);
        $userMock->shouldReceive('first')->andReturn((object) [
            'name'               => 'Testing',
            'email'              => 'test1@gmail.com',
            'country_code'       => '+91',
            'mobile'             => '1234567890',
            'imei'               => 'hhbhkbklbjkjbk',
            'verify_timeslots'   => true,
            'verify_geo_fencing' => true,
            'orgTimeSlots'       => collect([
                (object) [
                    'timezone'   => json_encode(['value' => 'America/New_York']),
                    'start_time' => Carbon::now()->subMinutes(10)->toDateTimeString(),
                    'end_time'   => Carbon::now()->addMinutes(10)->toDateTimeString(),
                ],
            ]),
            'orgGeoFences' => collect([
                (object) [
                    'latitude'     => 40.7128,
                    'longitude'    => -74.0060,
                    'radius'       => 100, // Add radius to avoid the undefined property error
                    'is_active'    => 1,
                    'full_address' => '123 Main St, New York, NY', // Add full_address to avoid undefined property error
                ],
            ]),
            'organizations' => collect([
                (object) [
                    'id'   => 1,
                    'name' => 'Organization 1',
                ],
            ]), // Mocked organizations relationship
        ]);

        $webAuthMock->shouldReceive('delete')
            ->andReturn(true);

        $logMock = Mockery::mock('alias:App\Models\UserAppLogs');
        $logMock->shouldReceive('create')
            ->with(['mobile' => '1234567890', 'detail' => 'Log In with Face Authentication'])
            ->andReturn(true); // Assuming log creation is successful

        // Call the API with valid data
        $response = $this->json('POST', '/api/validate-geo-fence-auth', [
            'mobile' => '1234567890',
        ]);

        // Assert successful response
        $response->assertStatus(200);
        $response->assertJson([
            'data' => [
                'status'  => 'true',
                'message' => 'Biometric Authentication successfully done.',
            ],
        ]);
    }
}
