<?php

namespace Tests\Unit;

use Mockery;
use Tests\TestCase;

class ConfirmAppAuthLoginForWpTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    /** @test */
    public function test_missing_required_parameters()
    {
        $response = $this->json('POST', 'api/wp/confirm-login-auth', []);

        $response->assertStatus(400)->assertJson([
            'error' => [
                'status' => 400,
                'title'  => 'Missing Required Parameters',
            ],
        ]);
    }

    /** @test */
    public function test_invalid_domain_or_token()
    {
        // Mock UserAppLogs model
        $wpUserAppLogMock = Mockery::mock('alias:App\Models\UserAppLogs');
        $wpUserAppLogMock
            ->shouldReceive('create')
            ->with(['mobile' => '112345678', 'detail' => 'Log In into test.com'])
            ->andReturn(true);

        // Mock WpUser model
        $wpUserMock = Mockery::mock('alias:App\Models\WpUser');
        $wpUserMock
            ->shouldReceive('where')
            ->with([
                'user_token'   => 'kjdfjpklnjkld',
                'website'      => 'test.com',
                'country_code' => '+91',
                'mobile'       => '112345678',
            ])
            ->andReturnSelf();
        $wpUserMock
            ->shouldReceive('update')
            ->with(['app_auth_status' => 'true'])
            ->andReturn(false);

        // Create a request with the test data
        $response = $this->json('POST', 'api/wp/confirm-login-auth', [
            'country_code' => '+91',
            'mobile'       => '112345678',
            'domain'       => 'test.com',
            'token'        => 'kjdfjpklnjkld',
        ]);

        // Assert the response
        $response->assertStatus(400)->assertJson([
            'error' => [
                'status' => 400,
                'title'  => 'Authentication Failed',
            ],
        ]);
    }

    /** @test */
    public function testSuccessfulAuthentication()
    {
        // Arrange
        $mobile = '112345678';
        $domain = 'test.com';
        $token = 'kjdfjpklnjkld';
        $countryCode = '+91';

        // Mock UserAppLogs model
        $userAppLogsMock = Mockery::mock('alias:App\Models\UserAppLogs');
        $userAppLogsMock
            ->shouldReceive('create')
            ->once()
            ->with(['mobile' => $mobile, 'detail' => "Log In into $domain"])
            ->andReturn(true);

        // Mock WpUser model
        $wpUserMock = Mockery::mock('alias:App\Models\WpUser');
        $wpUserMock
            ->shouldReceive('where')
            ->once()
            ->with([
                'user_token'   => $token,
                'website'      => $domain,
                'country_code' => $countryCode,
                'mobile'       => $mobile,
            ])
            ->andReturnSelf();

        $wpUserMock
            ->shouldReceive('update')
            ->once()
            ->with(['app_auth_status' => 'true'])
            ->andReturn(true);

        // Mock Functions helper
        $functionsMock = Mockery::mock('overload:App\Helpers\Functions');
        $functionsMock
            ->shouldReceive('saveAppLog')
            ->once()
            ->with($mobile, "Log In into $domain")
            ->andReturn(true);

        $response = $this->json('POST', 'api/wp/confirm-login-auth', [
            'country_code' => $countryCode,
            'mobile'       => $mobile,
            'domain'       => $domain,
            'token'        => $token,
        ]);

        $response->assertStatus(200)->assertJson([
            'data' => [
                'status'  => true,
                'message' => 'Authentication Successful.',
                'details' => null,
            ],
        ]);
    }
}
