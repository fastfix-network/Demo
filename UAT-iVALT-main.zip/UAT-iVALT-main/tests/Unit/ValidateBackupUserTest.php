<?php

namespace Tests\Unit;

use Mockery;
use Tests\TestCase;

class ValidateBackupUserTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function test_missing_required_parameters()
    {
        // Send a request without the 'mobile' parameter
        $response = $this->json('POST', '/api/backup/validate/user', []);

        // Assert that the response status is 400 and the error message is correct
        $response->assertStatus(400)->assertJson([
            'error' => [
                'status' => 400,
                'title'  => 'Missing Required Parameters',
                'detail' => 'Mobile number is required.',
            ],
        ]);
    }

    public function test_mobile_not_found()
    {
        // Mock the User model
        $userMock = Mockery::mock('alias:App\Models\User');
        $userMock->shouldReceive('where')->with('mobile', 'nonexistent_mobile')->andReturnSelf();
        $userMock->shouldReceive('first')->andReturn(null);

        // Mock the UserAppLogs model
        $logMock = Mockery::mock('alias:App\Models\UserAppLogs');
        $logMock->shouldReceive('create')->with([
            'mobile' => 'nonexistent_mobile',
            'detail' => 'Log In from backup system',
        ])->andReturn(true);

        // Send a request with a non-existent mobile number
        $response = $this->json('POST', '/api/backup/validate/user', ['mobile' => 'nonexistent_mobile']);

        $response->assertStatus(404)->assertJson([
            'error' => [
                'status' => 404,
                'title'  => 'Not Found',
                'detail' => 'The mobile number provided (nonexistent_mobile) is not registered with iValt.',
            ],
        ]);
    }

    public function test_successful_user_validation()
    {
        // Mock the User model
        $userMock = Mockery::mock('alias:App\Models\User');
        $userMock->shouldReceive('where')->with('mobile', 'valid_mobile')->andReturnSelf();
        $userMock->shouldReceive('first')->andReturn((object) ['id' => 1, 'mobile' => 'valid_mobile']);

        // Mock the UserAppLogs model
        $logMock = Mockery::mock('alias:App\Models\UserAppLogs');
        $logMock->shouldReceive('create')->with([
            'mobile' => 'valid_mobile',
            'detail' => 'Log In from backup system',
        ])->andReturn(true);

        // Send a request with a valid mobile number
        $response = $this->json('POST', '/api/backup/validate/user', ['mobile' => 'valid_mobile']);

        $response->assertStatus(200)->assertJson([
            'data' => [
                'message' => 'User found.',

            ],

        ]);
    }
}
