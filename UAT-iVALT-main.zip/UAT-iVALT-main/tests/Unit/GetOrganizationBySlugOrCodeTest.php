<?php

namespace Tests\Unit;

use Mockery;
use Tests\TestCase;

class GetOrganizationBySlugOrCodeTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function test_missing_required_parameters()
    {
        $response = $this->json('GET', '/api/user/null/organizations/null');

        $response->assertStatus(400)->assertJson([
            'error' => [
                'status' => 400,
                'title'  => 'Missing Required Parameters',
            ],
        ]);
    }

    public function test_organization_not_found()
    {
        $orgMock = Mockery::mock('alias:App\Models\Organization\Organization');

        $orgMock->shouldReceive('where')
            ->with('organization_code', 'nonexistent_slug')
            ->andReturnSelf();

        $orgMock->shouldReceive('first')
            ->andReturn(null);

        $response = $this->json('GET', '/api/user/1/organizations/nonexistent_slug');

        $response->assertStatus(404)->assertJson([
            'error' => [
                'status' => 404,
                'title'  => 'Organization not found', // Update the expected title to 'Organization not found'
                'detail' => 'The organization with the provided slug does not exist.',
            ],
        ]);
    }

    public function test_user_not_found_in_organization()
    {
        // Mock the Organization model
        $orgMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $userMock = Mockery::mock('alias:App\Models\User');
        $orgMock->shouldReceive('where')
            ->with('organization_code', 'valid_slug')
            ->andReturnSelf();

        $orgMock->shouldReceive('first')
            ->andReturn($orgMock);

        $userMock->shouldReceive('find')
            ->with(1)
            ->andReturn(null);

        $orgMock->shouldReceive('users')
            ->andReturn($userMock);

        // Call the API endpoint and assert the response
        $response = $this->json('GET', '/api/user/1/organizations/valid_slug');

        // Assert the response
        $response->assertStatus(404)->assertJson([
            'error' => [
                'status' => 404,
                'title'  => 'User not found',
                'detail' => 'The user with the provided ID does not exist in this organization.',
            ],
        ]);
    }

    public function test_successful_organization_and_user_retrieval()
    {
        $userMock = Mockery::mock('alias:App\Models\User');
        $orgMock = Mockery::mock('alias:App\Models\Organization\Organization');

        $orgMock->shouldReceive('where')
            ->with('organization_code', 'existing_slug')
            ->andReturnSelf();
        $orgMock->shouldReceive('first')
            ->andReturn($orgMock);
        $userMock->shouldReceive('find')
            ->with(1)
            ->andReturn(true);

        $orgMock->shouldReceive('users')
            ->andReturn($userMock);

        $response = $this->json('GET', '/api/user/1/organizations/existing_slug');

        $response->assertStatus(200)->assertJson([
            'data' => [
                'message' => 'Organizations fetched successfully',
                'details' => 'true',
            ],

        ]);
    }
}
