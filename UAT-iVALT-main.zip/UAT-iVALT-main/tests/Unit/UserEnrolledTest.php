<?php

namespace Tests\Unit;

use App\Http\Controllers\ServerController;
use App\Models\User;
use Illuminate\Support\Facades\Route;
use Mockery;
use Tests\TestCase;

class UserEnrolledTest extends TestCase
{
    protected $userMock;

    protected $controllerMock;

    protected function setUp(): void
    {
        parent::setUp();

        $this->userMock = Mockery::mock(User::class);
        $this->app->instance(User::class, $this->userMock);

        $this->controllerMock = Mockery::mock(ServerController::class)->makePartial();
        $this->app->instance(ServerController::class, $this->controllerMock);

        Route::post('/api/is_enrolled', [ServerController::class, 'isEnrolled']);
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function test_missing_mobile_parameter()
    {
        $this->controllerMock->shouldReceive('isEnrolled')
            ->once()
            ->andReturn(response()->json([
                'error' => [
                    'title'  => 'Missing Required Parameters',
                    'detail' => 'The mobile number is required.',
                ],
            ], 400));

        $response = $this->postJson('/api/is_enrolled', [
            'country_code' => '+91',
        ]);

        $response->assertStatus(400)
            ->assertJson([
                'error' => [
                    'title'  => 'Missing Required Parameters',
                    'detail' => 'The mobile number is required.',
                ],
            ]);
    }

    public function test_user_not_found()
    {
        $this->userMock->shouldReceive('where')->andReturnSelf()
            ->shouldReceive('first')->andReturnNull();

        $this->controllerMock->shouldReceive('isEnrolled')
            ->once()
            ->andReturn(response()->json([
                'data' => [
                    'status'  => true,
                    'message' => 'User is not enrolled.',
                    'details' => [
                        'is_enrolled'      => 0,
                        'enrollmentStatus' => false,
                    ],
                ],
            ], 200));

        $response = $this->postJson('/api/is_enrolled', [
            'country_code' => '+91',
            'mobile'       => '1234567890',
        ]);

        $response->assertStatus(200)
            ->assertJson([
                'data' => [
                    'status'  => true,
                    'message' => 'User is not enrolled.',
                    'details' => [
                        'is_enrolled'      => 0,
                        'enrollmentStatus' => false,
                    ],
                ],
            ]);
    }

    public function test_user_not_enrolled()
    {
        $userMock = Mockery::mock(User::class);
        $userMock->shouldReceive('setAttribute')->with('is_enrolled', 0);
        $userMock->is_enrolled = 0;

        $this->userMock->shouldReceive('where')->andReturnSelf()
            ->shouldReceive('first')->andReturn($userMock);

        $this->controllerMock->shouldReceive('isEnrolled')
            ->once()
            ->andReturn(response()->json([
                'data' => [
                    'status'  => true,
                    'message' => 'User is not enrolled.',
                    'details' => [
                        'is_enrolled'      => 0,
                        'enrollmentStatus' => false,
                    ],
                ],
            ], 200));

        $response = $this->postJson('/api/is_enrolled', [
            'country_code' => '+91',
            'mobile'       => '6283974744',
        ]);

        $response->assertStatus(200)
            ->assertJson([
                'data' => [
                    'status'  => true,
                    'message' => 'User is not enrolled.',
                    'details' => [
                        'is_enrolled'      => 0,
                        'enrollmentStatus' => false,
                    ],
                ],
            ]);
    }

    public function test_user_enrolled()
    {
        $userMock = Mockery::mock(User::class);
        $userMock->shouldReceive('setAttribute')->with('is_enrolled', 1);
        $userMock->is_enrolled = 1;

        $this->userMock->shouldReceive('where->first')->andReturn($userMock);

        $this->controllerMock->shouldReceive('isEnrolled')
            ->once()
            ->andReturn(response()->json([
                'data' => [
                    'status'  => true,
                    'message' => 'User is enrolled.',
                    'details' => [
                        'is_enrolled'      => 1,
                        'enrollmentStatus' => true,
                    ],
                ],
            ], 200));

        $response = $this->postJson('/api/is_enrolled', [
            'country_code' => '+91',
            'mobile'       => '6283974746',
        ]);

        $response->assertStatus(200)
            ->assertJson([
                'data' => [
                    'status'  => true,
                    'message' => 'User is enrolled.',
                    'details' => [
                        'is_enrolled'      => 1,
                        'enrollmentStatus' => true,
                    ],
                ],
            ]);
    }
}
