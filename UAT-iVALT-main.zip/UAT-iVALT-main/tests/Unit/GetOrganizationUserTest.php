<?php

namespace Tests\Unit;

use App\Models\Organization\Organization;
use App\Models\User;
use Mockery;
use Tests\TestCase;

class GetOrganizationUserTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function testGetOrganizationNotFound()
    {
        $org_id = 1;
        $user_id = 1;

        // Mock the Organization model
        $organizationMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $organizationMock->shouldReceive('find')
            ->with($org_id)
            ->andReturn(null);
        $organizationMock->shouldReceive('where')
            ->with('id', $org_id)
            ->andReturnSelf();
        $organizationMock->shouldReceive('first')
            ->andReturn(null);

        // Bind the mock instance in the container
        $this->app->instance(Organization::class, $organizationMock);

        // Perform the request
        $response = $this->json('GET', "/api/organization/{$org_id}/user/{$user_id}");

        $response->assertStatus(404)
            ->assertJson([
                'error' => [
                    'title'  => 'Not Found',
                    'status' => 404,
                    'detail' => 'Organization not found',
                ],
            ]);
    }

    public function testGetOrganizationUserSuccess()
    {
        $org_id = 1;
        $user_id = 1;

        // Mock the Organization and User models
        $organizationMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $organizationMock->id = $org_id;
        $userMock = Mockery::mock('alias:App\Models\User');
        $organizationMock->shouldReceive('find')
            ->with($org_id)
            ->andReturn($organizationMock);

        $organizationMock->shouldReceive('where')
            ->with('id', $org_id)
            ->andReturnSelf();
        $organizationMock->shouldReceive('first')
            ->andReturn($organizationMock);
        $organizationMock->shouldReceive('users')
            ->andReturn($userMock);

        $userMock->shouldReceive('find')
            ->with($user_id)
            ->andReturn($userMock);

        // Bind the mock instance in the container
        $this->app->instance(Organization::class, $organizationMock);
        $this->app->instance(User::class, $userMock);

        // Perform the request
        $response = $this->json('GET', "/api/organization/{$org_id}/user/{$user_id}");

        $response->assertStatus(200)
            ->assertJson([
                'data' => [
                    'status'  => true,
                    'message' => 'Users fetched successfully',
                ],
            ]);
    }

    public function testGetOrganizationUserNotFound()
    {
        $org_id = 1;
        $user_id = 1;

        // Mock the Organization and User models
        $organizationMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $usersMock = Mockery::mock('alias:App\Models\User');

        $organizationMock->id = $org_id;

        $organizationMock->shouldReceive('find')
            ->with($org_id)
            ->andReturn($organizationMock);

        // Ensure the ID is returned correctly
        $organizationMock->shouldReceive('getAttribute')
            ->with('id')
            ->andReturn($org_id);

        $organizationMock->shouldReceive('where')
            ->with('id', $org_id)
            ->andReturnSelf();
        $organizationMock->shouldReceive('first')
            ->andReturn($organizationMock);
        $organizationMock->shouldReceive('users')
            ->andReturn($usersMock);

        $usersMock->shouldReceive('find')
            ->with($user_id)
            ->andReturn(null);

        $organizationMock->name = 'Test Organization';

        // Bind the mock instance in the container
        $this->app->instance(Organization::class, $organizationMock);

        // Perform the request
        $response = $this->json('GET', "/api/organization/{$org_id}/user/{$user_id}");

        $response->assertStatus(404)
            ->assertJson([
                'error' => [
                    'status' => 404,
                    'title'  => 'Not Found',
                    'detail' => 'User not found for Test Organization',
                ],
            ]);
    }
}
