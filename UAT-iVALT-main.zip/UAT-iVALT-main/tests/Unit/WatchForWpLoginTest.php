<?php

namespace Tests\Unit;

use Mockery;
use Tests\TestCase;

class WatchForWpLoginTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function test_Missing_Required_Parameters()
    {
        $data = [];

        $response = $this->json('POST', '/api/wp/watch-for-login', $data);

        // Assert
        $response->assertStatus(400)
            ->assertJson([
                'error' => [
                    'status' => 400,
                    'title'  => 'Missing Required Parameters',
                ],
            ]);
    }

    public function test_User_Authentication_Success()
    {
        $data = [
            'country_code' => '91',
            'mobile'       => '9876543210',
            'email'        => 'test@example.com',
            'domain'       => 'example.com',
        ];

        // Mock the WpUser model
        $wpUserMock = Mockery::mock('alias:App\Models\WpUser');
        $wpUserMock->shouldReceive('firstWhere')
            ->andReturn((object) [
                'app_auth_status' => 'true',
                'user_token'      => 'abc123',
            ]);
        $wpUserMock->shouldReceive('where')
            ->andReturn($wpUserMock);
        $wpUserMock->shouldReceive('update')
            ->andReturn(true);

        // Act
        $response = $this->json('POST', '/api/wp/watch-for-login', $data);

        // Assert
        $response->assertStatus(200)
            ->assertJson([
                'data' => [
                    'status'   => 'true',
                    'message'  => 'Authentication Successful.',
                ],
            ]);
    }

    public function test_User_Authentication_Failure()
    {
        $data = [
            'country_code' => '91',
            'mobile'       => '9876543210',
            'email'        => 'test@example.com',
            'domain'       => 'example.com',
        ];

        // Mock the WpUser model
        $wpUserMock = Mockery::mock('alias:App\Models\WpUser');
        $wpUserMock->shouldReceive('firstWhere')
            ->andReturn((object) [
                'app_auth_status' => 'true',
                'user_token'      => 'abc123',
            ]);
        $wpUserMock->shouldReceive('where')
            ->andReturn($wpUserMock);
        $wpUserMock->shouldReceive('update')
            ->andReturn(false); // Simulate failed update

        // Act
        $response = $this->json('POST', '/api/wp/watch-for-login', $data);

        // Assert
        $response->assertStatus(403)
            ->assertJson([
                'error' => [
                    'status' => 403,
                    'title'  => 'Authentication failed!',
                    'detail' => 'User authentication failed!',
                ],
            ]);
    }

    public function test_User_Not_Found_Or_Invalid_Status()
    {
        $data = [
            'country_code' => '91',
            'mobile'       => '9876543210',
            'email'        => 'test@example.com',
            'domain'       => 'example.com',
        ];

        // Mock the WpUser model
        $wpUserMock = Mockery::mock('alias:App\Models\WpUser');
        $wpUserMock->shouldReceive('firstWhere')
            ->andReturn(null); // Simulate user not found

        // Act
        $response = $this->json('POST', '/api/wp/watch-for-login', $data);

        // Assert
        $response->assertStatus(422)
            ->assertJson([
                'error' => [
                    'status' => 422,
                    'title'  => 'Unprocessable Request',
                ],
            ]);
    }
}
