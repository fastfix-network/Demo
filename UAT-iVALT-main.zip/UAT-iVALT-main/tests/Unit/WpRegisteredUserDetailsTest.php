<?php

namespace Tests\Unit;

use Mockery;
use Tests\TestCase;

class WpRegisteredUserDetailsTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function test_missing_required_parameters()
    {
        // Send a request without the 'imei' parameter
        $response = $this->json('POST', '/api/wp/registered-user-details', []);

        // Assert that the response status is 400 and the error message is correct
        $response->assertStatus(400)->assertJson([
            'error' => [
                'status' => 400,
                'title'  => 'Missing Required Parameters',
                'detail' => 'The IMEI is required.',
            ],
        ]);
    }

    public function test_imei_not_found()
    {
        // Mock the UserDeviceTokens model to return an empty collection
        $userDeviceTokensMock = Mockery::mock('alias:App\Models\UserDeviceTokens');
        $userDeviceTokensMock->shouldReceive('where')->with('imei', 'nonexistent_imei')->andReturnSelf();
        $userDeviceTokensMock->shouldReceive('get')->andReturn(collect());

        // Send a request with a non-existent IMEI
        $response = $this->json('POST', '/api/wp/registered-user-details', ['imei' => 'nonexistent_imei']);

        // Assert that the response status is 404 and the error message is correct
        $response->assertStatus(404)->assertJson([
            'error' => [
                'status' => 404,
                'title'  => 'Not Found',
                'detail' => 'The IMEI provided (nonexistent_imei) is not registered with iValt.',
            ],
        ]);
    }

    public function test_successful_authentication()
    {
        // Mock the UserDeviceTokens model to return a collection with a single item
        $userDeviceTokensMock = Mockery::mock('alias:App\Models\UserDeviceTokens');
        $userDeviceTokensMock->shouldReceive('where')->with('imei', 'valid_imei')->andReturnSelf();
        $userDeviceTokensMock->shouldReceive('get')->andReturn(collect([(object) ['user_id' => 1]]));

        // Mock the User model to return the user details
        $userMock = Mockery::mock('alias:App\Models\User');
        $userMock->shouldReceive('where')->with('id', '=', 1)->andReturnSelf();
        $userMock->shouldReceive('get')->andReturn(collect([(object) ['id' => 1, 'name' => 'John Doe']]));

        // Send a request with a valid IMEI
        $response = $this->json('POST', '/api/wp/registered-user-details', ['imei' => 'valid_imei']);

        // Assert that the response status is 200 and the correct user details are returned
        $response->assertStatus(200)->assertJson([
            'data' => [
                'message' => 'Authentication successful.',
            ],
        ]);
    }
}
