<?php

namespace Tests\Unit;

use Mockery;
use Tests\TestCase;

class DeleteOrganizationGeoFencesTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function test_organization_not_found()
    {
        $orgId = 1;
        $geoFencesId = 1;

        // Mock Organization model
        $organizationMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $organizationMock->shouldReceive('find')->with($orgId)->andReturn(null);

        // Make the request
        $response = $this->json('DELETE', "/api/organization/{$orgId}/delete/geo-fence/{$geoFencesId}");

        // Assert the response
        $response->assertStatus(404)->assertJson([
            'error' => [
                'title'  => 'Not Found',
                'detail' => 'Organization not found',
            ],
        ]);
    }

    public function test_geo_fence_not_found()
    {
        $orgId = 1;
        $geoFencesId = 1;

        // Mock Organization model
        $organizationMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $organizationMock->shouldReceive('find')->with($orgId)->andReturn($organizationMock);

        // Mock geoGeoFences() relationship
        $geoFencesMock = Mockery::mock('alias:App\Models\Organization\OrganizationGeoFences');
        $organizationMock->shouldReceive('geoGeoFences')->andReturn($geoFencesMock);
        $geoFencesMock->shouldReceive('find')->with($geoFencesId)->andReturn(null);

        // Make the request
        $response = $this->json('DELETE', "/api/organization/{$orgId}/delete/geo-fence/{$geoFencesId}");

        // Assert the response
        $response->assertStatus(404)->assertJson([
            'error' => [
                'title'  => 'Not Found',
                'detail' => 'Geo fences not found.',
            ],
        ]);
    }

    public function test_geo_fence_deletion_success()
    {
        $orgId = 1;
        $geoFencesId = 1;

        $orgModelMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $orgModelMock->shouldReceive('find')->with($orgId)->andReturn($orgModelMock);
        $geoFencesMock = Mockery::mock('alias:App\Models\Organization\OrganizationGeoFences');
        $orgModelMock->shouldReceive('geoGeoFences')->andReturn($geoFencesMock);

        $geoFencesMock->shouldReceive('find')->with($geoFencesId)->andReturn($geoFencesMock);
        $geoFencesMock->id = $geoFencesId;
        $geoFencesMock->shouldReceive('delete')->andReturn(true);

        // Make the request
        $response = $this->json('DELETE', "/api/organization/{$orgId}/delete/geo-fence/{$geoFencesId}");

        // Assert the response
        $response->assertStatus(200)->assertJson([
            'data' => [
                'status'  => true,
                'message' => 'Geo fences deleted successfully.',
            ],
        ]);
    }
}
