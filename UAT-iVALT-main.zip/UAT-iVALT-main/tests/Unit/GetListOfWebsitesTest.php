<?php

namespace Tests\Unit;

use Mockery;
use Tests\TestCase;

class GetListOfWebsitesTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function test_missing_required_parameters()
    {
        $response = $this->json('POST', '/api/backup/wp/websites', []);

        $response->assertStatus(400)->assertJson([
            'error' => [
                'status' => 400,
                'title'  => 'Missing Required Parameters',
                'detail' => 'Mobile number is required.',
            ],
        ]);
    }

    public function test_websites_not_found()
    {
        // Mock the WpUser model
        $wpUserMock = Mockery::mock('alias:App\Models\WpUser');
        $wpUserMock->shouldReceive('where')->with('mobile', 'nonexistent_mobile')->andReturnSelf();
        $wpUserMock->shouldReceive('count')->andReturn(0);

        // Send a POST request with a mobile number that does not exist
        $response = $this->json('POST', '/api/backup/wp/websites', ['mobile' => 'nonexistent_mobile']);

        $response->assertStatus(200)->assertJson([
            'data' => [
                'message' => 'Websites not found.',
            ],
        ]);
    }

    public function test_websites_found()
    {
        // Mock the WpUser model
        $wpUserMock = Mockery::mock('alias:App\Models\WpUser');
        $wpUserMock->shouldReceive('where')->with('mobile', 'valid_mobile')->andReturnSelf();
        $wpUserMock->shouldReceive('count')->andReturn(1);

        // Define what `get` should return
        $wpUserMock->shouldReceive('get')->andReturn(collect([
            ['website' => 'example.com'],
            ['website' => 'another-example.com'],
        ]));

        // Send a POST request with a mobile number that exists
        $response = $this->json('POST', '/api/backup/wp/websites', ['mobile' => 'valid_mobile']);

        $response->assertStatus(200)->assertJson([
            'data' => [

                'message' => 'Websites found.',
            ],
        ]);
    }
}
