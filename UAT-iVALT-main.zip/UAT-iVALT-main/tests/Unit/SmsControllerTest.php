<?php

namespace Tests\Unit;

use App\Http\Controllers\SmsController;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Mockery;
use Tests\TestCase;

class SmsControllerTest extends TestCase
{
    protected $smsServiceMock;

    protected $smsAttemptMock;

    protected $dbMock;

    protected function setUp(): void
    {
        parent::setUp();

        $this->smsServiceMock = Mockery::mock('App\Services\SmsService');
        $this->smsAttemptMock = Mockery::mock('alias:App\Models\SMSAttempt');
        $this->dbMock = Mockery::mock('alias:Illuminate\Support\Facades\DB');
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function testSendOTPCodeSMSNewRecord()
    {
        $request = Request::create('wp/send/sms', 'POST', ['mobile' => '1234567890']);
        $request->setLaravelSession(Mockery::mock('Illuminate\Session\Store'));

        $this->smsAttemptMock->shouldReceive('where')->with('phone_number', '1234567890')->andReturnSelf();
        $this->smsAttemptMock->shouldReceive('where')->with('ip_address', Mockery::any())->andReturnSelf();
        $this->smsAttemptMock->shouldReceive('first')->andReturnNull();

        $this->smsAttemptMock->shouldReceive('create')->with(Mockery::on(function ($data) {
            return $data['phone_number'] == '1234567890' && $data['attempt_count'] == 1;
        }));

        $this->dbMock->shouldReceive('table')->with('register_otps')->andReturnSelf();
        $this->dbMock->shouldReceive('insert')->with(Mockery::on(function ($data) {
            return $data['mobile'] == '1234567890' && isset($data['otp']);
        }));

        $this->smsServiceMock->shouldReceive('sendSMS')->andReturn(response()->json(['status' => 'success'], 200));

        $controller = Mockery::mock(SmsController::class, [$this->smsServiceMock])->makePartial();
        $controller->shouldReceive('sendOTPCodeSMS')->with($request)->once()->andReturn(response()->json(['status' => 'success'], 200));
        $response = $controller->sendOTPCodeSMS($request);

        $this->assertEquals(200, $response->getStatusCode());
    }

    public function testSendOTPCodeSMSExistingRecordExceededLimit()
    {
        $request = Request::create('wp/send/sms', 'POST', ['mobile' => '1234567890']);
        $request->setLaravelSession(Mockery::mock('Illuminate\Session\Store'));

        $smsAttempt = (object) [
            'phone_number'      => '1234567890',
            'ip_address'        => $request->ip(),
            'last_attempt_date' => Carbon::now()->subHours(1),
            'attempt_count'     => 10,
            'save'              => function () {},
        ];

        $this->smsAttemptMock->shouldReceive('where')->with('phone_number', '1234567890')->andReturnSelf();
        $this->smsAttemptMock->shouldReceive('where')->with('ip_address', $request->ip())->andReturnSelf();
        $this->smsAttemptMock->shouldReceive('first')->andReturn($smsAttempt);

        $controller = new SmsController($this->smsServiceMock);
        $response = $controller->sendOTPCodeSMS($request);

        $this->assertEquals(429, $response->getStatusCode());
        $this->assertStringContainsString('Maximum number of SMS attempts reached for today.', $response->getContent());
    }

    public function testSendOTPCodeSMSSuccessful()
    {
        $request = Request::create('wp/send/sms', 'POST', ['mobile' => '1234567890']);
        $request->setLaravelSession(Mockery::mock('Illuminate\Session\Store'));

        $this->smsAttemptMock->shouldReceive('where')->with('phone_number', '1234567890')->andReturnSelf();
        $this->smsAttemptMock->shouldReceive('where')->with('ip_address', Mockery::any())->andReturnSelf();
        $this->smsAttemptMock->shouldReceive('first')->andReturnNull();

        $this->smsAttemptMock->shouldReceive('create')->with(Mockery::on(function ($data) {
            return $data['phone_number'] == '1234567890' && $data['attempt_count'] == 1;
        }));

        $this->dbMock->shouldReceive('table')->with('register_otps')->andReturnSelf();
        $this->dbMock->shouldReceive('insert')->with(Mockery::on(function ($data) {
            return $data['mobile'] == '1234567890' && isset($data['otp']);
        }));

        $this->smsServiceMock->shouldReceive('sendSMS')->andReturn(response()->json(['status' => 'success'], 200));

        $controller = Mockery::mock(SmsController::class, [$this->smsServiceMock])->makePartial();
        $controller->shouldReceive('sendOTPCodeSMS')->with($request)->once()->andReturn(response()->json(['status' => 'success'], 200));
        $response = $controller->sendOTPCodeSMS($request);

        $this->assertEquals(200, $response->getStatusCode());
    }
}
