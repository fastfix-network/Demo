<?php

namespace Tests\Unit;

use Mockery;
use Tests\TestCase;

class UserTimeslotsListUpdateTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function test_user_not_found()
    {
        // Arrange
        $userId = 1;

        // Mock User::find() to return null
        $userMock = Mockery::mock('alias:App\Models\User');
        $userMock->shouldReceive('find')
            ->with($userId)
            ->andReturn(null);

        // Act: Perform the API call
        $response = $this->json('PUT', "/api/user/{$userId}/timeslots/update");

        // Assert: Check that the response indicates the user was not found
        $response->assertStatus(404)
            ->assertJson([
                'error' => [
                    'status' => 404,
                    'detail' => 'User not found',
                ],
            ]);
    }

    public function test_missing_required_parameters()
    {
        // Arrange
        $userId = 1;

        // Mock User::find() to return a user instance
        $userMock = Mockery::mock('alias:App\Models\User');
        $userMock->shouldReceive('find')
            ->with($userId)
            ->andReturn($userMock);

        // Act: Perform the API call without required parameters
        $response = $this->json('PUT', "/api/user/{$userId}/timeslots/update", []);

        // Assert: Check that the response indicates missing required parameters
        $response->assertStatus(400)
            ->assertJson([
                'error' => [
                    'status' => 400,
                    'title'  => 'Missing Required Parameters',
                ],
            ]);
    }

    public function test_successful_timeslot_update()
    {
        // Arrange
        $userId = 1;
        $timeslotIds = [1, 2, 3];

        // Mock User::find() to return a user instance
        $userMock = Mockery::mock('alias:App\Models\User');
        $orgTimeSlotsMock = Mockery::mock('alias:App\Models\Organization\TimeSlot');
        $userMock->shouldReceive('find')
            ->with($userId)
            ->andReturn($userMock);

        // Mock orgTimeSlots() relationship detach and attach methods

        $orgTimeSlotsMock->shouldReceive('detach')->once();
        $orgTimeSlotsMock->shouldReceive('attach')->with($timeslotIds)->once();
        $userMock->shouldReceive('orgTimeSlots')->andReturn($orgTimeSlotsMock);

        // Mock orgTimeSlots relationship to return the updated timeslots
        $orgTimeSlotsMock->shouldReceive('get')->andReturn($timeslotIds);
        $userMock->shouldReceive('getRelationValue')->with('orgTimeSlots')->andReturn($timeslotIds);

        // Act: Perform the API call with required parameters
        $response = $this->json('PUT', "/api/user/{$userId}/timeslots/update", ['timeslot_ids' => $timeslotIds]);

        // Assert: Check that the response indicates a successful update
        $response->assertStatus(200)
            ->assertJson([
                'data' => [
                    'status'  => true,
                    'message' => 'Org timeslots list.',
                ],

            ]);
    }
}
