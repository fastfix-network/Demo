<?php

namespace Tests\Unit;

use Mockery;
use Tests\TestCase;

class GetOrganizationUserDetailsTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function test_missing_required_parameters()
    {
        // Mock the request object without required parameters
        $response = $this->json('POST', '/api/organization/user/details', []);

        $response->assertStatus(400)->assertJson([
            'error' => [
                'status' => '400',
                'title'  => 'Missing Required Parameters',

            ],
        ]);
    }

    public function test_invalid_client_id()
    {
        $clientId = 'invalid-client-id';

        // Mock the OrganizationAuthCode model and its relations
        $organizationAuthCodeMock = Mockery::mock('alias:App\Models\Organization\OrganizationAuthCode');
        $organizationAuthCodeMock->shouldReceive('with')->with('organization')->andReturnSelf();
        $organizationAuthCodeMock->shouldReceive('where')->with(['client_id' => $clientId])->andReturnSelf();
        $organizationAuthCodeMock->shouldReceive('whereHas')->with('organization')->andReturnSelf();
        $organizationAuthCodeMock->shouldReceive('first')->andReturn(null);

        // Send request with only the 'client_id' parameter
        $response = $this->json('POST', '/api/organization/user/details', [
            'client_id' => $clientId,
        ]);

        // Check for the expected error response
        $response->assertStatus(400)->assertJson([
            'error' => [
                'title'  => 'Invalid details',
                'detail' => 'Invalid client id',
            ],
        ]);
    }

    public function test_successful_details_fetch()
    {
        $clientId = 'valid-client-id';

        // Mock the Organization model
        $organizationMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $organizationMock->shouldReceive('unsetRelation')
            ->with('users')
            ->andReturnSelf();
        $organizationMock->shouldReceive('only')
            ->with(['name', 'organization_code', 'is_active'])
            ->andReturn([
                'name'              => 'Test Organization',
                'organization_code' => 'TEST123',
                'is_active'         => true,
            ]);

        // Mock the OrganizationAuthCode model and its relations
        $organizationAuthCodeMock = Mockery::mock('alias:App\Models\Organization\OrganizationAuthCode');
        $organizationAuthCodeMock->shouldReceive('with')
            ->with('organization')
            ->andReturnSelf();
        $organizationAuthCodeMock->shouldReceive('where')
            ->with(['client_id' => $clientId])
            ->andReturnSelf();
        $organizationAuthCodeMock->shouldReceive('whereHas')
            ->with('organization')
            ->andReturnSelf();
        $organizationAuthCodeMock->shouldReceive('first')
            ->andReturn((object) [
                'organization'  => $organizationMock,
                'client_id'     => $clientId,
                'client_secret' => 'secret',
            ]);

        // Mocking the request to the API endpoint
        $response = $this->json('POST', '/api/organization/user/details', [
            'client_id'    => $clientId,
            'mobile'       => '1234567890',
            'country_code' => '91',
            'name'         => 'John Doe',
            'platform'     => 'Android',
            'email'        => 'john.doe@example.com',
            'imei'         => '123456789012345',
            'device_token' => 'some_device_token',
            'user_code'    => 'user123',
            'is_admin'     => true,
        ]);

        // Asserting the response status and structure
        $response->assertStatus(200)->assertJson([
            'data' => [
                'status'  => 'true',
                'message' => 'Details fetched successfully',

            ],
        ]);
    }
}
