<?php

namespace Tests\Unit;

use App\Services\EmailService;
use Mockery;
use Tests\TestCase;

class WordpressRegisterTest extends TestCase
{
    protected string $apiRoute;
    protected array $validPayload;

    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();

        $this->apiRoute = route('api.wordpress.register.for.wordpress');
        $this->validPayload = [
            'country_code' => '91',
            'mobile'       => '1234567890',
            'email'        => 'test@test.com',
            'domain'       => 'test.com',
        ];
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function test_missing_required_parameters()
    {
        $response = $this->json('POST', $this->apiRoute, []);

        $response->assertStatus(400)
            ->assertJson([
                'error' => [
                    'status' => 400,
                    'title'  => 'Missing Required Parameters',
                ],
            ]);
    }

    public function test_user_not_found()
    {
        // Mock the EmailService
        $emailServiceMock = Mockery::mock(EmailService::class);

        // Mock the User model to return null when first() is called
        $userMock = Mockery::mock('alias:App\Models\User');
        $userMock->shouldReceive('with')->with('device_tokens')->andReturnSelf();
        $userMock->shouldReceive('where')->with(['country_code' => $this->validPayload['country_code'], 'mobile' => $this->validPayload['mobile']])->andReturnSelf();
        $userMock->shouldReceive('first')->andReturn(null);

        // Mock the WordpressApiController with enabled protected method mocking
        $wordpressApiControllerMock = Mockery::mock('App\Http\Controllers\WordpressApiController[getFCMApiKey]', [$emailServiceMock])
            ->shouldAllowMockingProtectedMethods();

        // Mock getFCMApiKey method
        $wordpressApiControllerMock->shouldReceive('getFCMApiKey')->andReturn('mock-fcm-api-key');

        // Replace the WordpressApiController in the IoC container
        $this->app->instance('App\Http\Controllers\WordpressApiController', $wordpressApiControllerMock);

        $userAppLogsMock = Mockery::mock('alias:App\Models\UserAppLogs');
        $userAppLogsMock->shouldReceive('create')->andReturn(true);

        // Mock global function
        $functionsMock = Mockery::mock('alias:functions');
        $functionsMock->shouldReceive('saveAppLog')
            ->with($this->validPayload['mobile'], 'Registered in '.$this->validPayload['domain'])
            ->andReturn(true);

        $response = $this->json('POST', $this->apiRoute, $this->validPayload);

        $response->assertStatus(404)
            ->assertJson([
                'error' => [
                    'status' => 404,
                    'title'  => 'Not Found',
                    'detail' => 'The mobile number provided ('.$this->validPayload['country_code'].$this->validPayload['mobile'].') was not found.',
                ],
            ]);
    }

    public function test_successful_registration_ivalt_user()
    {
        // Mock the EmailService
        $emailServiceMock = Mockery::mock(EmailService::class);

        // Mock the User model to return a user when first() is called
        $userMock = Mockery::mock('alias:App\Models\User');
        $userMock->shouldReceive('with')->with('device_tokens')->andReturnSelf();
        $userMock->shouldReceive('where')->with(['country_code' => $this->validPayload['country_code'], 'mobile' => $this->validPayload['mobile']])->andReturnSelf();
        $userMock->shouldReceive('first')->andReturnSelf();

        // Mock the WordpressApiController with enabled protected method mocking
        $wordpressApiControllerMock = Mockery::mock('App\Http\Controllers\WordpressApiController[getFCMApiKey]', [$emailServiceMock])
            ->shouldAllowMockingProtectedMethods();

        // Mock getFCMApiKey method
        $wordpressApiControllerMock->shouldReceive('getFCMApiKey')->andReturn('mock-fcm-api-key');

        // Replace the WordpressApiController in the IoC container
        $this->app->instance('App\Http\Controllers\WordpressApiController', $wordpressApiControllerMock);

        $userAppLogsMock = Mockery::mock('alias:App\Models\UserAppLogs');
        $userAppLogsMock->shouldReceive('create')->andReturn(true);

        // Mock global function
        $functionsMock = Mockery::mock('alias:functions');
        $functionsMock->shouldReceive('saveAppLog')
            ->with($this->validPayload['mobile'], 'Registered in '.$this->validPayload['domain'])
            ->andReturn(true);

        // Mock NotificationController
        $notificationControllerMock = Mockery::mock('alias:App\Http\Controllers\NotificationController');
        $notificationControllerMock->shouldReceive('registerForWpSendNotifications')
            ->with(Mockery::any(), Mockery::any(), Mockery::any(), Mockery::any(), 'iVALT')
            ->andReturn(true);

        $wpUserMock = Mockery::mock('alias:App\Models\WpUser');
        $wpUserMock->shouldReceive('where')->andReturnSelf();
        $wpUserMock->shouldReceive('delete')->andReturn(true);

        $userToken = 'k7zl1Ls5MBepJUaBwLRo';
        $wpUserMock->shouldReceive('create')
            ->withArgs(function ($args) use ($userToken) {
                return $args['country_code'] === $this->validPayload['country_code']
                    && $args['mobile'] === $this->validPayload['mobile']
                    && $args['email'] === $this->validPayload['email']
                    && $args['website'] === $this->validPayload['domain']
                    && $args['user_token'] = $userToken;
            })
            ->andReturn(true);

        $response = $this->json('POST', $this->apiRoute, $this->validPayload);

        $response->assertStatus(200)
            ->assertJson([
                'data' => [
                    'status'  => true,
                    'message' => 'Biometric Auth Request successfully sent.',
                ],
            ]);
    }
}
