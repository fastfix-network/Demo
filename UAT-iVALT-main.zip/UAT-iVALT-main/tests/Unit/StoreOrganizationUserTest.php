<?php

namespace Tests\Unit;

use App\Models\Organization\Organization;
use App\Models\User;
use Mockery;
use Tests\TestCase;

// use App\Http\Controllers\Auth0ApiController;

class StoreOrganizationUserTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function test_Missing_Required_Parameters()
    {
        $orgId = 1;

        $orgMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $orgMock->shouldReceive('find')->with($orgId)->andReturn($orgMock);

        $response = $this->json('POST', '/api/organization/'.$orgId.'/create/user', []);

        $response->assertStatus(400)
            ->assertJson([
                'error' => [
                    'status' => 400,
                    'title'  => 'Missing Required Parameters',
                ],
            ]);
    }

    public function test_Organization_Not_Found()
    {
        $orgId = 1; // Non-existent organization ID

        $orgMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $orgMock->shouldReceive('find')->with($orgId)->andReturn(null);

        $response = $this->json('POST', '/api/organization/'.$orgId.'/create/user', []);

        $response->assertStatus(404)
            ->assertJson([
                'error' => [
                    'status' => 404,
                    'title'  => 'Not Found',
                    'detail' => 'Organization not found',
                ],
            ]);
    }

    public function test_User_Creation_Success()
    {
        $orgId = 1;
        $data = [
            'mobile'              => '9876543210',
            'country_code'        => '91',
            'name'                => 'Test User',
            'platform'            => 'iOS',
            'email'               => 'testuser@example.com',
            'imei'                => '123456789012345',
            'device_token'        => 'abc123',
            'user_code'           => 'USER001',
            'is_admin'            => true,
            'auth0_user_password' => 'password',
        ];

        // Mock Organization model
        $orgMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $orgMock->shouldReceive('find')->with($orgId)->andReturn($orgMock);
        $orgMock->shouldReceive('users')->andReturn($orgMock);
        $orgMock->shouldReceive('create')->andReturn(Mockery::self());
        $orgMock->shouldReceive('update')->andReturn(true);
        $orgMock->id = 1;
        // Mock Auth0 user creation
        $auth0Mock = Mockery::mock('alias:App\Http\Controllers\Auth0\Auth0ApiController');
        $auth0Mock->shouldReceive('checkIfUserExistOnAuth0')
            ->andReturn(['statusCode' => 404, 'error' => 'Not Found']);
        $auth0Mock->shouldReceive('createUser')
            ->andReturn(['user_id' => 'auth0|12345']);

        // Act
        $response = $this->json('POST', '/api/organization/'.$orgId.'/create/user', $data);

        // Assert
        $response->assertStatus(200)
            ->assertJson([
                'data' => [
                    'status'  => true,
                    'message' => 'User created successfully.',
                ],
            ]);
    }

    public function test_User_Creation_Failure()
    {
        $orgId = 1;
        $data = [
            'mobile'              => '9876543210',
            'country_code'        => '91',
            'name'                => 'Test User',
            'platform'            => 'iOS',
            'email'               => 'testuser@example.com',
            'imei'                => '123456789012345',
            'device_token'        => 'abc123',
            'user_code'           => 'USER001',
            'is_admin'            => true,
            'auth0_user_password' => 'password',
        ];

        // Mock Organization model
        $orgMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $orgMock->shouldReceive('find')->with($orgId)->andReturn($orgMock);
        $orgMock->shouldReceive('users')->andReturn($orgMock);
        $orgMock->shouldReceive('create')->andReturn(Mockery::self());
        $orgMock->shouldReceive('update')->andReturn(true);
        $orgMock->id = 1;

        // Mock Auth0 user creation fails
        $auth0Mock = Mockery::mock('alias:App\Http\Controllers\Auth0\Auth0ApiController');
        $auth0Mock->shouldReceive('checkIfUserExistOnAuth0')
            ->andReturn(['statusCode' => 404, 'error' => 'Not Found']); // User doesn't exist
        $auth0Mock->shouldReceive('createUser')
            ->andReturn([]); // Simulate failure by returning an empty response

        // Act
        $response = $this->json('POST', '/api/organization/'.$orgId.'/create/user', $data);

        // Assert
        $response->assertStatus(404)
            ->assertJson([
                'error' => [
                    'status' => 404,
                    'title'  => 'Operation failed',
                    'detail' => 'Something went wrong!',
                ],
            ]);
    }
}
