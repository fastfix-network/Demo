<?php

namespace Tests\Unit;

use Mockery;
use Tests\TestCase;

class RegisterUserTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function test_Missing_Required_Parameters()
    {
        $data = []; // Missing all required parameters

        $response = $this->json('POST', '/api/wp/register/mobile/user', $data);

        $response->assertStatus(400)
            ->assertJson([
                'error' => [
                    'status' => 400,
                    'title'  => 'Missing Required Parameters',
                ],

            ]);
    }

    public function test_New_User_Registration()
    {
        $data = [
            'mobile'       => '9876543210',
            'country_code' => '91',
            'name'         => 'Test User',
            'platform'     => 'ios',
            'email'        => 'testuser@example.com',
            'imei'         => '1234567890',
            'device_token' => 'test_token',
            'user_code'    => '12345',
        ];

        // Mock User model to return null for a new user
        $userMock = Mockery::mock('alias:App\Models\User');
        $userMock->shouldReceive('where')->andReturnSelf();
        $userMock->shouldReceive('first')->andReturn(null);
        $userMock->shouldReceive('insertGetId')->andReturn(1);

        $response = $this->json('POST', '/api/wp/register/mobile/user', $data);

        $response->assertStatus(200)
            ->assertJson([
                'data' => [
                    'message' => 'User registered successfully.',
                ],
            ]);
    }

    // Test Case 3: Existing User Update with Same Email
    public function test_Existing_User_Update_With_Same_Email()
    {
        $data = [
            'mobile'       => '9876543210',
            'country_code' => '91',
            'name'         => 'Test User',
            'platform'     => 'android',
            'email'        => 'testuser@example.com',
            'imei'         => '1234567890',
            'device_token' => 'test_token',
            'user_code'    => '12345',
        ];

        // Mock User model to return existing user data
        $userMock = Mockery::mock('alias:App\Models\User');
        $userMock->shouldReceive('where')->andReturnSelf();
        $userMock->shouldReceive('first')->andReturn((object) $data);
        $userMock->shouldReceive('update')->andReturn(true);

        $this->app->instance('App\Models\User', $userMock);

        $response = $this->json('POST', '/api/wp/register/mobile/use', $data);

        $response->assertStatus(200)
            ->assertJson(['message' => 'Welcome! Test User. Please verify your email to continue using iVALT.']);
    }
    // /**
    //  * Test case for invalid platform.
    //  */
    // public function test_invalid_platform()
    // {
    //     $requestData = [
    //         'mobile'       => '1234567890',
    //         'country_code' => '+91',
    //         'name'         => 'Test User',
    //         'platform'     => 'windows', // Invalid platform
    //         'email'        => 'test@example.com',
    //         'imei'         => '123456789012345',
    //         'device_token' => 'valid_device_token',
    //         'user_code'    => 'test_code',
    //     ];

    //     $response = $this->postJson('/api/wp/register/mobile/user', $requestData);

    //     $response->assertStatus(422)
    //         ->assertJson([
    //             'error' => [
    //                 'title'  => 'Invalid Platform',
    //                 'detail' => 'The platform provided is not valid.',
    //             ],
    //         ]);
    // }

    public function test_valid_registration()
    {
        $requestData = [
            'mobile'       => '1234567890',
            'country_code' => '+91',
            'name'         => 'Test User',
            'platform'     => 'android',
            'email'        => 'test@example.com',
            'imei'         => '123456789012345',
            'device_token' => 'valid_device_token',
            'user_code'    => 'test_code',
        ];

        // Mocking the User model
        $userMock = Mockery::mock('overload:App\Models\User');

        $userMock->shouldReceive('where')
            ->with(['country_code' => '+91', 'mobile' => '1234567890'])
            ->andReturnSelf();

        $userMock->shouldReceive('first')->andReturnNull(); // No existing user

        $userMock->shouldReceive('insertGetId')->andReturn(1); // New user ID

        // Mocking the UserDeviceTokens model
        $userDeviceTokenMock = Mockery::mock('overload:App\Models\UserDeviceTokens');

        $userDeviceTokenMock->shouldReceive('create')->andReturn(true);

        // Mocking the EmailService method
        // $this->emailService->shouldReceive('sendMobileAppVerificationEmail')
        //     ->once()
        //     ->with('test@example.com', Mockery::type('string'), Mockery::type('string'))
        //     ->andReturn(true);

        $response = $this->postJson('/api/wp/register/mobile/user', $requestData);

        $response->assertStatus(200)
            ->assertJson([
                'data' => [
                    'message' => 'User registered successfully.',
                ],
            ]);
    }

    // /**
    //  * Test case for an existing user registration.
    //  */
    // public function test_existing_user_registration()
    // {
    //     $requestData = [
    //         'mobile'       => '1234567890',
    //         'country_code' => '+91',
    //         'name'         => 'Test User',
    //         'platform'     => 'android',
    //         'email'        => 'test@example.com',
    //         'imei'         => '123456789012345',
    //         'device_token' => 'valid_device_token',
    //         'user_code'    => 'test_code',
    //     ];

    //     $existingUser = (object) [
    //         'id'           => 1,
    //         'mobile'       => '1234567890',
    //         'country_code' => '+91',
    //         'email'        => 'test@example.com',
    //         'chain_id'     => null,
    //     ];

    //     // Mocking the User model
    //     $userMock = Mockery::mock('overload:App\Models\User');

    //     $userMock->shouldReceive('where')
    //         ->with(['country_code' => $requestData['country_code'], 'mobile' => $requestData['mobile']])
    //         ->andReturnSelf();

    //     $userMock->shouldReceive('first')->andReturn($existingUser); // Existing user

    //     // Mocking the update method
    //     $userMock->shouldReceive('update')->andReturn(true);

    //     // Mocking the UserDeviceTokens model
    //     $userDeviceTokenMock = Mockery::mock('overload:App\Models\UserDeviceTokens');

    //     $userDeviceTokenMock->shouldReceive('where')
    //         ->with(['user_id' => 1, 'imei' => '123456789012345'])
    //         ->andReturnSelf();

    //     $userDeviceTokenMock->shouldReceive('get')->andReturnSelf();

    //     $userDeviceTokenMock->shouldReceive('count')->andReturn(1);

    //     $userMock->shouldReceive('where')->with([
    //         'mobile' => $requestData['mobile'],
    //     ])->andReturnSelf();

    //     $userMock->shouldReceive('update')->andReturn(true);

    //     $userDeviceTokenMock->shouldReceive('where')->with([
    //         'user_id' => 1,
    //         'imei'    => '123456789012345',
    //     ])->andReturnSelf();

    //     $userDeviceTokenMock->shouldReceive('update')->andReturn(true);

    //     // Mocking the first method to return null (no existing device token)
    //     $userDeviceTokenMock->shouldReceive('first')->andReturnNull();

    //     // Mocking the create method for new device token
    //     $userDeviceTokenMock->shouldReceive('create')->andReturn(true);

    //     // Mocking the EmailService method
    //     $this->emailService->shouldReceive('sendMobileAppVerificationEmail')
    //         ->once()
    //         ->with($requestData['email'], Mockery::type('string'), Mockery::type('string'))
    //         ->andReturn(true);

    //     $response = $this->postJson('/api/wp/register/mobile/user', $requestData);

    //     $response->assertStatus(200)
    //         ->assertJson([
    //             'data' => [
    //                 'status'  => true,
    //                 'message' => 'User registered successfully.',
    //             ],
    //         ]);
    // }
}
