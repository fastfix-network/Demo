<?php

namespace Tests\Unit;

use Mockery;
use Tests\TestCase;

class WpSendNotificationTest extends TestCase
{
    /**
     * Set up the test environment.
     *
     * @return void
     */
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();

    }

    /**
     * Clean up the test environment.
     *
     * @return void
     */
    public function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    /**
     * Test missing mobile parameter.
     *
     * @return void
     */
    public function test_missing_required_parameter()
    {
        $response = $this->json('POST', 'api/wp/send-notification', []);

        $response->assertStatus(400)->assertJson([
            'error' => [
                'title'  => 'Missing Required Parameters',
                'status' => 400,
            ],
        ]);
    }

    /**
     * Test sending notification when user is not found.
     *
     * @return void
     */
    public function testSendNotificationFailureUserNotFound()
    {
        $requestData = [
            'country_code' => '1',
            'mobile'       => '1234567890',
            'domain'       => 'example.com',
            'email'        => 'test@example.com',
        ];

        // Mock the User model to return null when first() is called
        $userMock = Mockery::mock('alias:App\Models\User');
        $userMock->shouldReceive('with')->with('device_tokens')->andReturnSelf();
        $userMock->shouldReceive('where')->with(['country_code' => '1', 'mobile' => '1234567890'])->andReturnSelf();
        $userMock->shouldReceive('first')->andReturn(null);

        // Mock the EmailService
        $emailServiceMock = Mockery::mock('App\Services\EmailService');

        // Mock the WordpressApiController with enabled protected method mocking
        $wordpressApiControllerMock = Mockery::mock('App\Http\Controllers\WordpressApiController[getFCMApiKey]', [$emailServiceMock])
            ->shouldAllowMockingProtectedMethods();

        // Mock getFCMApiKey method
        $wordpressApiControllerMock->shouldReceive('getFCMApiKey')->andReturn('mock-fcm-api-key');

        // Replace the WordpressApiController in the IoC container
        $this->app->instance('App\Http\Controllers\WordpressApiController', $wordpressApiControllerMock);

        // Call the method
        $response = $this->json('POST', 'api/wp/send-notification', $requestData);

        // Assert the response for user not found
        $response->assertStatus(404)->assertJson([
            'error' => [
                'status'  => 404,
                'title'   => 'Not Found',
                'detail'  => 'The mobile number provided (11234567890) is not registered with iVALT.',
            ],
        ]);
    }

    /**
     * Test successful sending of notification.
     *
     * @return void
     */
    public function testSendNotificationSuccess()
    {
        $requestData = [
            'country_code' => '1',
            'mobile'       => '1234567890',
            'domain'       => 'example.com',
            'email'        => 'test@example.com',
        ];

        // Mock the User model
        $userMock = Mockery::mock('alias:App\Models\User');
        $userMock->shouldReceive('with')->with('device_tokens')->andReturnSelf();
        $userMock->shouldReceive('where')->with(['country_code' => '1', 'mobile' => '1234567890'])->andReturnSelf();
        $userMock->shouldReceive('first')->andReturn($userMock);

        // Mock NotificationController
        $notificationControllerMock = Mockery::mock('alias:App\Http\Controllers\NotificationController');
        $notificationControllerMock->shouldReceive('sendNotificationAuthStatus')
            ->with($userMock, 'iVALT', '1234567890', '1'.'1234567890'.' Authenticated Successfully.', '1'.'1234567890', true)
            ->once()
            ->andReturn(['success' => true]);

        // Mock the EmailService
        $emailServiceMock = Mockery::mock('App\Services\EmailService');

        // Mock the WordpressApiController with shouldAllowMockingProtectedMethods
        $wordpressApiControllerMock = Mockery::mock('App\Http\Controllers\WordpressApiController[getFCMApiKey]', [$emailServiceMock])
            ->shouldAllowMockingProtectedMethods();

        $wordpressApiControllerMock->shouldReceive('getFCMApiKey')->andReturn('mock-fcm-api-key');

        // Inject the mocked WordpressApiController into your test
        $this->app->instance('App\Http\Controllers\WordpressApiController', $wordpressApiControllerMock);

        // Call the method
        $response = $this->json('POST', 'api/wp/send-notification', $requestData);

        // Assert the response
        $response->assertStatus(200)->assertJson([
            'data' => [
                'status'  => true,
                'message' => 'Biometric Auth Request successfully sent.',
                'details' => [],
            ],
        ]);
    }
}
