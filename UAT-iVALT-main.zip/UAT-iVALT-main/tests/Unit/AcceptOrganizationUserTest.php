<?php

namespace Tests\Unit;

use Mockery;
use Tests\TestCase;

class AcceptOrganizationUserTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function test_organization_not_found()
    {
        $orgId = 1;
        $userId = 1;

        // Mock Organization model
        $orgModelMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $orgModelMock->shouldReceive('find')->with($orgId)->andReturn(null);

        $response = $this->json('POST', "/api/organization/{$orgId}/user/{$userId}/pending");

        $response->assertStatus(404)->assertJson([
            'error' => [
                'title'  => 'Not Found',
                'detail' => 'Organization not found',
            ],
        ]);
    }

    public function test_user_not_found_in_pending_users()
    {
        $orgId = 1;
        $userId = 1;

        // Mock Organization model
        $orgModelMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $orgModelMock->shouldReceive('find')->with($orgId)->andReturn($orgModelMock);

        // Mock pendingUsers() relationship
        $pendingUsersMock = Mockery::mock();
        $orgModelMock->shouldReceive('pendingUsers')->andReturn($pendingUsersMock);
        $pendingUsersMock->shouldReceive('find')->with($userId)->andReturn(null);

        $response = $this->json('POST', "/api/organization/{$orgId}/user/{$userId}/accept");

        $response->assertStatus(404)->assertJson([
            'error' => [
                'title'  => 'Not Found',
                'detail' => 'User not found',
            ],
        ]);
    }

    public function test_user_accepted_successfully()
    {
        $orgId = 1;
        $userId = 1;

        // Mock Organization model
        $orgModelMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $orgModelMock->shouldReceive('find')->with($orgId)->andReturn($orgModelMock);

        // Mock pendingUsers() relationship
        $pendingUsersMock = Mockery::mock();
        $orgModelMock->shouldReceive('pendingUsers')->andReturn($pendingUsersMock);
        $pendingUsersMock->shouldReceive('find')->with($userId)->andReturn((object) ['id' => $userId]);
        $pendingUsersMock->shouldReceive('detach')->with($userId)->andReturn(true);

        // Mock users() relationship
        $usersMock = Mockery::mock();
        $orgModelMock->shouldReceive('users')->andReturn($usersMock);
        $usersMock->shouldReceive('attach')->with($userId)->andReturn(true);

        $response = $this->json('POST', "/api/organization/{$orgId}/user/{$userId}/accept");

        $response->assertStatus(200)->assertJson([
            'data' => [
                'status'  => true,
                'message' => 'Operation successfully completed.',
            ],
        ]);
    }
}
