<?php

namespace Tests\Unit;

use Mockery;
use Tests\TestCase;

class UpdateOrganizationGeoFencesTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function test_successful_geo_fences_update()
    {
        $orgId = 1;
        $geoFencesId = 100;
        $updateData = [
            'name'      => 'Updated GeoFence',
            'latitude'  => '12.345678',
            'longitude' => '98.765432',
            'radius'    => '200',
            'is_active' => 1,
        ];

        // Mock Organization model and geoGeoFences relationship
        $orgModelMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $geoFencesMock = Mockery::mock('alias:App\Models\Organization\OrganizationGeoFences');

        $orgModelMock->shouldReceive('find')->with($orgId)->andReturn($orgModelMock);
        $orgModelMock->shouldReceive('geoGeoFences->find')->with($geoFencesId)->andReturn($geoFencesMock);
        $geoFencesMock->shouldReceive('update')->with(Mockery::subset($updateData))->andReturn(true);

        $response = $this->json('PUT', '/api/organization/'.$orgId.'/update/geo-fence/'.$geoFencesId, $updateData);

        $response->assertStatus(200)->assertJson([
            'data' => [
                'status'  => true,
                'message' => 'Geo fences updated successfully.',
            ],
        ]);
    }

    public function test_organization_not_found()
    {
        $orgId = 1;
        $geoFencesId = 100;
        $updateData = [
            'name'      => 'Updated GeoFence',
            'latitude'  => '12.345678',
            'longitude' => '98.765432',
            'radius'    => '200',
            'is_active' => true,
        ];

        $orgModelMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $orgModelMock->shouldReceive('find')->with($orgId)->andReturn(null);

        $response = $this->json('PUT', '/api/organization/'.$orgId.'/update/geo-fence/'.$geoFencesId, $updateData);

        $response->assertStatus(404)->assertJson([
            'error' => [
                'title'  => 'Not Found',
                'detail' => 'Organization not found',
            ],
        ]);
    }

    public function test_geo_fences_not_found()
    {
        $orgId = 1;
        $geoFencesId = 100;
        $updateData = [
            'name'      => 'Updated GeoFence',
            'latitude'  => '12.345678',
            'longitude' => '98.765432',
            'radius'    => '200',
            'is_active' => 1,
        ];

        $orgModelMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $geoFencesMock = Mockery::mock('alias:App\Models\Organization\OrganizationGeoFences');

        $orgModelMock->shouldReceive('find')->with($orgId)->andReturn($orgModelMock);
        $orgModelMock->shouldReceive('geoGeoFences->find')->with($geoFencesId)->andReturn(null);

        $response = $this->json('PUT', '/api/organization/'.$orgId.'/update/geo-fence/'.$geoFencesId, $updateData);

        $response->assertStatus(404)->assertJson([
            'error' => [
                'title'  => 'Not Found',
                'detail' => 'Geo fences not found.',
            ],
        ]);
    }

    public function test_geo_fences_not_updated()
    {
        $orgId = 1;
        $geoFencesId = 100;
        $updateData = [
            'name'      => 'Updated GeoFence',
            'latitude'  => '12.345678',
            'longitude' => '98.765432',
            'radius'    => '200',
            'is_active' => 1,
        ];

        // Mock Organization model and geoGeoFences relationship
        $orgModelMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $geoFencesMock = Mockery::mock('alias:App\Models\Organization\OrganizationGeoFences');
        $orgModelMock->name = 'Test ORG';
        $orgModelMock->shouldReceive('find')->with($orgId)->andReturn($orgModelMock);
        $orgModelMock->shouldReceive('geoGeoFences->find')->with($geoFencesId)->andReturn($geoFencesMock);
        $geoFencesMock->shouldReceive('getAttribute')->with('name')->andReturn('Test ORG');
        $geoFencesMock->shouldReceive('update')->with(Mockery::subset($updateData))->andReturn(false);

        $response = $this->json('PUT', '/api/organization/'.$orgId.'/update/geo-fence/'.$geoFencesId, $updateData);

        $response->assertStatus(404)->assertJson([
            'error' => [
                'title'  => 'Not Found',
                'detail' => 'Geo fences not updated for '.$orgModelMock->name,
            ],
        ]);
    }
}
