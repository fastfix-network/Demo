<?php

namespace Tests\Unit;

use App\Models\User;
use Mockery;
use Tests\TestCase;

class IsEmailVerifiedTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function test_missing_required_parameters()
    {
        $response = $this->json('POST', '/api/check-is-email-verified', [
            // No parameters provided
        ]);

        $response->assertStatus(400)->assertJson([
            'error' => [
                'status' => 400,
                'title'  => 'Missing Required Parameters',
            ],
        ]);
    }

    public function test_invalid_platform_provided()
    {
        $response = $this->json('POST', '/api/check-is-email-verified', [
            'country_code' => '91',
            'mobile'       => '1234567890',
            'platform'     => 'invalid_platform',
            'email'        => 'user@example.com',
        ]);

        $response->assertStatus(400)->assertJson([
            'error' => [
                'status' => 400,
                'title'  => 'Bad Request',
                'detail' => 'Provided platform is not valid.',
            ],
        ]);
    }

    public function test_email_not_found()
    {
        // Mocking the User model
        $userMock = Mockery::mock('alias:App\Models\User');
        $userMock->shouldReceive('where')
            ->with([
                'country_code' => '91',
                'mobile'       => '1234567890',
                'platform'     => 'android',
                'email'        => 'user@example.com',
            ])
            ->andReturnSelf();
        $userMock->shouldReceive('first')
            ->andReturn(null);

        $response = $this->json('POST', '/api/check-is-email-verified', [
            'country_code' => '91',
            'mobile'       => '1234567890',
            'platform'     => 'android',
            'email'        => 'user@example.com',
        ]);

        $response->assertStatus(404)->assertJson([
            'error' => [
                'status' => 404,
                'title'  => 'Not Found',
                'detail' => 'The email provided (user@example.com) was not found.',
            ],
        ]);
    }

    public function test_email_not_verified()
    {
        // Mocking the User model with an unverified email
        $userMock = Mockery::mock('alias:App\Models\User');
        $userMock->is_email_verified = 0;

        $userMock->shouldReceive('where')
            ->with([
                'country_code' => '91',
                'mobile'       => '1234567890',
                'platform'     => 'android',
                'email'        => 'user@example.com',
            ])
            ->andReturnSelf()
            ->shouldReceive('first')
            ->andReturn($userMock);

        $response = $this->json('POST', '/api/check-is-email-verified', [
            'country_code' => '91',
            'mobile'       => '1234567890',
            'platform'     => 'android',
            'email'        => 'user@example.com',
        ]);

        $response->assertStatus(404)->assertJson([
            'error' => [
                'status' => 404,
                'title'  => 'Not Found',
                'detail' => 'The email provided (user@example.com) has not been verified.',
            ],
        ]);
    }

    public function test_email_verified()
    {
        // Mocking the User model with a verified email
        $userMock = Mockery::mock('alias:App\Models\User');
        $userMock->is_email_verified = 1;
        $userMock->shouldReceive('toArray')->andReturn(['email' => 'user@example.com']);

        $userMock->shouldReceive('where')
            ->with([
                'country_code' => '91',
                'mobile'       => '1234567890',
                'platform'     => 'android',
                'email'        => 'user@example.com',
            ])
            ->andReturnSelf()
            ->shouldReceive('first')
            ->andReturn($userMock);

        $response = $this->json('POST', '/api/check-is-email-verified', [
            'country_code' => '91',
            'mobile'       => '1234567890',
            'platform'     => 'android',
            'email'        => 'user@example.com',
        ]);

        $response->assertStatus(200)->assertJson([
            'data' => [

                'message' => 'Email has been verified.',
            ],
        ]);
    }
}
