<?php

namespace Tests\Unit;

use Mockery;
use Tests\TestCase;

class ValidateGlobalAuthForAdminTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function test_missing_required_parameters()
    {
        $response = $this->json('POST', '/api/validate-admin-auth', []);

        $response->assertStatus(400)
            ->assertJson([
                'error' => [
                    'status' => 400,
                    'title'  => 'Missing Required Parameters',
                ],

            ]);
    }

    public function test_user_not_found()
    {
        $mobile = '1234567890';
        $webAuthMock = Mockery::mock('alias:App\Models\WebAuth');
        $webAuthMock->shouldReceive('where')
            ->with(['mobile_with_country_code' => $mobile])
            ->andReturnSelf();
        $webAuthMock->shouldReceive('first')
            ->andReturnNull();

        $userMock = Mockery::mock('alias:App\Models\User');
        $userMock->shouldReceive('where')
            ->with(['mobile_with_country_code' => $mobile])
            ->andReturnSelf();
        $userMock->shouldReceive('get')
            ->andReturn(collect([]));

        $response = $this->json('POST', '/api/validate-admin-auth', ['mobile' => $mobile]);

        $response->assertStatus(404)
            ->assertJson([
                'error' => [
                    'status' => 404,
                    'title'  => 'Not Found',
                ],
            ]);
    }

    public function test_web_auth_not_found()
    {
        $mobile = '1234567890';

        $userMock = Mockery::mock('alias:App\Models\User');
        $userMock->shouldReceive('where')
            ->with(['mobile_with_country_code' => $mobile])
            ->andReturnSelf();
        $userMock->shouldReceive('get')
            ->andReturn(collect(['name' => 'Test User']));

        $webAuthMock = Mockery::mock('alias:App\Models\WebAuth');
        $webAuthMock->shouldReceive('where')
            ->with(['mobile_with_country_code' => $mobile])
            ->andReturnSelf();
        $webAuthMock->shouldReceive('first')
            ->andReturnNull();

        $response = $this->json('POST', '/api/validate-admin-auth', ['mobile' => $mobile]);

        $response->assertStatus(422)
            ->assertJson([
                'error' => [
                    'status' => 422,
                    'title'  => 'Unprocessable Request',
                ],
            ]);
    }

    public function test_web_auth_invalid_state()
    {
        $mobile = '1234567890';

        $userMock = Mockery::mock('alias:App\Models\User');
        $userMock->shouldReceive('where')
            ->with(['mobile_with_country_code' => $mobile])
            ->andReturnSelf();
        $userMock->shouldReceive('get')
            ->andReturn(collect(['name' => 'Test User']));

        $webAuthMock = Mockery::mock('alias:App\Models\WebAuth');
        $webAuthMock->login_status = 0;
        $webAuthMock->shouldReceive('where')
            ->with(['mobile_with_country_code' => $mobile])
            ->andReturnSelf();
        $webAuthMock->shouldReceive('first')
            ->andReturn($webAuthMock);

        $response = $this->json('POST', '/api/validate-admin-auth', ['mobile' => $mobile]);

        $response->assertStatus(422)
            ->assertJson([
                'error' => [
                    'status' => 422,
                    'title'  => 'Unprocessable Request',
                ],
            ]);
    }

    public function test_successful_authentication()
    {
        $mobile = '1234567890';

        // Create a mock of the User model with expected properties
        $userMock = Mockery::mock('alias:App\Models\User');
        $userMock->shouldReceive('where')
            ->with(['mobile_with_country_code' => $mobile])
            ->andReturnSelf();
        $userMock->shouldReceive('get')
            ->andReturn(collect([
                (object) [
                    'name'          => 'Test User',
                    'email'         => 'test@example.com',
                    'imei'          => '123456789012345',
                    'is_admin'      => true,
                    'mobile'        => $mobile,
                    'organizations' => [],
                ],
            ]));

        // Create a mock of the WebAuth model with expected properties
        $webAuthMock = Mockery::mock('alias:App\Models\WebAuth');
        $webAuthMock->shouldReceive('where')
            ->with(['mobile_with_country_code' => $mobile])
            ->andReturnSelf();
        $webAuthMock->shouldReceive('first')
            ->andReturn((object) [
                'id'           => 1,
                'login_status' => 1,
                'latitude'     => '37.7749',
                'longitude'    => '-122.4194',
            ]);

        // Mock the delete() method on WebAuth
        $webAuthMock->shouldReceive('delete')
            ->once() // This indicates delete should be called exactly once
            ->andReturn(true);

        // Mock the saveAppLog function
        $logMock = Mockery::mock('alias:App\Models\UserAppLogs');
        $logMock->shouldReceive('create')->with([
            'mobile' => $mobile,
            'detail' => 'Log In with Face Authentication for admin.',
        ])->andReturn(true);

        // Make a POST request to the endpoint
        $response = $this->json('POST', '/api/validate-admin-auth', ['mobile' => $mobile]);

        // Assert the response status and JSON structure
        $response->assertStatus(200)
            ->assertJson([
                'data' => [
                    'status'  => true,
                    'message' => 'Biometric Authentication successfully done.',
                ],
            ]);
    }
}
