<?php

namespace Tests\Unit;

use Mockery;
use Tests\TestCase;

class WpRegisterConfirmationTest extends TestCase
{
    protected string $apiRoute;

    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
        $this->apiRoute = route('api.wordpress.register.confirmation');
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function testMissingRequiredParameters()
    {
        // Perform the POST request
        $response = $this->json('POST', $this->apiRoute, []);

        $response->assertStatus(400)->assertJson([
            'error' => [
                'status' => 400,
                'title'  => 'Missing Required Parameters',
            ],
        ]);
    }

    /**
     * Test user not found.
     *
     * @return void
     */
    public function testUserNotFound()
    {
        $data = [
            'country_code' => '+91',
            'mobile'       => '1234567890',
            'domain'       => 'example.com',
            'token'        => 'dgsddsgsdgdsg',
        ];

        $wpUserMock = Mockery::mock('alias:App\Models\WpUser');

        $wpUserMock->shouldReceive('where')
            ->with([
                'country_code' => '+91',
                'mobile'       => '1234567890',
                'website'      => 'example.com',
                'user_token'   => 'dgsddsgsdgdsg',
            ])
            ->andReturnSelf();

        $wpUserMock->shouldReceive('update')
            ->with(['confirmed' => 1])
            ->andReturn(0); // Simulate update failure (no rows updated)

        $response = $this->json('POST', $this->apiRoute, $data);

        $response->assertStatus(404)
            ->assertJson([
                'error' => [
                    'title'  => 'Not Found',
                    'status' => 404,
                ],
            ]);
    }

    public function testSuccessfulRegistrationConfirmation()
    {
        $data = [
            'country_code' => '+91',
            'mobile'       => '1234567890',
            'domain'       => 'example.com',
            'token'        => 'dgsddsgsdgdsg',
        ];

        $wpUserMock = Mockery::mock('alias:App\Models\WpUser');

        $wpUserMock->shouldReceive('where')
            ->with([
                'country_code' => '+91',
                'mobile'       => '1234567890',
                'website'      => 'example.com',
                'user_token'   => 'dgsddsgsdgdsg',
            ])
            ->andReturnSelf();

        $wpUserMock->shouldReceive('update')
            ->with(['confirmed' => 1])
            ->andReturn(1); // Simulate update success

        $response = $this->json('POST', $this->apiRoute, $data);

        $response->assertStatus(200)
            ->assertJson([
                'data' => [
                    'message' => 'Registration confirmed.',
                ],
            ]);
    }

    public function testSuccessfulRegistrationConfirmationWithSupplier()
    {
        $data = [
            'country_code' => '+91',
            'mobile'       => '1234567890',
            'domain'       => 'example.com',
            'token'        => 'dgsddsgsdgdsg',
            'supplier_id'  => 1,
            'supplier'     => 'supplier',
        ];

        $wpUserMock = Mockery::mock('alias:App\Models\WpUser');
        $wpUserMock->shouldReceive('where')
            ->with([
                'country_code' => '+91',
                'mobile'       => '1234567890',
                'website'      => 'example.com',
                'user_token'   => 'dgsddsgsdgdsg',
                'supplier_id'  => 1,
                'supplier'     => 'supplier',
            ])
            ->andReturnSelf();

        $wpUserMock->shouldReceive('update')
            ->with(['confirmed' => 1])
            ->andReturn(1);

        $response = $this->json('POST', $this->apiRoute, $data);

        $response->assertStatus(200)
            ->assertJson([
                'data' => [
                    'message' => 'Registration confirmed.',
                ],
            ]);
    }
}
