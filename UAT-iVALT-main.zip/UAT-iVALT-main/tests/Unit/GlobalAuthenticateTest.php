<?php

namespace Tests\Unit;

use App\Http\Controllers\NotificationController;
use App\Models\User;
use Illuminate\Http\Request;
use Mockery;
use Tests\TestCase;

class GlobalAuthenticateTest extends TestCase
{
    /**
     * Test missing required parameters.
     *
     * @return void
     */
    public function test_missing_required_parameters()
    {
        $response = $this->postJson('api/global/authenticate', []);

        $response->assertStatus(400)
            ->assertJson([
                'error' => [
                    'title'  => 'Missing Required Parameters',
                    'status' => 400,
                ],
            ]);
    }

    public function test_User_Not_Found()
    {
        $data = [
            'mobile'       => '9876543210',
            'status'       => true,
            'country_code' => '91',
        ];

        // Mock User model to return null when querying by mobile
        $userMock = Mockery::mock('alias:App\Models\User');
        $userMock->shouldReceive('where')->with([
            'country_code' => $data['country_code'],
            'mobile'       => $data['mobile'],
        ])->andReturnSelf();
        $userMock->shouldReceive('first')->andReturn(null);

        $response = $this->json('POST', '/api/global/authenticate', $data);

        $response->assertStatus(404)
            ->assertJson([
                'error' => [
                    'status' => 404,
                    'title'  => 'User Not Found',
                ],
            ]);
    }

    public function test_User_Found_And_Notification_Sent()
    {
        $data = [
            'mobile'              => '9876543210',
            'status'              => true,
            'country_code'        => '91',
            'request_from_mobile' => true,
        ];

        // Mock User model to return a user object
        $userMock = Mockery::mock('alias:App\Models\User');
        $userMock->device_token = 'device_token';
        $userMock->shouldReceive('where')->andReturnSelf();
        $userMock->shouldReceive('first')->andReturn($userMock);

        // Mock NotificationController to avoid sending actual notifications
        $notificationMock = Mockery::mock(NotificationController::class);
        $notificationMock->shouldReceive('sendNotificationAuthStatus')
            ->with($userMock, 'iVALT', $data['mobile'], $data['country_code'].$data['mobile'].' Authenticated Successfully.', $data['country_code'].$data['mobile'], $data['status'])
            ->andReturn(true);

        $this->app->instance(NotificationController::class, $notificationMock);

        $response = $this->json('POST', '/api/global/authenticate', $data);

        $response->assertStatus(200)
            ->assertJson([
                'data' => [
                    'status'  => true,
                    'message' => 'iVALT ID Verification Request Sent.',
                ],
            ]);
    }

    // public function test_successful_authentication()
    // {

    //     // Create a WebAuth entry
    //     WebAuth::create([
    //         'mobile' => '6283974746',
    //         'mobile_with_country_code' => '+916283974746',
    //         'login_status' => 1,
    //         'latitude' => 37.7749,
    //         'longitude' => -122.4194,
    //         'country_code' => '+91'
    //     ]);

    //     // Make the request
    //     $response = $this->postJson('api/global/authenticate', [
    //         'mobile' => '6283974746',
    //         'status' => true,
    //         'country_code' => '+91'
    //     ]);

    //     // Assert the response
    //     $response->assertStatus(200)
    //              ->assertJson([
    //                  'message' => 'Biometric Authentication successfully done.',
    //              ]);
    // }

    // /**
    //  * Test invalid state.
    //  *
    //  * @return void
    //  */
    // public function test_invalid_state()
    // {
    //     $user = User::factory()->create([
    //         'mobile_with_country_code' => '11234567890',
    //     ]);

    //     WebAuth::create([
    //         'mobile_with_country_code' => '11234567890',
    //         'login_status' => 0,
    //     ]);

    //     $response = $this->postJson('api/global/authenticate', [
    //         'mobile' => '1234567890',
    //         'status' => true,
    //         'country_code' => '1'
    //     ]);

    //     $response->assertStatus(422)
    //              ->assertJson([
    //                  'message' => 'The mobile number (11234567890) was not in a valid state. Please initiate the Biometric Auth Request again before checking results.',
    //              ]);
    // }

    // /**
    //  * Test authentication with full address.
    //  *
    //  * @return void
    //  */
    // public function test_authentication_with_full_address()
    // {
    //     $user = User::factory()->create([
    //         'mobile_with_country_code' => '11234567890',
    //     ]);

    //     WebAuth::create([
    //         'mobile_with_country_code' => '11234567890',
    //         'login_status' => 1,
    //         'latitude' => 37.7749,
    //         'longitude' => -122.4194,
    //         'full_address' => 1,
    //     ]);

    //     $response = $this->postJson('api/global/authenticate', [
    //         'mobile' => '1234567890',
    //         'status' => true,
    //         'country_code' => '1',
    //         'full_address' => true,
    //     ]);

    //     $response->assertStatus(200)
    //              ->assertJson([
    //                  'message' => 'Biometric Authentication successfully done.',
    //              ]);
    // }

    // /**
    //  * Test authentication with timezone and time.
    //  *
    //  * @return void
    //  */
    // public function test_authentication_with_timezone_and_time()
    // {
    //     $user = User::factory()->create([
    //         'mobile_with_country_code' => '11234567890',
    //     ]);

    //     WebAuth::create([
    //         'mobile_with_country_code' => '11234567890',
    //         'login_status' => 1,
    //         'latitude' => 37.7749,
    //         'longitude' => -122.4194,
    //         'timezone' => json_encode(['value' => 'America/Los_Angeles']),
    //         'time' => '10:00 AM',
    //     ]);

    //     $response = $this->postJson('api/global/authenticate', [
    //         'mobile' => '1234567890',
    //         'status' => true,
    //         'country_code' => '1',
    //         'timezone' => ['value' => 'America/Los_Angeles'],
    //         'time' => '10:00 AM',
    //     ]);

    //     $response->assertStatus(200)
    //              ->assertJson([
    //                  'message' => 'Biometric Authentication successfully done.',
    //              ]);
    // }

    // /**
    //  * Test authentication with latitude and longitude.
    //  *
    //  * @return void
    //  */
    // public function test_authentication_with_latitude_and_longitude()
    // {
    //     $user = User::factory()->create([
    //         'mobile_with_country_code' => '11234567890',
    //     ]);

    //     WebAuth::create([
    //         'mobile_with_country_code' => '11234567890',
    //         'login_status' => 1,
    //         'latitude' => 37.7749,
    //         'longitude' => -122.4194,
    //     ]);

    //     $response = $this->postJson('api/global/authenticate', [
    //         'mobile' => '1234567890',
    //         'status' => true,
    //         'country_code' => '1',
    //         'latitude' => 37.7749,
    //         'longitude' => -122.4194,
    //     ]);

    //     $response->assertStatus(200)
    //              ->assertJson([
    //                  'message' => 'Biometric Authentication successfully done.',
    //              ]);
    // }

    // /**
    //  * Test authentication with address.
    //  *
    //  * @return void
    //  */
    // public function test_authentication_with_address()
    // {
    //     $user = User::factory()->create([
    //         'mobile_with_country_code' => '11234567890',
    //     ]);

    //     WebAuth::create([
    //         'mobile_with_country_code' => '11234567890',
    //         'login_status' => 1,
    //         'latitude' => 37.7749,
    //         'longitude' => -122.4194,
    //         'address' => '123 Main St, San Francisco, CA',
    //     ]);

    //     $response = $this->postJson('api/global/authenticate', [
    //         'mobile' => '1234567890',
    //         'status' => true,
    //         'country_code' => '1',
    //         'address' => '123 Main St, San Francisco, CA',
    //     ]);

    //     $response->assertStatus(200)
    //              ->assertJson([
    //                  'message' => 'Biometric Authentication successfully done.',
    //              ]);
    // }
}
