<?php

namespace Tests\Unit;

use App\Models\WordpressEmailAuth;
use App\Services\EmailService;
use Illuminate\Http\JsonResponse;
use Mockery;
use Tests\TestCase;

class WordpressSendVerificationCodeTest extends TestCase
{
    protected string $apiRoute;
    protected array $validPayload;

    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();

        $this->apiRoute = route('api.wordpress.send.verification.code');
        $this->validPayload = [
            'domain' => 'test.com',
            'email'  => 'test@test.com',
        ];

    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function testMissingRequiredParameters()
    {
        $response = $this->json('POST', $this->apiRoute, []);

        $response->assertStatus(400)
            ->assertJson([
                'error' => [
                    'status' => 400,
                    'title'  => 'Missing Required Parameters',
                ],
            ]);
    }

    public function testSuccessfulVerificationEmailSent()
    {

        // Mocking the EmailService
        $emailServiceMock = Mockery::mock(EmailService::class);
        $this->app->instance(EmailService::class, $emailServiceMock);

        // Return a JsonResponse indicating failure (422)
        $emailServiceMock
            ->shouldReceive('sendWordpressVerificationEmail')
            ->once()
            ->with('test@test.com', Mockery::type('int'))
            ->andReturn(new JsonResponse(['status' => true], 200));

        $wpEmailAuthMock = Mockery::mock('alias:'.WordpressEmailAuth::class);
        $wpEmailAuthMock->shouldReceive('updateOrCreate')->andReturnSelf();

        $response = $this->json('POST', $this->apiRoute, $this->validPayload);

        $response->assertStatus(200)
            ->assertJson([
                'data' => [
                    'details' => null,
                    'message' => 'Verification email sent successfully.',
                ],
            ]);
    }
}
