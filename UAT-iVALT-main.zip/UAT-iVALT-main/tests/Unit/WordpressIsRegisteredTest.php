<?php

namespace Tests\Unit;

use App\Models\WordpressEmailAuth;
use App\Models\WpUser;
use Mockery;
use Tests\TestCase;

class WordpressIsRegisteredTest extends TestCase
{
    protected string $apiRoute;
    protected array $validPayload;

    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();

        $this->apiRoute = route('api.wordpress.is.registered');
        $this->validPayload = [
            'country_code'     => '91',
            'mobile'           => '1234567890',
            'email'            => 'test@test.com',
            'domain'           => 'test.com',
        ];
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function testMissingRequiredParameters()
    {
        $response = $this->json('POST', $this->apiRoute, []);

        $response->assertStatus(400)
            ->assertJson([
                'error' => [
                    'status' => 400,
                    'title'  => 'Missing Required Parameters',
                ],
            ]);
    }

    public function testMobileNotRegistered()
    {
        $this->mockWpUser()->shouldReceive('firstWhere')->andReturn(null);

        $response = $this->json('POST', $this->apiRoute, $this->validPayload);

        $response->assertStatus(404)
            ->assertJson([
                'error' => [
                    'status' => 404,
                    'title'  => 'Not Found',
                    'detail' => 'The mobile number provided ('.$this->validPayload['country_code'].' '.$this->validPayload['mobile'].') is not registered with iVALT.',
                ],
            ]);
    }

    public function testMobileRegistered()
    {
        $mockWpUser = $this->mockWpUser();
        $mockWpUser->shouldReceive('firstWhere')->andReturnSelf();
        $mockWpUser->shouldReceive('getAttribute')->with('confirmed')->andReturn(1);
        $mockWpUser->confirmed = 1;

        $response = $this->json('POST', $this->apiRoute, $this->validPayload);

        $response->assertStatus(422)
            ->assertJson([
                'error' => [
                    'status' => 422,
                    'title'  => 'Already Registered',
                    'detail' => 'User already registered with iVALT.',
                ],
            ]);
    }

    private function mockWpUser()
    {
        return Mockery::mock('alias:'.WpUser::class);
    }

    private function mockWordpressEmailAuth()
    {
        return Mockery::mock('alias:'.WordpressEmailAuth::class);
    }
}
