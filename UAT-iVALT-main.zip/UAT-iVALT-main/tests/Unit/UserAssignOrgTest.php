<?php

namespace Tests\Unit;

use Mockery;
use Tests\TestCase;

class UserAssignOrgTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    public function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function test_missing_required_parameters()
    {
        $requestParams = [];

        $response = $this->json('POST', '/api/user/assign-org', $requestParams);

        $response->assertStatus(400)
            ->assertJson([
                'error' => [
                    'status' => 400,
                    'title'  => 'Missing Required Parameters',
                ],
            ]);
    }

    public function test_organization_not_found()
    {
        $requestParams = ['country_code' => '+1', 'mobile' => '1234567890', 'organization_code' => 'ORG001'];

        $orgMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $orgMock->shouldReceive('where')
            ->with(['organization_code' => $requestParams['organization_code']])
            ->andReturnSelf();
        $orgMock->shouldReceive('first')
            ->andReturn(null);
        $response = $this->json('POST', '/api/user/assign-org', $requestParams);

        // Assert
        $response->assertStatus(404)
            ->assertJson([
                'error' => [
                    'status' => 404,
                    'detail' => 'The organization code provided (ORG001) is not registered with iVALT.',
                ],
            ]);
    }

    public function test_user_not_found()
    {
        $requestParams = ['country_code' => '+1', 'mobile' => '1234567890', 'organization_code' => 'ORG001'];

        // Mock Organization::where() to return a mock organization
        $orgMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $orgMock->shouldReceive('where')
            ->with(['organization_code' => $requestParams['organization_code']])
            ->andReturnSelf();
        $orgMock->shouldReceive('first')
            ->andReturn($orgMock);

        // Mock User::where() to return null
        $userMock = Mockery::mock('alias:App\Models\User');
        $userMock->shouldReceive('where')
            ->with(['country_code' => $requestParams['country_code'], 'mobile' => $requestParams['mobile']])
            ->andReturnSelf();
        $userMock->shouldReceive('first')
            ->andReturn(null);

        // Act
        $response = $this->json('POST', '/api/user/assign-org', $requestParams);

        // Assert
        $response->assertStatus(404)
            ->assertJson([
                'error' => [
                    'status' => 404,
                    'detail' => 'The mobile number provided (+11234567890) is not registered with iVALT.',
                ],
            ]);
    }

    public function test_successfully_assigns_user_to_organization()
    {
        $requestParams = ['country_code' => '+1', 'mobile' => '1234567890', 'organization_code' => 'ORG001'];

        // Mock Organization::where() to return a mock organization
        $orgMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $orgMock->shouldReceive('where')
            ->with(['organization_code' => $requestParams['organization_code']])
            ->andReturnSelf();
        $orgMock->shouldReceive('first')
            ->andReturn($orgMock);

        // Mock User::where() to return a mock user
        $userMock = Mockery::mock('alias:App\Models\User');
        $userMock->id = 1;
        $userMock->shouldReceive('where')
            ->with(['country_code' => $requestParams['country_code'], 'mobile' => $requestParams['mobile']])
            ->andReturnSelf();
        $userMock->shouldReceive('first')
            ->andReturn($userMock);

        // Mock the detach and attach methods for user assignment
        $orgMock->shouldReceive('users->detach')->with(1)->andReturnSelf();
        $orgMock->shouldReceive('pendingUsers->attach')->with(1)->andReturnSelf();

        // Act
        $response = $this->json('POST', '/api/user/assign-org', $requestParams);

        // Assert
        $response->assertStatus(200)
            ->assertJson([
                'data' => [
                    'status'  => 'true',
                    'message' => 'User status updated successfully.',
                ],
            ]);
    }
}
