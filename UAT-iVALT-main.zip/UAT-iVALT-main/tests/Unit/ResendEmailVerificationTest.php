<?php

namespace Tests\Unit;

use App\Services\EmailService;
use Illuminate\Http\JsonResponse;
use Mockery;
use Tests\TestCase;

class ResendEmailVerificationTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function test_missing_required_parameters()
    {
        $response = $this->json('POST', 'api/resend-email-verification', []);

        $response->assertStatus(400)->assertJson([
            'error' => [
                'status' => 400,
                'title'  => 'Missing Required Parameters',
            ],
        ]);
    }

    public function test_user_not_found()
    {
        $userMock = Mockery::mock('alias:App\Models\User');
        $userMock
            ->shouldReceive('where')
            ->with([
                'country_code' => '91',
                'mobile'       => '1234567890',
                'email'        => 'test@example.com',
            ])
            ->andReturn($userMock);

        $userMock->shouldReceive('first')->andReturn(null);

        $response = $this->json('POST', 'api/resend-email-verification', [
            'mobile'       => '1234567890',
            'email'        => 'test@example.com',
            'country_code' => '91',
        ]);

        $response->assertStatus(404)->assertJson([
            'error' => [
                'status' => 404,
                'title'  => 'Not Found',
                'detail' => 'The mobile number provided (1234567890) was not found.',
            ],
        ]);
    }

    public function testResendEmailVerificationFailed()
    {
        $requestData = [
            'mobile'       => '6283974746',
            'email'        => 'bikramjeet@ivalt.com',
            'country_code' => '+91',
        ];

        // Mocking the User model
        $userMock = Mockery::mock('alias:App\Models\User');
        $userMock->shouldReceive('where')
            ->with($requestData)
            ->andReturnSelf();

        $userMock->shouldReceive('first')
            ->andReturn($userMock);

        $userMock->shouldReceive('update')->andReturn(true);

        // Mocking the EmailService
        $emailServiceMock = Mockery::mock(EmailService::class);
        $this->app->instance(EmailService::class, $emailServiceMock);

        // Return a JsonResponse indicating failure (422)
        $emailServiceMock
            ->shouldReceive('sendMobileAppVerificationEmail')
            ->once()
            ->with($requestData['email'], '62****4746', Mockery::type('string'))
            ->andReturn(new JsonResponse(['status' => false], 422));

        // Call the API endpoint and assert the response
        $response = $this->json('POST', '/api/resend-email-verification', $requestData);

        // Assert the response
        $response->assertStatus(422)
            ->assertJson([
                'error' => [
                    'status' => 422,
                    'title'  => 'Unprocessable Request',
                    'detail' => 'Email could not be sent.',
                ],
            ]);
    }

    public function testResendEmailVerificationSuccess()
    {
        $requestData = [
            'mobile'       => '6283974746',
            'email'        => 'bikramjeet@ivalt.com',
            'country_code' => '+91',
        ];

        // Mocking the User model
        $userMock = Mockery::mock('alias:App\Models\User');
        $userMock->shouldReceive('where')
            ->with($requestData)
            ->andReturnSelf();

        $userMock->shouldReceive('first')
            ->andReturn($userMock);

        $userMock->shouldReceive('update')->andReturn(true);

        // Mocking the EmailService
        $emailServiceMock = Mockery::mock(EmailService::class);
        $this->app->instance(EmailService::class, $emailServiceMock);
        $emailServiceMock
            ->shouldReceive('sendMobileAppVerificationEmail')
            ->once()
            ->with($requestData['email'], '62****4746', Mockery::type('string'))
            ->andReturn(new JsonResponse(true));

        // Call the API endpoint and assert the response
        $response = $this->json('POST', '/api/resend-email-verification', $requestData);
        $response->assertStatus(200)
            ->assertJson([
                'data' => [
                    'status'  => true,
                    'message' => 'Verification email sent successfully.',
                ],
            ]);
    }
}
