<?php

namespace Tests\Unit;

use Mockery;
use Tests\TestCase;

class DeleteOrganizationUserTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function test_organization_not_found()
    {
        $orgId = 1;
        $userId = 1;

        // Mock Organization model
        $orgModelMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $orgModelMock->shouldReceive('find')->with($orgId)->andReturn(null);

        // Make the request
        $response = $this->json('DELETE', "/api/organization/{$orgId}/delete/user/{$userId}");

        // Assert the response
        $response->assertStatus(404)->assertJson([
            'error' => [
                'title'  => 'Not Found',
                'detail' => 'Organization not found',
            ],
        ]);
    }

    public function test_user_not_found_in_organization()
    {
        $orgId = 1;
        $userId = 1;

        // Mock Organization model
        $orgModelMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $orgModelMock->shouldReceive('find')->with($orgId)->andReturn($orgModelMock);

        // Mock users() method to return a mock of the relationship query builder
        $usersMock = Mockery::mock('alias:App\Models\User');
        $orgModelMock->shouldReceive('users')->andReturn($usersMock);
        $usersMock->shouldReceive('find')->with($userId)->andReturn(null);

        // Make the request
        $response = $this->json('DELETE', "/api/organization/{$orgId}/delete/user/{$userId}");

        // Assert the response
        $response->assertStatus(404)->assertJson([
            'error' => [
                'title'  => 'Not Found',
                'detail' => 'User not found.',
            ],
        ]);
    }

    public function test_user_deletion_success()
    {
        $orgId = 1;
        $userId = 1;

        // Mock Organization model
        $orgModelMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $orgModelMock->shouldReceive('find')->with($orgId)->andReturn($orgModelMock);

        // Mock users() relationship
        $usersMock = Mockery::mock('alias:App\Models\User');
        $orgModelMock->shouldReceive('users')->andReturn($usersMock);
        $orgUserModelMock = Mockery::mock('alias:App\Models\User');
        $orgUserModelMock->id = $userId;
        $usersMock->shouldReceive('find')->with($userId)->andReturn($orgUserModelMock);
        $orgUserModelMock->shouldReceive('delete')->andReturn(true);
        $usersMock->shouldReceive('detach')->with($userId)->andReturn(true);

        // Make the request
        $response = $this->json('DELETE', "/api/organization/{$orgId}/delete/user/{$userId}");

        // Assert the response
        $response->assertStatus(200)->assertJson([
            'data' => [
                'status'  => true,
                'message' => 'User deleted successfully.',
            ],
        ]);
    }

    public function test_user_deletion_failure()
    {
        $orgId = 1;
        $userId = 1;

        // Mock Organization model
        $orgModelMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $orgModelMock->shouldReceive('find')->with($orgId)->andReturn($orgModelMock);

        // Mock users() relationship
        $usersMock = Mockery::mock('alias:Illuminate\Database\Eloquent\Relations\BelongsToMany');
        $orgModelMock->shouldReceive('users')->andReturn($usersMock);
        $orgUserModelMock = Mockery::mock('alias:App\Models\User');
        $orgUserModelMock->id = $userId;
        $usersMock->shouldReceive('find')->with($userId)->andReturn($orgUserModelMock);
        $orgUserModelMock->shouldReceive('delete')->andReturn(false); // Simulate failure
        $usersMock->shouldReceive('detach')->with($userId)->andReturn(false); // Simulate failure

        // Make the request
        $response = $this->json('DELETE', "/api/organization/{$orgId}/delete/user/{$userId}");

        // Assert the response
        $response->assertStatus(404)->assertJson([
            'error' => [
                'title'  => 'Operation failed',
                'detail' => 'Something went wrong!',
            ],
        ]);
    }
}
