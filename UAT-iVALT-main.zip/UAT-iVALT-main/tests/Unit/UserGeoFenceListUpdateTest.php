<?php

namespace Tests\Unit;

use Mockery;
use Tests\TestCase;

class UserGeoFenceListUpdateTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function test_user_not_found()
    {
        // Arrange
        $userId = 1;

        // Mock User::find() to return null
        $userMock = Mockery::mock('alias:App\Models\User');
        $userMock
            ->shouldReceive('find')
            ->with($userId)
            ->andReturn(null);

        // Act: Perform the API call
        $response = $this->json('PUT', "/api/user/{$userId}/geofences/update", []);

        // Assert: Check that the response indicates the user was not found
        $response->assertStatus(404)
            ->assertJson([
                'error' => [
                    'status' => 404,
                    'detail' => 'User not found',
                ],
            ]);
    }

    public function test_missing_required_parameters()
    {
        // Arrange
        $userId = 1;

        // Mock User::find() to return a user instance
        $userMock = Mockery::mock('alias:App\Models\User');
        $userMock
            ->shouldReceive('find')
            ->with($userId)
            ->andReturn($userMock);

        // Mock request to have no 'orgGeoFence_ids' parameter

        // Act: Perform the API call
        $response = $this->json('PUT', "/api/user/{$userId}/geofences/update", []);

        // Assert: Check that the response indicates missing required parameters
        $response->assertStatus(400)
            ->assertJson([
                'error' => [
                    'status' => 400,
                    'title'  => 'Missing Required Parameters',
                ],
            ]);
    }

    // public function test_user_found_no_orgGeoFences_provided()
    // {
    //     // Arrange
    //     $userId = 1;
    //     $orgGeoFenceIds = [1];
    //     $requestParams = ['orgGeoFence_ids' => $orgGeoFenceIds];

    //     // Mock User::find() to return a user instance
    //     $userMock = Mockery::mock('alias:App\Models\User');
    //     $orgGeoFenceMock = Mockery::mock('alias:App\Models\Organization\OrganizationGeoFences');
    //     $userMock
    //         ->shouldReceive('find')
    //         ->with($userId)
    //         ->andReturn($userMock);

    //     $orgGeoFenceMock->shouldReceive('detach')->once();
    //     $orgGeoFenceMock->shouldReceive('attach')->with($orgGeoFenceIds)->once();
    //     $userMock->shouldReceive('orgGeoFences')->andReturn($orgGeoFenceMock);

    //     $orgGeoFenceMock->shouldReceive('get')->andReturn($orgGeoFenceIds);
    //     $userMock->shouldReceive('getRelationValue')->with('orgGeoFences')->andReturn(collect([]));

    //     // Act: Perform the API call
    //     $response = $this->json('PUT', "/api/user/{$userId}/geofences/update", $requestParams);

    //     // Assert: Check that the response indicates successful update but no orgGeoFences
    //     $response->assertStatus(404)
    //         ->assertJson([
    //             'error' => [
    //                 'status' => 404,
    //                 'detail' => 'User orgGeoFences not found',
    //             ],
    //         ]);

    // }

    public function test_successful_orgGeoFences_update()
    {
        // Arrange
        $userId = 1;
        $orgGeoFenceIds = [1, 2, 3];

        // Mock User::find() to return a user instance
        $userMock = Mockery::mock('alias:App\Models\User');
        $userMock
            ->shouldReceive('find')
            ->with($userId)
            ->andReturn($userMock);

        // Mock orgGeoFences relationship methods
        $userMock
            ->shouldReceive('orgGeoFences')
            ->andReturn($userMock);

        $userMock
            ->shouldReceive('detach')
            ->once()
            ->andReturnSelf();

        $userMock
            ->shouldReceive('attach')
            ->with($orgGeoFenceIds)
            ->once()
            ->andReturnSelf();

        $userMock
            ->shouldReceive('getAttribute')
            ->with('orgGeoFences')
            ->andReturn([
                ['id' => 1, 'name' => 'GeoFence 1'],
                ['id' => 2, 'name' => 'GeoFence 2'],
                ['id' => 3, 'name' => 'GeoFence 3'],
            ]);

        // Mock request to have 'orgGeoFence_ids' parameter
        $requestParams = ['orgGeoFence_ids' => $orgGeoFenceIds];

        // Act: Perform the API call
        $response = $this->json('PUT', "/api/user/{$userId}/geofences/update", $requestParams);

        // Assert: Check that the response indicates a successful update
        $response->assertStatus(200)
            ->assertJson([
                'data' => [
                    'status'  => true,
                    'message' => 'Org orgGeoFences list.',
                ],

            ]);
    }
}
