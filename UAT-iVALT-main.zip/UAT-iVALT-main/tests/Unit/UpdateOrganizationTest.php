<?php

namespace Tests\Unit;

use Mockery;
use Tests\TestCase;

class UpdateOrganizationTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function test_Organization_Not_Found()
    {
        $orgId = 1; // Use a non-existent ID
        $data = [
            'name'               => 'Updated Organization',
            'organization_code'  => 'UPDORG123',
            'has_geo_fencing'    => true,
            'number_geo_fencing' => 10,
            'is_active'          => true,
        ];

        $organizationMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $organizationMock->shouldReceive('find')
            ->with(1)
            ->andReturn(null);

        $response = $this->json('PUT', '/api/organization/update/'.$orgId, $data);

        // Assert
        $response->assertStatus(404)
            ->assertJson([
                'error' => [
                    'status' => 404,
                    'title'  => 'Not Found',
                    'detail' => 'Organization not found',
                ],
            ]);
    }

    public function test_Missing_Required_Parameters()
    {
        // Mock the organization to exist
        $orgModelMock = Mockery::mock('alias:App\Models\Organization\Organization');

        $response = $this->json('PUT', '/api/organization/update/1', []);

        // Assert that the response status is 400
        $response->assertStatus(400);
        $response->assertJson([
            'error' => [
                'status' => 400,
                'title'  => 'Missing Required Parameters',

            ],
        ]);
    }

    public function test_Update_Organization_Success()
    {
        // Arrange
        $data = [
            'name'               => 'Updated Organization',
            'organization_code'  => 'UPDORG123',
            'has_geo_fencing'    => true,
            'number_geo_fencing' => 10,
            'is_active'          => true,
        ];

        // Mock the Organization model and the update method
        $organizationMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $organizationMock->shouldReceive('find')
            ->with(1)
            ->andReturn($organizationMock);
        $organizationMock->shouldReceive('update')
            ->once()
            ->andReturn(true);

        // Act
        $response = $this->json('PUT', '/api/organization/update/1', $data);

        // Assert
        $response->assertStatus(200)
            ->assertJson([
                'data' => [
                    'status'  => true,
                    'message' => 'Organization updated successfully.',

                ],

            ]);
    }

    public function test_Update_Organization_Failure()
    {
        // Arrange
        $data = [
            'name'               => 'Updated Organization',
            'organization_code'  => 'UPDORG123',
            'has_geo_fencing'    => true,
            'number_geo_fencing' => 10,
            'is_active'          => true,
        ];

        // Mock the Organization model and the update method
        $organizationMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $organizationMock->shouldReceive('find')
            ->with(1)
            ->andReturn($organizationMock);
        $organizationMock->shouldReceive('update')
            ->once()
            ->andReturn(false);

        // Act
        $response = $this->json('PUT', '/api/organization/update/1', $data);

        // Assert
        $response->assertStatus(404)
            ->assertJson([
                'error' => [
                    'status' => 404,
                    'title'  => 'Operation failed',
                    'detail' => 'Something went wrong!',
                ],
            ]);
    }
}
