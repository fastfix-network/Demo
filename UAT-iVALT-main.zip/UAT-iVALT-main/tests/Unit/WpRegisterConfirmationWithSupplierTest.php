<?php

namespace Tests\Unit;

use App\Models\WpUser;
use Mockery;
use Tests\TestCase;

class WpRegisterConfirmationWithSupplierTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();

        $this->wpUserMock = Mockery::mock('alias:App\Models\WpUser');
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function testMissingRequiredParameters()
    {
        $response = $this->json('POST', 'api/wp/register/supplier/confirmation', [
            'mobile' => '1234567890',
            // Missing 'domain', 'token', 'supplier', 'supplier_id'
        ]);

        $response->assertStatus(400)
            ->assertJson([
                'error' => [
                    'status' => 400,
                    'title'  => 'Missing Required Parameters',
                ],
            ]);
    }

    public function testInvalidToken()
    {
        $this->wpUserMock->shouldReceive('where')
            ->with([
                'mobile'      => '1234567890',
                'website'     => 'example.com',
                'supplier_id' => 'supplier-id',
                'supplier'    => 'supplier-name',
                'user_token'  => 'invalid-token',
            ])
            ->andReturnSelf();

        // Allow the update call, but it should not actually update anything
        $this->wpUserMock->shouldReceive('update')
            ->with(['confirmed' => 1])
            ->andReturn(0); // Simulate "no update" due to invalid token

        $response = $this->json('POST', 'api/wp/register/supplier/confirmation', [
            'mobile'      => '1234567890',
            'domain'      => 'example.com',
            'token'       => 'invalid-token',
            'supplier'    => 'supplier-name',
            'supplier_id' => 'supplier-id',
        ]);

        $response->assertStatus(404)
            ->assertJson([
                'error' => [
                    'status' => 404,
                    'title'  => 'Not Found',
                    'detail' => 'The mobile number provided (1234567890) is not registered with iValt.',
                ],
            ]);
    }

    public function testSuccessfulConfirmation()
    {
        // Mock the WpUser model to simulate successful update
        // $wpUserMock = Mockery::mock('alias:App\Models\WpUser');
        $this->wpUserMock->shouldReceive('where')
            ->with([
                'mobile'      => '1234567890',
                'website'     => 'example.com',
                'supplier_id' => 'supplier-id',
                'supplier'    => 'supplier-name',
                'user_token'  => 'valid-token',
            ])
            ->andReturnSelf();  // Return the mock itself for method chaining

        $this->wpUserMock->shouldReceive('update')
            ->with(['confirmed' => 1])
            ->andReturn(1); // Indicating successful update

        $response = $this->json('POST', 'api/wp/register/supplier/confirmation', [
            'mobile'      => '1234567890',
            'domain'      => 'example.com',
            'token'       => 'valid-token',
            'supplier'    => 'supplier-name',
            'supplier_id' => 'supplier-id',
        ]);

        $response->assertStatus(200)
            ->assertJson([
                'data' => [
                    'status'  => true,
                    'message' => 'Authentication success.',
                    'details' => [],
                ],

            ]);
    }

    public function testMobileNumberNotRegistered()
    {
        // Mock the WpUser model to simulate no update (user not found)
        // $wpUserMock = Mockery::mock('alias:App\Models\WpUser');
        $this->wpUserMock->shouldReceive('where')
            ->with([
                'mobile'      => '1234567890',
                'website'     => 'example.com',
                'supplier_id' => 'supplier-id',
                'supplier'    => 'supplier-name',
                'user_token'  => 'valid-token',
            ])
            ->andReturnSelf();  // Return the mock itself for method chaining

        $this->wpUserMock->shouldReceive('update')
            ->with(['confirmed' => 1])
            ->andReturn(0); // Indicating no update (user not found)

        $response = $this->json('POST', 'api/wp/register/supplier/confirmation', [
            'mobile'      => '1234567890',
            'domain'      => 'example.com',
            'token'       => 'valid-token',
            'supplier'    => 'supplier-name',
            'supplier_id' => 'supplier-id',
        ]);

        $response->assertStatus(404)
            ->assertJson([
                'error' => [
                    'status' => 404,
                    'title'  => 'Not Found',
                    'detail' => 'The mobile number provided (1234567890) is not registered with iValt.',
                ],
            ]);
    }
}
