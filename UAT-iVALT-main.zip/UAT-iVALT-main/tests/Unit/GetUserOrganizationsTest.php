<?php

namespace Tests\Unit;

use Mockery;
use Tests\TestCase;

class GetUserOrganizationsTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function test_missing_required_parameters()
    {
        // Perform the API call without mobile_number
        $response = $this->json('POST', '/api/organization/user/getOrganizations', []);

        // Assert the response
        $response->assertStatus(400)
            ->assertJson([
                'error' => [
                    'status' => '400',
                    'title'  => 'Missing Required Parameters',

                ],
            ]);
    }

    public function test_user_not_found()
    {
        $mobileNumber = '919876543210';

        // Mock the User model to return null
        $userMock = Mockery::mock('alias:App\Models\User');
        $userMock->shouldReceive('where')->with('mobile_with_country_code', $mobileNumber)->andReturnSelf();
        $userMock->shouldReceive('first')->andReturnNull();

        // Perform the API call
        $response = $this->json('POST', '/api/organization/user/getOrganizations', [
            'mobile_number' => $mobileNumber,
        ]);

        // Assert the response
        $response->assertStatus(404)
            ->assertJson([
                'error' => [
                    'title'  => 'Not Found',
                    'detail' => 'User not found',
                ],
            ]);
    }

    public function test_successful_organization_fetch()
    {
        $mobileNumber = '919876543210';

        // Mock the User model
        $userMock = Mockery::mock('alias:App\Models\User');

        // Set up the mock organization and pending organization data
        $activeOrganization = (object) [
            'id'                => 1,
            'name'              => 'Org A',
            'organization_code' => 'ORG1',
            'is_active'         => 1,
        ];

        $pendingOrganization = (object) [
            'id'                => 2,
            'name'              => 'Org B',
            'organization_code' => 'ORG2',
            'is_active'         => 1,
            'pivot'             => (object) ['is_Active' => true], // Correctly use 'is_Active' to match the function logic
        ];

        // Mock User with organizations and pendingOrganizations relationships
        $userMock->shouldReceive('where')->with('mobile_with_country_code', $mobileNumber)->andReturnSelf();
        $userMock->shouldReceive('first')->andReturn((object) [
            'id'                       => 1,
            'mobile_with_country_code' => $mobileNumber,
            'organizations'            => collect([$activeOrganization]),
            'pendingOrganizations'     => collect([$pendingOrganization]),
        ]);

        // Perform the API call
        $response = $this->json('POST', '/api/organization/user/getOrganizations', [
            'mobile_number' => $mobileNumber,
        ]);

        // Assert the response
        $response->assertStatus(200)
            ->assertJson([
                'data' => [
                    'status'  => 'true',
                    'message' => 'User Organizations fetched successfully.',

                ],
            ],

            );
    }
}
