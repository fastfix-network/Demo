<?php

namespace Tests\Unit;

use Mockery;
use Tests\TestCase;

class UserCheckOrgAssignmentTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    public function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function test_missing_required_parameters()
    {

        $response = $this->json('POST', '/api/user/check-org-assignment', []);

        // Assert the response
        $response->assertStatus(400);
        $response->assertJson([
            'error' => [
                'status' => '400',
                'title'  => 'Missing Required Parameters',
            ],
        ]);
    }

    public function test_user_not_found()
    {

        $userMock = Mockery::mock('alias:App\Models\User');
        $userMock->shouldReceive('where')
            ->with(['country_code' => '91', 'mobile' => '1234567890'])
            ->once()
            ->andReturnSelf();
        $userMock->shouldReceive('first')
            ->once()
            ->andReturn(null);

        $response = $this->json('POST', '/api/user/check-org-assignment', [
            'country_code' => '91',
            'mobile'       => '1234567890',
        ]);

        // Assert the response
        $response->assertStatus(404);
        $response->assertJson([
            'error' => [
                'status' => '404',
                'title'  => 'Not Found',
                'detail' => 'The mobile number provided (91 1234567890) is not registered with iVALT.',
            ],
        ]);
    }

    public function test_user_not_assigned_to_organization()
    {

        $userMock = Mockery::mock('alias:App\Models\User');
        $userMock->id = 1;
        $userMock->shouldReceive('where')
            ->with(['country_code' => '91', 'mobile' => '1234567890'])
            ->once()
            ->andReturnSelf();
        $userMock->shouldReceive('first')
            ->once()
            ->andReturn($userMock);

        // Mock the OrganizationUserPool model
        $organizationUserPoolMock = Mockery::mock('alias:App\Models\Organization\OrganizationUserPool');
        $organizationUserPoolMock->shouldReceive('firstWhere')
            ->with(['user_id' => 1])
            ->once()
            ->andReturn(null);

        // Mock the OrganizationUser model
        $organizationUserMock = Mockery::mock('alias:App\Models\Organization\OrganizationUser');
        $organizationUserMock->shouldReceive('firstWhere')
            ->with(['user_id' => 1])
            ->once()
            ->andReturn(null);

        // Call the API using your preferred method
        $response = $this->json('POST', '/api/user/check-org-assignment', [
            'country_code' => '91',
            'mobile'       => '1234567890',
        ]);

        // Assert the response
        $response->assertStatus(404);
        $response->assertJson([
            'error' => [
                'status' => '404',
                'title'  => 'Not Found',
                'detail' => 'User not assigned to organization',
            ],
        ]);
    }

    public function test_user_success_assigned_to_organization()
    {
        $userMock = Mockery::mock('alias:App\Models\User');
        $userMock->id = 1;
        $userMock->shouldReceive('where')
            ->with(['country_code' => '91', 'mobile' => '1234567890'])
            ->once()
            ->andReturnSelf();
        $userMock->shouldReceive('first')
            ->once()
            ->andReturn($userMock);

        $organizationUserPoolMock = Mockery::mock('alias:App\Models\Organization\OrganizationUserPool');
        $organizationUserPoolMock->shouldReceive('firstWhere')
            ->with(['user_id' => $userMock->id])
            ->once()
            ->andReturn($userMock);

        // Mock the OrganizationUser model
        $organizationUserMock = Mockery::mock('alias:App\Models\Organization\OrganizationUser');
        $organizationUserMock->shouldReceive('firstWhere')
            ->with(['user_id' => $userMock->id])
            ->once()
            ->andReturn($userMock);

        // Call the API using your preferred method
        $response = $this->json('POST', '/api/user/check-org-assignment', [
            'country_code' => '91',
            'mobile'       => '1234567890',
        ]);

        // Assert the response
        $response->assertStatus(200);
        $response->assertJson([
            'data' => [
                'status'  => 'true',
                'message' => 'User assigned to organization',
            ],
        ]);
    }
}
