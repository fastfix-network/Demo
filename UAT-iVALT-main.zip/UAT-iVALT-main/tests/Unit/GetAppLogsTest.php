<?php

namespace Tests\Unit;

use Illuminate\Support\Facades\DB;
use Mockery;
use Tests\TestCase;

class GetAppLogsTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function test_get_app_logs_missing_required_parameters()
    {
        // Arrange: Prepare the request data without the 'mobile' parameter
        $requestParams = [];

        // Act: Perform the API call
        $response = $this->json('POST', '/api/get/app/logs', $requestParams);

        // Assert: Check that the response indicates missing required parameters
        $response->assertStatus(400)
            ->assertJson([
                'error' => [
                    'status' => 400,
                    'title'  => 'Missing Required Parameters', // Adjust message to match your validation
                ],
            ]);
    }

    public function test_get_app_logs_logs_found()
    {
        // Arrange: Prepare the request data
        $mobile = '1234567890';
        $requestParams = ['mobile' => $mobile];

        // Mock the database query for logs
        DB::shouldReceive('table->where->count')
            ->once()
            ->andReturn(1);

        DB::shouldReceive('table->where->orderBy->get->toArray')
            ->once()
            ->andReturn([
                ['id' => 1, 'mobile' => $mobile, 'message' => 'Log entry 1'],
                ['id' => 2, 'mobile' => $mobile, 'message' => 'Log entry 2'],
            ]);

        // Act: Perform the API call
        $response = $this->json('POST', '/api/get/app/logs', $requestParams);

        // Assert: Check that the response contains logs
        $response->assertStatus(200)
            ->assertJson([
                'data' => [
                    'status'  => true,
                    'message' => 'Logs fetched successfully.',

                ],

            ]);
    }

    public function test_get_app_logs_no_logs_found()
    {
        // Arrange: Prepare the request data
        $mobile = '0987654321';
        $requestParams = ['mobile' => $mobile];

        // Mock the database query for logs
        DB::shouldReceive('table->where->count')
            ->once()
            ->andReturn(0);

        // Act: Perform the API call
        $response = $this->json('POST', '/api/get/app/logs', $requestParams);

        // Assert: Check that the response contains no logs
        $response->assertStatus(200)
            ->assertJson([
                'data' => [
                    'status'  => true,
                    'message' => 'Logs not available.',
                ],
            ]);
    }
}
