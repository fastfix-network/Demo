<?php

namespace Tests\Unit;

use Mockery;
use Tests\TestCase;

class SendAppAuthNotificationTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function test_missing_required_parameters()
    {
        // Arrange: Missing 'request_to_mobile' and 'request_from_mobile'
        $requestParams = [];

        // Act: Perform the API call
        $response = $this->json('POST', '/api/send/app-auth/notification', $requestParams);

        // Assert: Check for a 400 error with missing required parameters
        $response->assertStatus(400)
            ->assertJson([
                'error' => [
                    'status' => 400,
                    'title'  => 'Missing Required Parameters',
                ],
            ]);
    }

    public function test_user_not_found()
    {
        // Arrange: Valid parameters but no user exists
        $requestParams = [
            'request_to_mobile'   => '+1234567890',
            'request_from_mobile' => '+0987654321',
        ];

        // Mock the User model and its 'with' method
        $userMock = Mockery::mock('alias:App\Models\User');
        $userMock->shouldReceive('with')->with('device_tokens')->andReturn($userMock);
        $userMock->shouldReceive('where')->with(['mobile_with_country_code' => $requestParams['request_to_mobile']])->andReturn($userMock);
        $userMock->shouldReceive('first')->andReturn(null);

        // Act: Perform the API call
        $response = $this->json('POST', '/api/send/app-auth/notification', $requestParams);

        // Assert: Check for a 404 error when user is not found
        $response->assertStatus(404)
            ->assertJson([
                'error' => [
                    'status' => 404,
                    'detail' => 'The mobile number provided (+1234567890) was not found.',
                ],
            ]);
    }

    public function test_successful_notification()
    {
        // Arrange: Valid parameters and user found
        $requestParams = [
            'request_to_mobile'   => '+1234567890',
            'request_from_mobile' => '+0987654321',
        ];

        // Mock the User model and its 'with' method
        $userMock = Mockery::mock('alias:App\Models\User');
        $userMock->shouldReceive('with')->with('device_tokens')->andReturn($userMock);
        $userMock->shouldReceive('where')->with(['mobile_with_country_code' => $requestParams['request_to_mobile']])->andReturn($userMock);
        $userMock->shouldReceive('first')->andReturn($userMock);

        // Mock the NotificationController and its method
        $notificationMock = Mockery::mock('overload:App\Http\Controllers\NotificationController');
        $notificationMock->shouldReceive('sendNotificationForMobileAuth')
            ->with(
                $userMock,
                'iVALT',
                $requestParams['request_to_mobile'],
                'ID Request from '.$requestParams['request_from_mobile'],
                $requestParams['request_from_mobile']
            )
            ->andReturn(response()->json(['message' => 'Biometric Authentication successfully done.'], 200));

        $response = $this->json('POST', '/api/send/app-auth/notification', $requestParams);

        $response->assertStatus(200)
            ->assertJson([
                'message' => 'Biometric Authentication successfully done.',
            ]);
    }
}
