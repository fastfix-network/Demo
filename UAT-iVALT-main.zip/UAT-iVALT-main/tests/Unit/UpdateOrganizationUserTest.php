<?php

namespace Tests\Unit;

use Mockery;
use Tests\TestCase;

class UpdateOrganizationUserTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function test_organization_not_found()
    {
        $orgId = 999;
        $userId = 1;

        // Mock Organization model
        $orgModelMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $orgModelMock->shouldReceive('find')->with($orgId)->andReturn(null);

        $response = $this->json('PUT', "/api/organization/{$orgId}/update/user/{$userId}");

        $response->assertStatus(404)->assertJson([
            'error' => [
                'title'  => 'Not Found',
                'detail' => 'Organization not found',
            ],
        ]);
    }

    public function test_user_not_found_in_organization()
    {
        $orgId = 1;
        $userId = 999;

        $organizationMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $organizationMock->shouldReceive('find')->with($orgId)->andReturn($organizationMock);
        $organizationMock->shouldReceive('users->find')
            ->with($userId)
            ->andReturn(null);

        $response = $this->json('PUT', "/api/organization/{$orgId}/update/user/{$userId}");

        $response->assertStatus(404)
            ->assertJson([
                'error' => [
                    'status' => 404,
                    'title'  => 'Not Found',
                    'detail' => 'User not found.',
                ],
            ]);
    }

    public function test_successful_user_update_without_auth0()
    {
        $orgId = 1;
        $userId = 1;

        $requestData = [
            'email'        => 'test@example.com',
            'mobile'       => '1234567890',
            'country_code' => '+1',
            'name'         => 'Test User',
        ];

        $organizationMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $userMock = Mockery::mock('alias:App\Models\User');

        $organizationMock->shouldReceive('find')
            ->with($orgId)
            ->andReturn($organizationMock);
        $organizationMock->shouldReceive('users->find')
            ->with($userId)
            ->andReturn($userMock);
        $userMock->shouldReceive('update')
            ->andReturn(true);

        $response = $this->json('PUT', "/api/organization/{$orgId}/update/user/{$userId}", $requestData);

        $response->assertStatus(200)
            ->assertJson([
                'data' => [
                    'status'  => 200,
                    'message' => 'User updated successfully.',
                ],
            ]);
    }

    public function test_successful_user_update_with_auth0_creation()
    {
        $orgId = 1;
        $userId = 1;

        $requestData = [
            'email'               => 'test@example.com',
            'mobile'              => '1234567890',
            'country_code'        => '+1',
            'name'                => 'Test User',
            'create_auth0_user'   => 'on',
            'auth0_user_password' => 'securepassword',
        ];

        $organizationMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $userMock = Mockery::mock('alias:App\Models\User');
        $auth0ApiMock = Mockery::mock('alias:App\Http\Controllers\Auth0\Auth0ApiController');
        $organizationMock->id = 1;
        $organizationMock->shouldReceive('find')
            ->with($orgId)
            ->andReturn($organizationMock);
        $organizationMock->shouldReceive('users->find')
            ->with($userId)
            ->andReturn($userMock);
        $userMock->shouldReceive('update')
            ->andReturn(true);

        $auth0ApiMock->shouldReceive('checkIfUserExistOnAuth0')
            ->andReturn([]);
        $auth0ApiMock->shouldReceive('createUser')
            ->andReturn(['user_id' => 'auth0_user_id']);

        $response = $this->json('PUT', "/api/organization/{$orgId}/update/user/{$userId}", $requestData);

        $response->assertStatus(200)
            ->assertJson([
                'data' => [
                    'status'  => 200,
                    'message' => 'User updated successfully.',
                ],
            ]);
    }
}
