<?php

namespace Tests\Unit;

use App\Http\Controllers\ServerController;
use App\Services\EmailService;
use Mockery;
use Tests\TestCase;

class CheckIsUserEnrolledTest extends TestCase
{
    /**
     * @var ServerController
     */
    protected ServerController $controller;

    /**
     * @var EmailService | Mockery\LegacyMockInterface
     */
    protected EmailService|Mockery\LegacyMockInterface $emailService;

    /**
     * Test case for missing required parameters.
     *
     * @return void
     */
    public function test_missing_required_parameters()
    {
        // Send POST request with empty data to the is-enrolled route
        $response = $this->json('POST', route('api.is-enrolled'), []);

        // Assert the response is a 400 error with specific error message
        $response->assertStatus(400)->assertJson([
            'error' => [
                'status' => 400,
                'title'  => 'Missing Required Parameters',
            ],
        ]);
    }

    /**
     * Test case for checking if user is not enrolled.
     *
     * @return void
     */
    public function testIsUserEnrolledWithNonEnrolledUser()
    {
        // Mock User model and set up the where and first method
        $userMock = Mockery::mock('alias:App\Models\User');
        $userMock->shouldReceive('where->first')->andReturn(null);

        // Send POST request to the is-enrolled route with mobile number
        $response = $this->json('POST', route('api.is-enrolled'), ['mobile' => '1234567890']);

        // Assert the response contains the expected data
        $response->assertStatus(200)->assertJson([
            'data' => [
                'status'  => true,
                'message' => 'User is not enrolled.',
                'details' => [
                    'is_enrolled'      => 0,
                    'enrollmentStatus' => false,
                ],
            ],
        ]);
    }

    /**
     * Test case for checking if user is enrolled.
     *
     * @return void
     */
    public function testIsUserEnrolledWithEnrolledUser()
    {
        // Mock User model and set up the where method
        $userMock = Mockery::mock('alias:App\Models\User');
        $userMock->shouldReceive('where->first')->andReturnSelf();

        // Send POST request to the is-enrolled route with mobile number
        $response = $this->json('POST', route('api.is-enrolled'), ['mobile' => '1234567890']);

        // Assert the response contains the expected data
        $response->assertStatus(200)->assertJson([
            'data' => [
                'status'  => true,
                'message' => 'User is enrolled.',
                'details' => [
                    'is_enrolled'      => 1,
                    'enrollmentStatus' => true,
                ],
            ],
        ]);
    }

    /**
     * Set up the test environment.
     *
     * @return void
     */
    protected function setUp(): void
    {
        parent::setUp();

        // Mock EmailService
        $this->emailService = Mockery::mock(EmailService::class);

        // Create new instance of ServerController with mocked EmailService
        $this->controller = new ServerController($this->emailService);

        // Disable middleware and exception handling during tests
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    /**
     * Clean up the testing environment before the next test.
     *
     * @return void
     */
    protected function tearDown(): void
    {
        // Close all mockery sessions to avoid warnings
        Mockery::close();
        parent::tearDown();
    }
}
