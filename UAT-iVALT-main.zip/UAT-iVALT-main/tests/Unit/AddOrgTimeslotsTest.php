<?php

namespace Tests\Unit;

use Mockery;
use Tests\TestCase;

class AddOrgTimeslotsTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function testOrganizationNotFound()
    {
        // Mock the Organization model
        $organizationMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $organizationMock->shouldReceive('find')
            ->with(1)
            ->andReturn(null);

        $this->app->instance(Organization::class, $organizationMock);

        // Perform the request
        $response = $this->json('POST', '/api/organization/1/timeslots/add', [
            'timezone'   => 'UTC',
            'start_time' => '09:00',
            'end_time'   => '10:00',
            'status'     => 'active',
        ]);

        // Assert the response
        $response->assertStatus(404)
            ->assertJson([
                'error' => [
                    'status' => 404,
                    'title'  => 'Not Found',
                    'detail' => 'Organization not found',
                ],
            ]);
    }

    public function testMissingRequiredParameters()
    {
        $organizationMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $organizationMock->shouldReceive('find')
            ->with(1)
            ->andReturnSelf();

        $this->app->instance(Organization::class, $organizationMock);

        $response = $this->json('POST', '/api/organization/1/timeslots/add', []);

        $response->assertStatus(400)->assertJson([
            'error' => [
                'status' => 400,
                'title'  => 'Missing Required Parameters',
            ],
        ]);
    }

    public function testSuccessfulTimeslotAddition()
    {
        // Mock the Organization model
        $organizationMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $organizationMock->shouldReceive('find')
            ->with(1)
            ->andReturnSelf();
        $organizationMock->id = 1; // Set the 'id' property

        // Mock the TimeSlot model
        $timeSlotMock = Mockery::mock('alias:App\Models\Organization\TimeSlot');
        $timeSlotMock->shouldReceive('create')
            ->with([
                'org_id'     => 1,
                'timezone'   => json_encode('UTC'),
                'start_time' => '09:00',
                'end_time'   => '10:00',
                'status'     => 'active',
            ])
            ->andReturn((object) [
                'id'         => 1,
                'org_id'     => 1,
                'timezone'   => 'UTC',
                'start_time' => '09:00',
                'end_time'   => '10:00',
                'status'     => 'active',
            ]);

        // Bind the mock instances in the container
        $this->app->instance(Organization::class, $organizationMock);
        $this->app->instance(TimeSlot::class, $timeSlotMock);

        // Perform the request
        $response = $this->json('POST', '/api/organization/1/timeslots/add', [
            'timezone'   => 'UTC',
            'start_time' => '09:00',
            'end_time'   => '10:00',
            'status'     => 'active',
        ]);

        // Assert the response
        $response->assertStatus(200)
            ->assertJson([
                'data' => [
                    'status'  => 'true',
                    'message' => 'Time Slot added to organization',
                    'details' => [
                        'id'         => 1,
                        'org_id'     => 1,
                        'timezone'   => 'UTC',
                        'start_time' => '09:00',
                        'end_time'   => '10:00',
                        'status'     => true, // Update 'status' to match the actual response
                    ],
                ],

            ]);
    }

    public function testFailedTimeslotAddition()
    {
        // Mock the Organization model
        $organizationMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $organizationMock->shouldReceive('find')
            ->with(1)
            ->andReturnSelf();
        $organizationMock->id = 1;

        // Mock the TimeSlot model
        $timeSlotMock = Mockery::mock('alias:App\Models\Organization\TimeSlot');
        $timeSlotMock->shouldReceive('create')
            ->with([
                'org_id'     => 1,
                'timezone'   => json_encode('UTC'),
                'start_time' => '09:00',
                'end_time'   => '10:00',
                'status'     => 'active',
            ])
            ->andReturn(null); // Simulate a failure

        // Bind the mock instances in the container
        $this->app->instance(Organization::class, $organizationMock);
        $this->app->instance(TimeSlot::class, $timeSlotMock);

        // Perform the request
        $response = $this->json('POST', '/api/organization/1/timeslots/add', [
            'timezone'   => 'UTC',
            'start_time' => '09:00',
            'end_time'   => '10:00',
            'status'     => 'active',
        ]);

        // Assert the response
        $response->assertStatus(404)
            ->assertJson([
                'error' => [
                    'status' => 404,
                    'title'  => 'Unprocessable Request',
                    'detail' => 'Time Slot did not add to organization',
                ],
            ]);
    }
}
