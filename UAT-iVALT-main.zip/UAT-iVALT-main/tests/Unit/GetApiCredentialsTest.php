<?php

namespace Tests\Unit;

use Mockery;
use Tests\TestCase;

class GetApiCredentialsTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function test_organization_not_found()
    {
        $orgModelMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $orgId = 1;
        $orgModelMock->shouldReceive('find')->with($orgId)->andReturn(null);

        $response = $this->json('GET', "/api/organization/{$orgId}/get-org-api-creds");
        $response->assertStatus(404)->assertJson([
            'error' => [
                'title'  => 'Not Found',
                'detail' => 'Organization not found',
            ],
        ]);
    }

    public function test_successful_api_credentials_fetch()
    {
        // Mock the Organization model
        $organizationMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $orgId = 1;

        // Set up the mock API credentials data
        $authApiCreds = (object) [
            'client_id'     => 'some-client-id',
            'client_secret' => 'some-client-secret',
        ];

        // Mock the Organization's method for fetching an organization by ID
        $organizationMock->shouldReceive('find')
            ->with($orgId)
            ->andReturn($organizationMock);

        $organizationMock->authApiCreds = $authApiCreds;

        // Perform the API call
        $response = $this->json('GET', "/api/organization/{$orgId}/get-org-api-creds");

        // Assert the response
        $response->assertStatus(200)
            ->assertJson([
                'data' => [
                    'status'  => 'true',
                    'message' => 'Organization auth0 credentials fetched successfully',
                ],

            ]);
    }
}
