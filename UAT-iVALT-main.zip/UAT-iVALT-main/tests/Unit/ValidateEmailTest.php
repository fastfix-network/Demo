<?php

namespace Tests\Unit;

use App\Models\User;
use App\Services\EmailService;
use Mockery;
use Tests\TestCase;

class ValidateEmailTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    public function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function test_missing_parameters()
    {
        // Call the API with missing parameters
        $response = $this->json('GET', '/api/ivalt-email-verification', []);

        // Assert the response
        $response->assertStatus(400);
        $response->assertJson([
            'error' => [
                'status' => 400,
                'title'  => 'Missing Required Parameters',
            ],
        ]);
    }

    public function test_invalid_token()
    {
        // Mock the User model to return null
        $userMock = Mockery::mock('alias:App\Models\User');
        $userMock->shouldReceive('where')
            ->with([
                'temp_email'               => 'test@example.com',
                'email_verification_token' => 'invalid_token',
            ])
            ->andReturnSelf();
        $userMock->shouldReceive('orWhere')
            ->with([
                'email'                    => 'test@example.com',
                'email_verification_token' => 'invalid_token',
            ])
            ->andReturnSelf();
        $userMock->shouldReceive('first')->andReturn(null);

        // Call the API with an invalid token
        $response = $this->json('GET', '/api/ivalt-email-verification', [
            'email' => 'test@example.com',
            'token' => 'invalid_token',
        ], [
            'User-Agent' => 'PostmanRuntime/7.28.4', // Simulate a Postman request
        ]);

        // Assert the response
        $response->assertStatus(404);
        $response->assertJson([
            'error' => [
                'status' => 404,
                'title'  => 'Not Found',
                'detail' => 'The email provided (test@example.com) is not registered with iVALT.',
            ],
        ]);
    }

    public function test_successful_email_verification()
    {

        // Create a mock for the User model
        $userMock = Mockery::mock('alias:App\Models\User');

        // Create a mock user object with properties and mock the update method

        $userMock->temp_email = 'test@example.com';  // Set property directly
        $userMock->email = 'test@example.com';       // Set property directly
        $userMock->name = 'Test User';
        $userMock->mobile_with_country_code = '+1234567890';
        $userMock->shouldReceive('update')
            ->with([
                'email_verification_token' => null,
                'is_email_verified'        => 1,
                'email'                    => 'test@example.com',
            ])
            ->andReturn(true);

        // Mock the `where` and `orWhere` methods to return the user object
        $userMock->shouldReceive('where')
            ->with([
                'temp_email'               => 'test@example.com',
                'email_verification_token' => 'valid_token',
            ])
            ->andReturnSelf();  // Return self for chaining

        $userMock->shouldReceive('orWhere')
            ->with([
                'email'                    => 'test@example.com',
                'email_verification_token' => 'valid_token',
            ])
            ->andReturnSelf();  // Return self for chaining

        // Mock the `first` method to return the mock user object
        $userMock->shouldReceive('first')->andReturn($userMock);

        // Mock the EmailService to send a success email
        $emailServiceMock = Mockery::mock('App\Services\EmailService');
        $emailServiceMock->shouldReceive('sendRegistrationSuccessEmail')
            ->with('test@example.com', 'Test User')
            ->once();

        // Mock the AwsSecretsManagerService
        $awsSecretsManagerServiceMock = Mockery::mock('App\Services\AwsSecretsManagerService');
        $awsSecretsManagerServiceMock->shouldReceive('getCredentials')
            ->with('your_secret_name')
            ->andReturn([
                'AWS_REGION'            => 'us-east-1',
                'AWS_ACCESS_KEY_ID'     => 'fake_access_key',
                'AWS_SECRET_ACCESS_KEY' => 'fake_secret_key',
            ]);

        // Bind the mocks to the application container

        $this->app->instance(AwsSecretsManagerService::class, $awsSecretsManagerServiceMock);
        $this->app->instance(EmailService::class, $emailServiceMock);

        // Call the API with valid token and email
        $response = $this->json('GET', '/api/ivalt-email-verification', [
            'email' => 'test@example.com',
            'token' => 'valid_token',
        ], [
            'User-Agent' => 'PostmanRuntime/7.28.4', // Simulate a Postman request
        ]);

        // Assert the response
        $response->assertStatus(200);
        $response->assertJson([
            'message' => 'Email verified successfully.',
        ]);
    }
}
