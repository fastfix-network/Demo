<?php

namespace Tests\Unit;

use Mockery;
use Tests\TestCase;

class DeleteOrgTimeslotsTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function test_timeslot_not_found()
    {
        // Arrange
        $timeSlotId = 1;
        $timeSlotMock = Mockery::mock('alias:App\Models\Organization\TimeSlot');

        // Mock the find method to return null (indicating the timeslot was not found)
        $timeSlotMock->shouldReceive('find')
            ->with($timeSlotId)
            ->andReturn(null);

        // Act: Perform the API call
        $response = $this->json('DELETE', "/api/timeslot/{$timeSlotId}/delete");

        // Assert: Check that the response indicates the timeslot was not found
        $response->assertStatus(404)
            ->assertJson([
                'error' => [
                    'status' => 404,
                    'detail' => 'TimeSlot not found',
                ],
            ]);
    }

    public function test_unsuccessful_timeslot_deletion()
    {
        // Arrange
        $timeSlotId = 1;
        $timeSlotMock = Mockery::mock('alias:App\Models\Organization\TimeSlot');

        $timeSlotMock
            ->shouldReceive('find')
            ->with($timeSlotId)
            ->andReturn($timeSlotMock);

        // Mock the delete method to return false (indicating unsuccessful deletion)
        $timeSlotMock->shouldReceive('delete')
            ->andReturn(false);

        // Act: Perform the API call
        $response = $this->json('DELETE', "/api/timeslot/{$timeSlotId}/delete");

        // Assert: Check that the response indicates an unsuccessful deletion
        $response->assertStatus(404)
            ->assertJson([
                'error' => [
                    'status' => 404,
                    'detail' => 'Time Slot did not delete yet',
                ],
            ]);
    }

    public function test_successful_timeslot_deletion()
    {
        // Arrange
        $timeSlotId = 1;
        $timeSlotMock = Mockery::mock('alias:App\Models\Organization\TimeSlot');

        $timeSlotMock
            ->shouldReceive('find')
            ->with($timeSlotId)
            ->andReturn($timeSlotMock);

        // Mock the delete method to return true (indicating successful deletion)
        $timeSlotMock->shouldReceive('delete')
            ->andReturn(true);

        // Act: Perform the API call
        $response = $this->json('DELETE', "/api/timeslot/{$timeSlotId}/delete");

        // Assert: Check that the response indicates a successful deletion
        $response->assertStatus(200)
            ->assertJson([
                'data' => [
                    'status'  => 200,
                    'message' => 'Time Slot has been deleted',
                ],
            ]);
    }
}
