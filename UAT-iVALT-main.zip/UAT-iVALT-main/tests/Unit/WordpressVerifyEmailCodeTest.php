<?php

namespace Tests\Unit;

use App\Models\WordpressEmailAuth;
use App\Models\WpUser;
use Mockery;
use Tests\TestCase;

class WordpressVerifyEmailCodeTest extends TestCase
{
    protected string $apiRoute;
    protected array $validPayload;

    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();

        $this->apiRoute = route('api.wordpress.verify.email.code');
        $this->validPayload = [
            'domain'           => 'test.com',
            'email'            => 'test@test.com',
            'verificationCode' => '123456',
            'country_code'     => '91',
            'mobile'           => '1234567890',
        ];
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function test_missing_required_parameters()
    {
        $response = $this->json('POST', $this->apiRoute, []);

        $response->assertStatus(400)
            ->assertJson([
                'error' => [
                    'status' => 400,
                    'title'  => 'Missing Required Parameters',
                ],
            ]);
    }

    public function testUserNotFound()
    {
        $this->mockWpUser()->shouldReceive('firstWhere')->andReturn(null);

        $response = $this->json('POST', $this->apiRoute, $this->validPayload);

        $response->assertStatus(404)
            ->assertJson([
                'error' => [
                    'status' => 404,
                    'title'  => 'Email Verification Failed.',
                    'detail' => 'test.com is not found!',
                ],
            ]);
    }

    public function testInvalidVerificationCode()
    {
        $this->mockWpUser()->shouldReceive('firstWhere')->andReturnSelf();
        $this->mockWordpressEmailAuth()
            ->shouldReceive('where')->andReturnSelf()
            ->shouldReceive('first')->andReturn(null);

        $response = $this->json('POST', $this->apiRoute, $this->validPayload);

        $response->assertStatus(400)
            ->assertJson([
                'error' => [
                    'status' => 400,
                    'title'  => 'Email Verification Failed.',
                    'detail' => 'Invalid verification code!',
                ],
            ]);
    }

    public function testSuccessfulVerification()
    {
        $wpUserMock = $this->mockWpUser();
        $wpUserMock->shouldReceive('firstWhere')->andReturnSelf();
        $wpUserMock->user_token = '123456';

        $this->mockWordpressEmailAuth()
            ->shouldReceive('where')->andReturnSelf()
            ->shouldReceive('first')->andReturnSelf()
            ->shouldReceive('delete')->andReturn(true);

        $response = $this->json('POST', $this->apiRoute, $this->validPayload);

        $response->assertStatus(200)
            ->assertJson([
                'data' => [
                    'status'  => true,
                    'message' => 'Email verified successfully.',
                    'details' => [
                        'token' => '123456',
                    ],
                ],
            ]);
    }

    public function testFailedDeletion()
    {
        $wpUserMock = $this->mockWpUser();
        $wpUserMock->shouldReceive('firstWhere')->andReturnSelf();
        $wpUserMock->user_token = '123456';

        $this->mockWordpressEmailAuth()
            ->shouldReceive('where')->andReturnSelf()
            ->shouldReceive('first')->andReturnSelf()
            ->shouldReceive('delete')->andReturn(false);

        $response = $this->json('POST', $this->apiRoute, $this->validPayload);

        $response->assertStatus(400)
            ->assertJson([
                'error' => [
                    'status' => 400,
                    'title'  => 'Email Verification Failed.',
                    'detail' => 'Invalid verification code!',
                ],
            ]);
    }

    private function mockWpUser()
    {
        return Mockery::mock('alias:'.WpUser::class);
    }

    private function mockWordpressEmailAuth()
    {
        return Mockery::mock('alias:'.WordpressEmailAuth::class);
    }
}
