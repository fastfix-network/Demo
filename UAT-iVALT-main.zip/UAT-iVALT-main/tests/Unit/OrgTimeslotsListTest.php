<?php

namespace Tests\Unit;

use App\Models\Organization\Organization;
use App\Models\Organization\TimeSlot;
use Mockery;
use Tests\TestCase;

class OrgTimeslotsListTest extends TestCase
{
    public function testOrganizationNotFound()
    {
        // Mock the Organization model
        $organizationMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $organizationMock->shouldReceive('find')
            ->with(1)
            ->andReturn(null);

        // Bind the mock instance in the container
        $this->app->instance(Organization::class, $organizationMock);

        // Perform the request
        $response = $this->json('GET', '/api/organization/1/timeslots');

        // Assert the response
        $response->assertStatus(404)
            ->assertJson([
                'error' => [
                    'status' => 404,
                    'title'  => 'Not Found',
                    'detail' => 'Organization not found',
                ],
            ]);
    }

    /**
     * @return void
     */
    public function testSuccessfulTimeslotRetrieval()
    {
        // Mock the Organization model
        $org_id = 1;
        $organizationMock = Mockery::mock('alias:App\Models\Organization\Organization');

        $organizationMock->shouldReceive('find')
            ->with($org_id)
            ->andReturn(new Organization(['id' => $org_id])); // Return an actual Organization instance

        // Mock the TimeSlot model
        $timeSlotMock = Mockery::mock('alias:App\Models\Organization\TimeSlot');
        $timeSlotMock->shouldReceive('where')
            ->with('org_id', $org_id)
            ->andReturnSelf();
        $timeSlotMock->shouldReceive('latest')
            ->andReturnSelf();
        $timeSlotMock->shouldReceive('get')
            ->andReturn(collect([
                (object) [
                    'id'         => 1,
                    'timezone'   => 'UTC',
                    'start_time' => '09:00',
                    'end_time'   => '10:00',
                    'org_id'     => 1,
                    'status'     => 'active',
                ],
                (object) [
                    'id'         => 2,
                    'timezone'   => 'UTC',
                    'start_time' => '10:00',
                    'end_time'   => '11:00',
                    'org_id'     => 1,
                    'status'     => 'inactive',
                ],
            ]));

        // Bind the mock instances in the container
        $this->app->instance(Organization::class, $organizationMock);
        $this->app->instance(TimeSlot::class, $timeSlotMock);

        // Perform the request
        $response = $this->json('GET', '/api/organization/1/timeslots');

        // Assert the response
        $response->assertStatus(200)
            ->assertJson([
                'data' => [
                    'status'  => true,
                    'message' => 'Org timeslots list.',
                    'details' => [
                        [
                            'id'         => 1,
                            'timezone'   => 'UTC',
                            'start_time' => '09:00',
                            'end_time'   => '10:00',
                            'org_id'     => 1,
                            'status'     => 'active',
                        ],
                        [
                            'id'         => 2,
                            'timezone'   => 'UTC',
                            'start_time' => '10:00',
                            'end_time'   => '11:00',
                            'org_id'     => 1,
                            'status'     => 'inactive',
                        ],
                    ],
                ],
            ]);
    }

    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }
}
