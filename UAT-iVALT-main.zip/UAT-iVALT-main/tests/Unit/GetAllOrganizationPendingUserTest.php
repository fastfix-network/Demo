<?php

namespace Tests\Unit;

use Mockery;
use Tests\TestCase;

class GetAllOrganizationPendingUserTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function test_organization_not_found()
    {
        $orgId = 1;

        // Mock Organization model
        $orgModelMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $orgModelMock->shouldReceive('find')->with($orgId)->andReturn(null);

        $response = $this->json('GET', '/api/organization/'.$orgId.'/pending/users');

        $response->assertStatus(404)->assertJson([
            'error' => [
                'title'  => 'Not Found',
                'detail' => 'Organization not found',
            ],
        ]);
    }

    public function test_pending_users_found_successfully()
    {
        $orgId = 1;

        // Create a mock organization
        $orgModelMock = Mockery::mock('alias:App\Models\Organization\Organization');

        // Return the mock organization instance when find is called
        $orgModelMock->shouldReceive('find')->with($orgId)->andReturn($orgModelMock);

        // Mock a collection of pending users
        $pendingUsers = collect([
            (object) ['id' => 1, 'organization_id' => $orgId, 'user_id' => 1, 'is_active' => 0],
            (object) ['id' => 2, 'organization_id' => $orgId, 'user_id' => 2, 'is_active' => 0],
        ]);

        // Mock the pendingUsers method to return the collection
        $orgModelMock->shouldReceive('pendingUsers')->andReturn($pendingUsers);

        // Make the request
        $response = $this->json('GET', '/api/organization/'.$orgId.'/pending/users');

        // Assert the response status and structure
        $response->assertStatus(200)->assertJson([
            'data' => [
                'status'  => 'true',
                'message' => 'Pending Users fetched successfully',

            ],
        ]);
    }

    public function test_no_pending_users_found()
    {
        $orgId = 1;

        // Create a mock organization
        $orgModelMock = Mockery::mock('alias:App\Models\Organization\Organization');

        // Return the mock organization instance when find is called
        $orgModelMock->shouldReceive('find')->with($orgId)->andReturn($orgModelMock);

        // Mock the pendingUsers method to return an empty collection
        $orgModelMock->shouldReceive('pendingUsers')->andReturn(null);

        // Make the request
        $response = $this->json('GET', '/api/organization/'.$orgId.'/pending/users');

        // Assert the response status and structure
        $response->assertStatus(404)->assertJson([
            'error' => [
                'title'  => 'Not Found',
                'detail' => 'Pending Users not found.',
            ],
        ]);
    }
}
