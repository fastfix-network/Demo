<?php

namespace Tests\Unit;

use App\Models\Organization\TimeSlot;
use Mockery;
use Tests\TestCase;

class UpdateOrgTimeslotsTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function testUpdateOrgTimeslots_TimeSlotNotFound()
    {
        $timeSlotMock = Mockery::mock('alias:App\Models\Organization\TimeSlot');
        $timeSlotMock->shouldReceive('find')->andReturn(null);

        $response = $this->json('PUT', '/api/timeslot/1/update', []);

        $response->assertStatus(404);
        $response->assertJson([
            'error' => [
                'status' => '404',
                'title'  => 'Not Found',
                'detail' => 'TimeSlot not found',
            ],

        ]);
    }

    public function testUpdateOrgTimeslots_MissingRequiredParameters()
    {
        $timeSlotMock = Mockery::mock('alias:App\Models\Organization\TimeSlot');
        $timeSlotMock->shouldReceive('find')->andReturn(true);

        $response = $this->json('PUT', '/api/timeslot/1/update', []);

        $response->assertStatus(400);
        $response->assertJson([
            'error' => [
                'status' => 400,
                'title'  => 'Missing Required Parameters',
            ],
        ]);
    }

    public function testUpdateOrgTimeslots_SuccessfulUpdate()
    {
        $timeSlotMock = Mockery::mock('alias:App\Models\Organization\TimeSlot');
        $timeSlotMock->shouldReceive('find')
            ->with(1)
            ->andReturnSelf();

        $timeSlotMock->shouldReceive('update')
            ->with([
                'timezone'   => 'UTC',
                'start_time' => '09:00',
                'end_time'   => '17:00',
                'status'     => 'active',
            ])
            ->andReturn(true);

        $response = $this->json('PUT', '/api/timeslot/1/update', [
            'timezone'   => 'UTC',
            'start_time' => '09:00',
            'end_time'   => '17:00',
            'status'     => 'active',
        ]);

        $response->assertStatus(200)
            ->assertJson([
                'data' => [
                    'status'  => true,
                    'message' => 'Time Slot has been updated',
                ],
            ]);
    }

    public function testUpdateOrgTimeslots_UpdateFails()
    {
        // Mock the TimeSlot model
        $timeSlotMock = Mockery::mock('alias:App\Models\Organization\TimeSlot');

        // Mock the find method to return a valid timeslot instance
        $timeSlotMock->shouldReceive('find')
            ->with(1)
            ->andReturnSelf();

        // Mock the update method to return false (indicating the update failed)
        $timeSlotMock->shouldReceive('update')
            ->with([
                'timezone'   => 'UTC',
                'start_time' => '09:00',
                'end_time'   => '17:00',
                'status'     => 'active',
            ])
            ->andReturn(false);

        // Mock the request payload and call the API
        $response = $this->json('PUT', '/api/timeslot/1/update', [
            'timezone'   => 'UTC',
            'start_time' => '09:00',
            'end_time'   => '17:00',
            'status'     => 'active',
        ]);

        // Assert the response
        $response->assertStatus(404)
            ->assertJson([
                'error' => [
                    'status' => 404,
                    'title'  => 'Unprocessable Request',
                    'detail' => 'Time Slot did not update',
                ],
            ]);
    }
}
