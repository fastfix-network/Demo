<?php

namespace Tests\Unit;

use Mockery;
use Tests\TestCase;

class UpdateOrganizationAuthCodesTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function test_organization_not_found()
    {
        $orgId = 1;
        $authCodeId = 1;
        // Mock Organization model
        $orgModelMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $orgModelMock->shouldReceive('find')->with($orgId)->andReturn(null);

        $response = $this->json('PUT', "/api/organization/{$orgId}/update/auth-code/{$authCodeId}");

        $response->assertStatus(404)->assertJson([
            'error' => [
                'title'  => 'Not Found',
                'detail' => 'Organization not found',
            ],
        ]);
    }

    public function test_auth_code_not_found()
    {
        $orgId = 1;
        $authCodeId = 1;
        $request = ['client_id' => 'new_client_id', 'client_secret' => 'new_client_secret'];

        // Mock Organization model
        $orgModelMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $orgModelMock->shouldReceive('find')->with($orgId)->andReturn($orgModelMock);

        // Mock authCodes relationship method
        $authCodeMock = Mockery::mock('alias:App\Models\Organization\OrganizationAuthCode');
        $authCodeMock->shouldReceive('find')->with($authCodeId)->andReturn(null);

        $orgModelMock->shouldReceive('authCodes')->andReturn($authCodeMock);

        $response = $this->json('PUT', "/api/organization/{$orgId}/update/auth-code/{$authCodeId}", $request);

        $response->assertStatus(404)->assertJson([
            'error' => [
                'title'  => 'Not Found',
                'detail' => 'Org Auth Code not found.',
            ],
        ]);
    }

    public function test_successful_auth_code_update()
    {
        $orgId = 1;
        $authCodeId = 1;
        $request = ['client_secret' => 'new_client_secret'];

        // Mock Organization model
        $orgModelMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $orgModelMock->shouldReceive('find')->with($orgId)->andReturn($orgModelMock);

        // Mock authCodes relationship method
        $authCodeMock = Mockery::mock('alias:App\Models\Organization\OrganizationAuthCode');
        $authCodeMock->shouldReceive('find')->with($authCodeId)->andReturn($authCodeMock);
        $authCodeMock->shouldReceive('update')->with($request)->andReturn(true);

        $orgModelMock->shouldReceive('authCodes')->andReturn($authCodeMock);
        $orgModelMock->shouldReceive('authCodes->find')->with($authCodeId)->andReturn((object) ['id' => $authCodeId, 'client_secret' => 'new_client_secret']);

        $response = $this->json('PUT', "/api/organization/{$orgId}/update/auth-code/{$authCodeId}", $request);

        $response->assertStatus(200)->assertJson([
            'data' => [
                'status'  => true,
                'message' => 'Org Auth Code updated successfully.',

            ],
        ]);
    }

    public function test_auth_code_update_failed()
    {
        $orgId = 1;
        $authCodeId = 1;
        $requestData = ['client_secret' => 'new_client_secret'];

        // Mock Organization model
        $orgModelMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $orgModelMock->shouldReceive('find')->with($orgId)->andReturn($orgModelMock);

        // Mock authCodes relationship method
        $authCodeMock = Mockery::mock('alias:App\Models\Organization\OrganizationAuthCode');
        $authCodeMock->shouldReceive('find')->with($authCodeId)->andReturn($authCodeMock);
        $authCodeMock->shouldReceive('update')->with($requestData)->andReturn(false);

        $orgModelMock->shouldReceive('authCodes')->andReturn($authCodeMock);

        $response = $this->json('PUT', "/api/organization/{$orgId}/update/auth-code/{$authCodeId}", $requestData);

        $response->assertStatus(404)->assertJson([
            'error' => [
                'title'  => 'Not Found',
                'detail' => 'Org Auth Code not updated.',
            ],
        ]);
    }
}
