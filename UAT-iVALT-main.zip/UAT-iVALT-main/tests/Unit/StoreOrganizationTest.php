<?php

namespace Tests\Unit;

use Mockery;
use Tests\TestCase;

class StoreOrganizationTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function test_missing_required_parameters()
    {
        $response = $this->json('POST', '/api/organization/create', []);

        // Assert
        $response->assertStatus(400)
            ->assertJson([
                'error' => [
                    'status' => 400,
                    'title'  => 'Missing Required Parameters',
                ],
            ]);
    }

    public function test_organization_already_exists()
    {
        $organizationMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $organizationMock->shouldReceive('where->orWhere->count')
            ->andReturn(1);

        $response = $this->json('POST', '/api/organization/create', [
            'name'               => 'Existing Organization',
            'organization_code'  => 'EXIST123',
            'has_geo_fencing'    => true,
            'number_geo_fencing' => 5,
            'is_active'          => true,
        ]);

        $response->assertStatus(403)
            ->assertJson([
                'error' => [
                    'status' => 403,
                    'title'  => 'Failed',
                    'detail' => 'Organization Already Exist.',
                ],
            ]);
    }

    public function test_successful_organization_creation()
    {
        $data = [
            'name'               => 'New Organization',
            'organization_code'  => 'NEWORG123',
            'has_geo_fencing'    => true,
            'number_geo_fencing' => 5,
            'is_active'          => true,
        ];

        $authCodesMock = Mockery::mock('App\Models\Organization\OrganizationAuthCode');
        $organizationMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $organizationMock->shouldReceive('where->orWhere->count')
            ->andReturn(0);

        $organizationMock->shouldReceive('create')
            ->andReturn($organizationMock);

        $organizationMock->shouldReceive('authCodes->count')
            ->andReturn(0);
        $organizationMock->shouldReceive('authCodes->create')
            ->andReturn(true);

        $response = $this->json('POST', '/api/organization/create', $data);

        // Assert
        $response->assertStatus(200)
            ->assertJson([
                'data' => [
                    'status'  => true,
                    'message' => 'Organization user created successfully.',
                ],
            ]);
    }

    public function test_organization_creation_failure()
    {
        $data = [
            'name'               => 'New Organization',
            'organization_code'  => 'NEWORG123',
            'has_geo_fencing'    => true,
            'number_geo_fencing' => 5,
            'is_active'          => true,
        ];

        $authCodesMock = Mockery::mock('App\Models\Organization\OrganizationAuthCode');
        $organizationMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $organizationMock->shouldReceive('where->orWhere->count')
            ->andReturn(0);

        $organizationMock->shouldReceive('create')
            ->andReturn(null);

        $organizationMock->shouldReceive('authCodes->count')
            ->andReturn(1);
        $organizationMock->shouldReceive('authCodes->create')
            ->andReturn(null);
        $organizationMock->shouldReceive('create')
            ->andReturn(false);

        $response = $this->json('POST', '/api/organization/create', $data);

        // Assert
        $response->assertStatus(404)
            ->assertJson([
                'error' => [
                    'status' => 404,
                    'title'  => 'Operation failed',
                    'detail' => 'Something went wrong!',
                ],
            ]);
    }
}
