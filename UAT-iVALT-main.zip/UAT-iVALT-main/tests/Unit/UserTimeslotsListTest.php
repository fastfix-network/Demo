<?php

namespace Tests\Unit;

use Mockery;
use Tests\TestCase;

class UserTimeslotsListTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function test_user_not_found()
    {
        // Mock the User model
        $userMock = Mockery::mock('alias:App\Models\User');
        $userId = 1;

        $userMock->shouldReceive('find')
            ->with($userId)
            ->andReturn(null);

        $response = $this->json('GET', "/api/user/{$userId}/timeslots");

        $response->assertStatus(404)
            ->assertJson([
                'error' => [
                    'status' => 404,
                    'detail' => 'User not found',
                ],
            ]);
    }

    public function test_user_timeslots_not_found()
    {
        // Mock the User model
        $userMock = Mockery::mock('alias:App\Models\User');
        $userId = 1;

        $userMock->shouldReceive('find')
            ->with($userId)
            ->andReturn($userMock);

        $userMock->shouldReceive('orgTimeSlots')
            ->andReturn(null);

        // Perform the API call
        $response = $this->json('GET', "/api/user/{$userId}/timeslots");

        // Assert the response
        $response->assertStatus(404)
            ->assertJson([
                'error' => [
                    'status' => 404,
                    'detail' => 'User timeslots not found',
                ],
            ]);
    }

    public function test_successful_user_timeslots_fetch()
    {
        // Mock the User model
        $userMock = Mockery::mock('alias:App\Models\User');
        $userId = 1;
        $mockTimeslots = collect([
            (['id' => 1, 'timezone' => 'UTC', 'start_time' => '09:00', 'end_time' => '10:00', 'org_id' => 1, 'status' => 1]),
            (['id' => 2, 'timezone' => 'UTC', 'start_time' => '10:00', 'end_time' => '11:00', 'org_id' => 1, 'status' => 1]),
        ]);

        // Mock the User's method for fetching a user by ID
        $userMock->shouldReceive('find')
            ->with($userId)
            ->andReturn($userMock);

        // Mock the User's method for fetching orgTimeSlots
        $userMock->shouldReceive('orgTimeSlots')
            ->andReturn($mockTimeslots);

        // Perform the API call
        $response = $this->json('GET', "/api/user/{$userId}/timeslots");

        // Assert the response
        $response->assertStatus(200)
            ->assertJson([
                'data' => [
                    'status'  => 200,
                    'message' => 'User timeslots list.',
                ],
            ]);
    }
}
