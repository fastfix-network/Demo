<?php

namespace Tests\Unit;

use Illuminate\Support\Facades\Auth;
use Mockery;
use Tests\TestCase;

class GenerateAuthTokenTest extends TestCase
{
    protected string $apiRoute;

    /**
     * Set up the test environment before each test case.
     */
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
        $this->apiRoute = route('api.generate.auth.token');
    }

    /**
     * Closes any Mockery mocks and then calls the parent tearDown method.
     */
    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function testMissingRequiredParameters()
    {
        $response = $this->json('POST', $this->apiRoute, []);

        $response->assertStatus(400)
            ->assertJson([
                'error' => [
                    'status' => 400,
                    'title'  => 'Missing Required Parameters',
                ],
            ]);
    }

    /**
     * Test the invalid client credentials scenario.
     *
     * This test case verifies that the API returns a 404 status code and the
     * expected JSON response when the client credentials provided in the
     * request data are invalid.
     *
     * @return void
     */
    public function testInvalidClientCredentials()
    {
        $requestData = [
            'client_id'     => 'invalid_client_id',
            'client_secret' => 'invalid_client_secret',
        ];

        $personalAccessClientMock = Mockery::mock('alias:App\Models\PersonalAccessClient');
        $personalAccessClientMock->shouldReceive('where')
            ->with([
                'client_id'     => $requestData['client_id'],
                'client_secret' => $requestData['client_secret'],
            ])
            ->andReturnSelf();
        $personalAccessClientMock->shouldReceive('first')
            ->andReturn(null);

        $response = $this->json('POST', $this->apiRoute, $requestData);

        $response->assertStatus(404)
            ->assertJson([
                'error' => [
                    'status' => 404,
                    'title'  => 'Not Found',
                    'detail' => 'Invalid client credentials',
                ],
            ]);
    }

    /**
     * Test the successful generation of a token.
     *
     * This test case verifies that the token generation process is successful
     * when valid client ID and client secret are provided in the request data.
     * It mocks the necessary dependencies and asserts that the response status
     * is 200 and the JSON response contains the expected data.
     *
     * @return void
     */
    public function testSuccessfulTokenGeneration()
    {
        $requestData = [
            'client_id'     => 'valid_client_id',
            'client_secret' => 'valid_client_secret',
        ];

        $personalAccessClientMock = Mockery::mock('alias:App\Models\PersonalAccessClient');
        $personalAccessClientMock->shouldReceive('where')
            ->with([
                'client_id'     => $requestData['client_id'],
                'client_secret' => $requestData['client_secret'],
            ])
            ->andReturnSelf();
        $personalAccessClientMock->shouldReceive('first')
            ->andReturn((object) ['id' => 1]);

        $userMock = Mockery::mock('alias:App\Models\User');
        $userMock->shouldReceive('createToken')
            ->andReturn((object) ['plainTextToken' => 'generated_token']);

        Auth::shouldReceive('guard')
            ->with('api')
            ->andReturnSelf();
        Auth::shouldReceive('loginUsingId')
            ->with(1)
            ->andReturn(true);
        Auth::shouldReceive('user')
            ->andReturn($userMock);

        $response = $this->json('POST', $this->apiRoute, $requestData);

        $response->assertStatus(200)
            ->assertJson([
                'data' => [
                    'status'  => true,
                    'message' => 'Authentication token successfully generated.',
                ],
            ]);
    }
}
