<?php

namespace Tests\Unit;

use Mockery;
use Tests\TestCase;

class CreateOrUpdateApiCredentialsTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function test_organization_not_found()
    {
        $orgModelMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $orgId = 1;
        $orgModelMock->shouldReceive('find')->with($orgId)->andReturn(null);

        $response = $this->json('POST', "/api/organization/{$orgId}/auth0-api-creds", []);
        $response->assertStatus(404)->assertJson([
            'error' => [
                'title'  => 'Not Found',
                'detail' => 'Organization not found',
            ],
        ]);
    }

    public function test_missing_required_parameters()
    {

        $organizationMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $orgId = 1;
        $organizationMock->id = $orgId;

        $organizationMock->shouldReceive('find')
            ->with($orgId)
            ->andReturn($organizationMock);

        $response = $this->json('POST', "/api/organization/{$orgId}/auth0-api-creds", []);

        // Assert the response
        $response->assertStatus(400)
            ->assertJson([
                'error' => [
                    'status' => 400,
                    'title'  => 'Missing Required Parameters',
                ],
            ]);
    }

    public function test_create_api_credentials()
    {
        // Mock the Organization and AuthApiCredentials models
        $organizationMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $authApiCredentialsMock = Mockery::mock('alias:App\Models\Organization\AuthApiCredentials');

        $orgId = 1;
        $organizationMock->id = $orgId;
        $organizationMock->authApiCreds = null;

        $organizationMock->shouldReceive('find')
            ->with($orgId)
            ->andReturn($organizationMock);

        // Mock the authApiCredentials method to return the mock relationship
        $organizationMock->shouldReceive('authApiCredentials')
            ->andReturn($authApiCredentialsMock);

        // Mock the creation of AuthApiCredentials
        $authApiCredentialsMock->shouldReceive('create')
            ->andReturn((object) ['domain' => 'test-domain', 'client_id' => 'test-client-id', 'client_secret' => 'test-client-secret', 'grant_type' => 'test-grant-type', 'audience' => 'test-audience']);

        // Perform the API call with required parameters
        $response = $this->json('POST', "/api/organization/{$orgId}/auth0-api-creds", [
            'domain'        => 'test-domain',
            'client_id'     => 'test-client-id',
            'client_secret' => 'test-client-secret',
            'grant_type'    => 'test-grant-type',
            'audience'      => 'test-audience',
        ]);

        // Assert the response
        $response->assertStatus(200)
            ->assertJson([
                'data' => [
                    'status'  => 200,
                    'message' => 'Org Auth0 Api Credentials Updated successfully.',
                ],
            ]);
    }

    public function test_update_api_credentials()
    {
        // Mock the Organization and AuthApiCredentials models
        $organizationMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $authApiCredentialsMock = Mockery::mock('alias:App\Models\Organization\AuthApiCredentials');

        $orgId = 1;
        $organizationMock->id = $orgId;
        $organizationMock->authApiCreds = (object) ['domain' => 'existing-domain', 'client_id' => 'existing-client-id', 'client_secret' => 'existing-client-secret', 'grant_type' => 'existing-grant-type', 'audience' => 'existing-audience'];

        // Mock the Organization's method for fetching an organization by ID
        $organizationMock->shouldReceive('find')
            ->with($orgId)
            ->andReturn($organizationMock);

        // Mock the authApiCredentials method to return the mock relationship
        $organizationMock->shouldReceive('authApiCredentials')
            ->andReturn($authApiCredentialsMock);

        // Mock the update of AuthApiCredentials
        $authApiCredentialsMock->shouldReceive('update')
            ->andReturn((object) ['domain' => 'updated-domain', 'client_id' => 'updated-client-id', 'client_secret' => 'updated-client-secret', 'grant_type' => 'updated-grant-type', 'audience' => 'updated-audience']);

        // Perform the API call with required parameters
        $response = $this->json('POST', "/api/organization/{$orgId}/auth0-api-creds", [
            'domain'        => 'updated-domain',
            'client_id'     => 'updated-client-id',
            'client_secret' => 'updated-client-secret',
            'grant_type'    => 'updated-grant-type',
            'audience'      => 'updated-audience',
        ]);

        // Assert the response
        $response->assertStatus(200)
            ->assertJson([
                'data' => [
                    'status'  => 200,
                    'message' => 'Org Auth0 Api Credentials Updated successfully.',
                ],
            ]);
    }
}
