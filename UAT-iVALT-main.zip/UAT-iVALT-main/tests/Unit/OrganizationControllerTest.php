<?php

namespace Tests\Unit;

use Tests\TestCase;

class OrganizationControllerTest extends TestCase
{
    public function it_fetches_all_organizations()
    {
        // Act: Make a GET request to fetch all organizations
        $response = $this->json('GET', '/api/organizations');

        // Assert: Check the response status and structure
        $response->assertStatus(200)
            ->assertJsonStructure([
                'data' => [
                    'status',
                    'message',
                ],
            ]);
    }

    public function it_fetches_a_single_organization()
    {
        // Arrange: Assume an existing organization ID
        $organizationId = 331; // Replace with an actual ID from your database

        // Act: Make a GET request to fetch the organization by ID
        $response = $this->json('GET', '/api/organization/'.$organizationId);

        // Assert: Check the response status and structure
        $response->assertStatus(200)
            ->assertJsonStructure([
                'data' => [
                    'status',
                    'message',

                ],
            ]);
    }

    public function it_returns_error_if_organization_not_found()
    {
        // Act: Make a GET request to fetch a non-existent organization
        $response = $this->json('GET', '/api/organization/000');

        // Assert: Check the response status and structure
        $response->assertStatus(404)
            ->assertJson([
                'data'  => null,
                'error' => [

                    'title'  => 'Not Found',
                    'status' => 404,
                    'detail' => 'Organization not found',

                ],
            ]);
    }
}
