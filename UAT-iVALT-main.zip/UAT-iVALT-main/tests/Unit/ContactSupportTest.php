<?php

namespace Tests\Unit;

use App\Services\EmailService;
use Illuminate\Http\JsonResponse;
use Mockery;
use Tests\TestCase;

class ContactSupportTest extends TestCase
{
    protected $controller;

    protected $mockEmailService;

    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();

        // Mock EmailService
        $this->mockEmailService = Mockery::mock(EmailService::class);
        $this->app->instance(EmailService::class, $this->mockEmailService);
    }

    protected function tearDown(): void
    {
        // Close Mockery
        Mockery::close();
        parent::tearDown();
    }

    /** @test */
    public function test_missing_required_parameters()
    {
        // Create a request with missing parameters
        $response = $this->json('POST', 'api/contact/support', []);

        // Assert the response
        $response->assertStatus(400)->assertJson([
            'error' => [
                'status' => 400,
                'title'  => 'Missing Required Parameters',
            ],
        ]);
    }

    /** @test */
    public function test_successful_email_sending()
    {
        // Mock the sendContactUsEmail method
        $this->mockEmailService->shouldReceive('sendContactUsEmail')
            ->once()
            ->with('baldev@ivalt.com', 'Support Request', Mockery::type('string'))
            ->andReturn(new JsonResponse(null, 200)); // Use the imported class

        // Create a request with valid data
        $response = $this->json('POST', 'api/contact/support', [
            'mobile'  => '1234567890',
            'email'   => 'test@example.com',
            'message' => 'This is a test message.',
        ]);

        // Assert the response
        $response->assertStatus(200)->assertJson([
            'data' => [
                'status'  => true,
                'message' => 'Email sent successfully.',
                'details' => null,
            ],
        ]);

        // Verify sendContactUsEmail was called
        $this->mockEmailService->shouldHaveReceived('sendContactUsEmail')
            ->once()
            ->with('baldev@ivalt.com', 'Support Request', Mockery::type('string'));
    }
}
