<?php

namespace Tests\Unit;

use App\Models\WordpressEmailAuth;
use App\Models\WpUser;
use Mockery;
use Tests\TestCase;

class WordpressConfirmWpAuthTest extends TestCase
{
    protected string $apiRoute;
    protected array $validPayload;

    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();

        $this->apiRoute = route('api.wordpress.check.confirmation');
        $this->validPayload = [
            'country_code'     => '91',
            'mobile'           => '1234567890',
            'domain'           => 'test.com',
            'token'            => 'test',
        ];
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function testMissingRequiredParameters()
    {
        $response = $this->json('POST', $this->apiRoute, []);

        $response->assertStatus(400)
            ->assertJson([
                'error' => [
                    'status' => 400,
                    'title'  => 'Missing Required Parameters',
                ],
            ]);
    }

    public function testMobileNotRegistered()
    {
        $this->mockWpUser()->shouldReceive('firstWhere')->andReturn(null);

        $response = $this->json('POST', $this->apiRoute, $this->validPayload);

        $response->assertStatus(404)
            ->assertJson([
                'error' => [
                    'status' => 404,
                    'title'  => 'Not Found',
                    'detail' => 'An authorization request for mobile number ('.$this->validPayload['country_code'].$this->validPayload['mobile'].') was not found for website ('.$this->validPayload['domain'].'). Please resend the Authorization request.',
                ],
            ]);
    }

    public function testMobileRegistered()
    {
        $mockWpUser = $this->mockWpUser();
        $mockWpUser->shouldReceive('firstWhere')->with(['country_code' => $this->validPayload['country_code'], 'mobile' => $this->validPayload['mobile'], 'website' => $this->validPayload['domain'], 'user_token' => $this->validPayload['token']])->andReturnSelf();
        $mockWpUser->shouldReceive('getAttribute')->with('confirmed')->andReturn(1);
        $mockWpUser->confirmed = 1;
        $mockWpUser->app_auth_status = 1;

        $response = $this->json('POST', $this->apiRoute, $this->validPayload);

        $response->assertStatus(200)
            ->assertJson([
                'data' => [
                    'status'  => true,
                    'message' => 'User authenticate successfull.',
                    'details' => [
                        'confirm'     => 1,
                        'auth_status' => 1,
                    ],
                ],
            ]);
    }

    private function mockWpUser()
    {
        return Mockery::mock('alias:'.WpUser::class);
    }

    private function mockWordpressEmailAuth()
    {
        return Mockery::mock('alias:'.WordpressEmailAuth::class);
    }
}
