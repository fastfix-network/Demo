<?php

namespace Tests\Unit;

use App\Models\Organization\Organization;
use Mockery;
use Tests\TestCase;

class GetAllOrganizationsTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    /**
     * Test successful retrieval of all organizations
     */
    public function testGetAllOrganizationsSuccess()
    {
        // Arrange
        $organizationMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $organizations = collect([
            ['id' => 1, 'name' => 'Org 1', 'organization_code' => 'ORG001', 'has_geo_fencing' => true, 'number_geo_fencing' => 5, 'is_active' => true],
            ['id' => 2, 'name' => 'Org 2', 'organization_code' => 'ORG002', 'has_geo_fencing' => false, 'number_geo_fencing' => 0, 'is_active' => false],
        ]);

        $organizationMock->shouldReceive('get')
            ->andReturn($organizations);

        $this->app->instance(Organization::class, $organizationMock);

        // Act
        $response = $this->json('GET', '/api/organizations');

        // Assert
        $response->assertStatus(200)
            ->assertJson([
                'data' => [
                    'status'  => true,
                    'message' => 'Organizations fetched successfully',

                ],
            ]);
    }
}
