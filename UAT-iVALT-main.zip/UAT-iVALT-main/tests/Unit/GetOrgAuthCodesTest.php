<?php

namespace Tests\Unit;

use App\Models\Organization\Organization;
use Mockery;
use Tests\TestCase;

class GetOrgAuthCodesTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function test_organization_not_found()
    {
        $orgId = 1;

        // Mock Organization model
        $orgModelMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $orgModelMock->shouldReceive('find')->with($orgId)->andReturn(null);

        $response = $this->json('GET', "/api/organization/{$orgId}/get-org-auth-codes");

        $response->assertStatus(404)->assertJson([
            'error' => [
                'title'  => 'Not Found',
                'detail' => 'Organization not found',
            ],
        ]);
    }

    public function test_organization_with_auth_code()
    {
        $orgId = 1;
        $authCode = (object) [
            'code'        => 'AUTH1',
            'description' => 'First auth code',
        ];

        // Mock Organization model
        $orgModelMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $orgModelMock->shouldReceive('find')->with($orgId)->andReturn($orgModelMock);

        // Mock authCodes relationship method
        $orgModelMock->shouldReceive('authCodes')->andReturn($authCode);

        $response = $this->json('GET', "/api/organization/{$orgId}/get-org-auth-codes");

        $response->assertStatus(200)->assertJson([
            'data' => [
                'status'  => 'success',
                'message' => 'Organization auth codes fetched successfully',
            ],
        ]);
    }
}
