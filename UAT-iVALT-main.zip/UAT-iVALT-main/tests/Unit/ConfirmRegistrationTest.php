<?php

namespace Tests\Unit;

use App\Http\Controllers\ServerController;
use App\Models\RegisterOtp;
use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Http\JsonResponse;
use Mockery;
use Tests\TestCase;

class ConfirmRegistrationTest extends TestCase
{
    use WithFaker;

    protected $registerOtp;

    protected function setUp(): void
    {
        parent::setUp();

        // Mocking the RegisterOtp model
        $this->registerOtp = Mockery::mock('alias:App\Models\RegisterOtp');
    }

    protected function tearDown(): void
    {
        Mockery::close();

        parent::tearDown();
    }

    /**
     * Test case for missing required parameters.
     */
    public function test_missing_required_parameters()
    {
        $response = $this->postJson('/api/wp/confirm/register', []);

        $response->assertStatus(400)
            ->assertJson([
                'error' => [
                    'title'  => 'Missing Required Parameters',
                    'status' => 400,
                ],
            ]);
    }

    /**
     * Test case for invalid OTP.
     */
    public function test_invalid_otp()
    {
        $requestData = [
            'mobile'       => '1234567890',
            'user_code'    => '123456',
            'country_code' => '+91',
        ];

        $this->registerOtp->shouldReceive('where')
            ->with(['mobile' => $requestData['country_code'].$requestData['mobile'], 'otp' => $requestData['user_code']])
            ->andReturnSelf();
        $this->registerOtp->shouldReceive('count')
            ->andReturn(0); // OTP is invalid

        $response = $this->postJson('/api/wp/confirm/register', $requestData);

        $response->assertStatus(422)
            ->assertJson([
                'error' => [
                    'title'  => 'Invalid OTP',
                    'detail' => 'The OTP provided is not valid.',
                ],
            ]);
    }

    /**
     * Test case for valid OTP and successful registration.
     */
    public function test_valid_otp_and_successful_registration()
    {
        $requestData = [
            'mobile'       => '1234567890',
            'user_code'    => '123456',
            'country_code' => '+91',
        ];

        $this->registerOtp->shouldReceive('where')
            ->with(['mobile' => $requestData['country_code'].$requestData['mobile'], 'otp' => $requestData['user_code']])
            ->andReturnSelf();
        $this->registerOtp->shouldReceive('count')
            ->andReturn(1); // OTP is valid
        $this->registerOtp->shouldReceive('where')
            ->with(['mobile' => $requestData['country_code'].$requestData['mobile']])
            ->andReturnSelf();
        $this->registerOtp->shouldReceive('delete')
            ->andReturn(true);

        // Mock the registerUser method call in the controller
        $serverControllerMock = Mockery::mock(ServerController::class)->makePartial();
        $serverControllerMock->shouldReceive('registerUser')
            ->andReturn(new JsonResponse([
                'data' => [
                    'message' => 'User registered successfully.',
                ],
            ], 200));

        // Act as if the controller is being called directly
        $response = $serverControllerMock->confirmRegistration(new \Illuminate\Http\Request($requestData));

        // Assertions
        $this->assertEquals(200, $response->getStatusCode());
        $this->assertEquals('User registered successfully.', $response->getData()->data->message);
    }
}
