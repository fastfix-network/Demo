<?php

namespace Tests\Unit;

use Mockery;
use Tests\TestCase;

class GetOrganizationByIdOrSlugTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function testGetOrganizationByIdOrSlugOrganizationNotFound()
    {
        // Arrange
        $orgIdOrSlug = 'nonexistent-slug';
        $organizationMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $organizationMock->shouldReceive('where')
            ->once()
            ->with('id', $orgIdOrSlug)
            ->andReturnSelf();
        $organizationMock->shouldReceive('orWhere')
            ->once()
            ->with('organization_code', $orgIdOrSlug)
            ->andReturnSelf();
        $organizationMock->shouldReceive('first')
            ->andReturn(null);

        // Act
        $response = $this->json('GET', '/api/organization/'.$orgIdOrSlug);

        // Assert
        $response->assertStatus(404)
            ->assertJson([
                'error' => [
                    'title'  => 'Not Found',
                    'status' => 404,
                    'detail' => 'Organization not found',
                ],
            ]);
    }

    public function testGetOrganizationByIdOrSlugOrganizationFoundById()
    {
        $orgIdOrSlug = 1;

        $organizationMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $organizationMock->shouldReceive('where')
            ->once()
            ->with('id', $orgIdOrSlug)
            ->andReturnSelf();

        $organizationMock->shouldReceive('orWhere')
            ->once()
            ->with('organization_code', $orgIdOrSlug)
            ->andReturnSelf();

        $organizationMock->shouldReceive('first')
            ->andReturnSelf();

        // Act
        $response = $this->json('GET', '/api/organization/'.$orgIdOrSlug);

        // Assert
        $response->assertStatus(200)
            ->assertJson([
                'data' => [
                    'status'  => 200,
                    'message' => 'Organizations fetched successfully',
                ],

            ]);
    }

    public function testGetOrganizationByIdOrSlugOrganizationFoundBySlug()
    {
        // Arrange
        $orgIdOrSlug = 'test-org';

        $organizationMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $organizationMock->shouldReceive('where')
            ->once()
            ->with('id', $orgIdOrSlug)
            ->andReturnSelf();
        $organizationMock->shouldReceive('orWhere')
            ->once()
            ->with('organization_code', $orgIdOrSlug)
            ->andReturnSelf();
        $organizationMock->shouldReceive('first')
            ->andReturnSelf();

        // Act
        $response = $this->json('GET', '/api/organization/'.$orgIdOrSlug);

        // Assert
        $response->assertStatus(200)
            ->assertJson([
                'data' => [
                    'status'  => 200,
                    'message' => 'Organizations fetched successfully',
                ],
            ]);
    }
}
