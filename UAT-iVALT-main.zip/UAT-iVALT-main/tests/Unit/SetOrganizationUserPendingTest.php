<?php

namespace Tests\Unit;

use Mockery;
use Tests\TestCase;

class SetOrganizationUserPendingTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function test_organization_not_found()
    {
        $orgId = 1;
        $userId = 1;

        // Mock Organization model
        $orgModelMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $orgModelMock->shouldReceive('find')->with($orgId)->andReturn(null);

        $response = $this->json('POST', "/api/organization/{$orgId}/user/{$userId}/pending");

        $response->assertStatus(404)->assertJson([
            'error' => [
                'title'  => 'Not Found',
                'detail' => 'Organization not found',
            ],
        ]);
    }

    public function test_user_not_found_in_organization()
    {
        $orgId = 1;
        $userId = 1;

        // Mock Organization model
        $orgModelMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $orgModelMock->shouldReceive('find')->with($orgId)->andReturn($orgModelMock);

        // Mock users() method to return a mock of the relationship query builder
        $userMock = Mockery::mock('alias:App\Models\User');
        $orgModelMock->shouldReceive('users')->andReturn($userMock);
        $userMock->shouldReceive('find')->with($userId)->andReturn(null);

        $response = $this->json('POST', "/api/organization/{$orgId}/user/{$userId}/pending");

        $response->assertStatus(404)->assertJson([
            'error' => [
                'title'  => 'Not Found',
                'detail' => 'User not found',
            ],
        ]);
    }

    public function test_user_status_updated_successfully()
    {
        $orgId = 1;
        $userId = 1;

        // Mock Organization model
        $orgModelMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $orgModelMock->shouldReceive('find')->with($orgId)->andReturn($orgModelMock);

        // Mock users() relationship
        $usersMock = Mockery::mock('alias:Illuminate\Database\Eloquent\Relations\BelongsToMany');
        $orgModelMock->shouldReceive('users')->andReturn($usersMock);
        $usersMock->shouldReceive('find')->with($userId)->andReturn($orgModelMock); // Mocking find method on users relationship
        $usersMock->shouldReceive('detach')->with($userId)->andReturn(true); // Mocking detach method

        // Mock pendingUsers() relationship
        $pendingUsersMock = Mockery::mock('alias:Illuminate\Database\Eloquent\Relations\BelongsToMany');
        $orgModelMock->shouldReceive('pendingUsers')->andReturn($pendingUsersMock);
        $pendingUsersMock->shouldReceive('where')->with('id', $userId)->andReturn($pendingUsersMock); // Mocking where method
        $pendingUsersMock->shouldReceive('count')->andReturn(0); // Mocking count method
        $pendingUsersMock->shouldReceive('detach')->with($userId)->andReturn(true); // Mocking detach method
        $pendingUsersMock->shouldReceive('attach')->with($userId)->andReturn(true); // Mocking attach method

        // Make the request
        $response = $this->json('POST', "/api/organization/{$orgId}/user/{$userId}/pending");

        // Assert the response
        $response->assertStatus(200)->assertJson([
            'data' => [
                'status'  => true,
                'message' => 'User status updated successfully.',
            ],
        ]);
    }
}
