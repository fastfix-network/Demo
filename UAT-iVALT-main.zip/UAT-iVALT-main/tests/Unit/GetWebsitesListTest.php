<?php

namespace Tests\Unit;

use App\Http\Controllers\ServerController;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Mockery;
use Tests\TestCase;

class GetWebsitesListTest extends TestCase
{
    protected $wpUserMock;

    protected function setUp(): void
    {
        parent::setUp();
        $this->wpUserMock = Mockery::mock('alias:App\Models\WpUser');
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function testGetWebsitesListMissingMobile()
    {
        $request = Mockery::mock(Request::class);
        $request->shouldReceive('has')->with('mobile')->andReturn(false);
        $request->shouldReceive('all')->andReturn([]);

        $controller = Mockery::mock(ServerController::class)
            ->makePartial()
            ->shouldAllowMockingProtectedMethods();

        $controller->shouldReceive('requiredFieldValidation')
            ->once()
            ->with($request, ['mobile'])
            ->andReturn('The mobile field is required.');

        $controller->shouldReceive('error')
            ->once()
            ->with(
                $request,
                'Missing Required Parameters.',
                'The mobile field is required.',
                400
            )
            ->andReturn(new JsonResponse('Missing Required Parameters.', 400));

        $response = $controller->getWebsitesList($request);

        $this->assertEquals(400, $response->getStatusCode());
        $this->assertStringContainsString('Missing Required Parameters.', $response->getContent());
    }

    public function testGetWebsitesListNoWebsitesFound()
    {
        $request = Mockery::mock(Request::class);
        $request->shouldReceive('has')->with('mobile')->andReturn(true);
        $request->shouldReceive('get')->with('mobile')->andReturn('1234567890');
        $request->shouldReceive('all')->andReturn(['mobile' => '1234567890']);

        $this->wpUserMock->shouldReceive('where')->with('mobile', '1234567890')->andReturnSelf();
        $this->wpUserMock->shouldReceive('count')->andReturn(0);

        $controller = Mockery::mock(ServerController::class)
            ->makePartial()
            ->shouldAllowMockingProtectedMethods();

        $controller->shouldReceive('success')
            ->once()
            ->with($request, [], 'No websites found.', 404)
            ->andReturn(new JsonResponse('No websites found.', 404));

        $response = $controller->getWebsitesList($request);

        $this->assertEquals(404, $response->getStatusCode());
        $this->assertStringContainsString('No websites found.', $response->getContent());
    }

    public function testGetWebsitesListWebsitesFound()
    {
        $request = Mockery::mock(Request::class);
        $request->shouldReceive('has')->with('mobile')->andReturn(true);
        $request->shouldReceive('get')->with('mobile')->andReturn('1234567890');
        $request->shouldReceive('all')->andReturn(['mobile' => '1234567890']);

        $websitesData = [
            (object) ['website' => 'example1.com'],
            (object) ['website' => 'example2.com'],
        ];

        $this->wpUserMock->shouldReceive('where')->with('mobile', '1234567890')->andReturnSelf();
        $this->wpUserMock->shouldReceive('count')->andReturn(count($websitesData));
        $this->wpUserMock->shouldReceive('get')->andReturn($websitesData);

        $controller = Mockery::mock(ServerController::class)
            ->makePartial()
            ->shouldAllowMockingProtectedMethods();

        $controller->shouldReceive('success')
            ->once()
            ->with(
                $request,
                ['websites' => ['example1.com', 'example2.com']],
                'Websites available.',
                200
            )
            ->andReturn(new JsonResponse('Websites available.', 200));

        $response = $controller->getWebsitesList($request);

        $this->assertEquals(200, $response->getStatusCode());
        $this->assertStringContainsString('Websites available.', $response->getContent());
    }
}
