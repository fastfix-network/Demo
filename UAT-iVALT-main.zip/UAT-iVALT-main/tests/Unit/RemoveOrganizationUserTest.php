<?php

namespace Tests\Unit;

use App\Models\Organization;
use App\Models\User;
use Mockery;
use Tests\TestCase;

class RemoveOrganizationUserTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
        $this->withoutExceptionHandling();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function test_missing_required_parameters()
    {
        // Send a POST request with missing parameters
        $response = $this->json('POST', '/api/organization/remove/user', []);

        $response->assertStatus(400)->assertJson([
            'error' => [
                'status' => 400,
                'title'  => 'Missing Required Parameters',
            ],
        ]);
    }

    public function test_user_not_found()
    {
        // Mock the Organization model
        $orgMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $orgMock->shouldReceive('find')->with(1)->andReturnSelf();
        $orgMock->shouldReceive('users->where->first')->andReturn(null);
        $orgMock->shouldReceive('pendingUsers->where->first')->andReturn(null);

        // Send a POST request with the mocked organization
        $response = $this->json('POST', '/api/organization/remove/user', [
            'org_id'       => 1,
            'country_code' => '91',
            'mobile'       => '1234567890',
        ]);

        $response->assertStatus(404)->assertJson([
            'error' => [
                'status' => 404,
                'title'  => 'Not Found',
                'detail' => 'User not found',
            ],
        ]);
    }

    public function test_successful_user_removal()
    {
        // Mock the Organization model
        $orgMock = Mockery::mock('alias:App\Models\Organization\Organization');
        $orgMock->shouldReceive('find')->with(1)->andReturnSelf();

        // Mock the User model
        $userMock = Mockery::mock('alias:App\Models\User');
        $userMock->id = 1; // Set the id property to avoid undefined property error
        $orgMock->shouldReceive('users->where->first')->andReturn($userMock);
        $orgMock->shouldReceive('pendingUsers->where->first')->andReturn(null);
        $orgMock->shouldReceive('users->detach')->with($userMock->id);

        // Send a POST request with the mocked organization and user
        $response = $this->json('POST', '/api/organization/remove/user', [
            'org_id'       => 1,
            'country_code' => '91',
            'mobile'       => '1234567890',
        ]);

        $response->assertStatus(200)->assertJson([
            'data' => [
                'status'  => true,
                'message' => 'User removed successfully.',

            ],

        ]);
    }

    public function test_successful_pending_user_removal()
    {
        $orgMock = Mockery::mock('alias:App\Models\Organization\Organization');

        // Assume the organization is found by its ID
        $orgMock->shouldReceive('find')->with(1)->andReturnSelf();

        // Mock the relationships
        $orgMock->shouldReceive('users->where->first')->andReturn(null);

        // Mock the pendingUsers() relationship and the where->first chain
        $pendingUserMock = Mockery::mock('overload:App\Model\User');
        $pendingUserMock->id = 123; // Mocking the ID for the pending user
        $orgMock->shouldReceive('pendingUsers->where->first')->andReturn($pendingUserMock);

        // Mock the detach method for the pendingUsers relationship
        $orgMock->shouldReceive('pendingUsers->detach')->with($pendingUserMock->id)->andReturn(true);

        // Send a POST request with the mocked organization and pending user
        $response = $this->json('POST', '/api/organization/remove/user', [
            'org_id'       => 1,
            'country_code' => '91',
            'mobile'       => '1234567890',
        ]);

        // Assert that the response is successful and the user was removed
        $response->assertStatus(200)->assertJson([
            'data' => [
                'status'  => true,
                'message' => 'User removed successfully.',

            ],
        ]);
    }
}
