<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateEmailAttemptsTable extends Migration
{
    public function up()
    {
        Schema::create('email_attempts', function (Blueprint $table) {
            $table->id();
            $table->string('to_address');
            $table->string('ip_address');
            $table->dateTime('last_attempt_date');
            $table->unsignedInteger('attempt_count')->default(0);
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('email_attempts');
    }
}
