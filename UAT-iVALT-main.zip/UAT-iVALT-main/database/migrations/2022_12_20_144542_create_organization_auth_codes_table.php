<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateOrganizationAuthCodesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        // Check if the table already exists
        // if (!Schema::hasTable('organization_auth_codes')) {
        //     Schema::create('organization_auth_codes', function (Blueprint $table) {
        //         $table->id();
        //         $table->bigInteger('organization_id')->index();
        //         $table->string('client_id', 196)->nullable();
        //         $table->string('client_secret', 196)->nullable();
        //         $table->foreign('organization_id')->references('id')->on('organizations')->onDelete('cascade');
        //         $table->timestamps();
        //     });
        // }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('organization_auth_codes');
    }
}
