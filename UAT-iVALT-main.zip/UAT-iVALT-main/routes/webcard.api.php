<?php

use App\Http\Controllers\SmsController;
use App\Http\Controllers\WebCardApiController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

/* A group webcard of api routes. */

Route::group(['prefix' => 'webcard', 'as' => 'webcard.', 'middleware' => 'log.route'], function () {
    Route::post('send/global/notification', [WebCardApiController::class, 'sendGlobalNotificationWebCard'])->name('global.notification');

    Route::post('check-user-enrollment', [WebCardApiController::class, 'checkWebCardEnrollment'])->name('check.enrollment');

    Route::post('remove-user', [WebCardApiController::class, 'removeWebCardUser'])->name('remove.user');

    Route::post('registered-user-details', [WebCardApiController::class, 'webCardRegisteredUserDetails'])->name('registered.user.details'); // Registered User Verification

    Route::post('enrolstatus', [WebCardApiController::class, 'webCardSetEnrollment'])->name('enrollment.status.update');

    Route::post('mobile/refresh/token', [WebCardApiController::class, 'webCardRefreshToken'])->name('refresh.token');

    Route::post('register/mobile/user', [WebCardApiController::class, 'storeWebCardUser'])->name('register.mobile.user');

    Route::post('user/details', [WebCardApiController::class, 'webCardIsUserExist'])->name('register.user.details');

    Route::post('global/authenticate', [WebCardApiController::class, 'globalAuthenticate'])->name('global.authenticate');

    Route::post('validate/global/auth', [WebCardApiController::class, 'validateGlobalAuth'])->name('validate.global.auth');

    Route::post('wp/send/sms', [SmsController::class, 'sendOTPCodeSMS'])->name('send.sms');
});
