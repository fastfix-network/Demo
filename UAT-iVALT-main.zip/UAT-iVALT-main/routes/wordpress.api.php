<?php

use App\Http\Controllers\WordpressApiController;
use Illuminate\Support\Facades\Route;

Route::group(['middleware' => ['log.route', 'auth.token'], 'prefix' => 'wp', 'as' => 'wordpress.'], function () {
    Route::post('register', [WordpressApiController::class, 'registerForWp'])->name('register.for.wordpress');

    Route::post('register/confirmation', [WordpressApiController::class, 'wpRegisterConfirmation'])->name('register.confirmation');

    Route::post('register-confirmation', [WordpressApiController::class, 'confirmWpAuth'])->name('check.confirmation');

    Route::post('is-registered', [WordpressApiController::class, 'isWpRegisteredAndConfirmed'])->name('is.registered');

    Route::post('send-notification', [WordpressApiController::class, 'sendNotification'])->name('send.notification');

    Route::post('confirm-login-auth', [WordpressApiController::class, 'confirmAppAuthLoginForWp'])->name('confirm.login.auth');

    Route::post('watch-for-login', [WordpressApiController::class, 'watchForWpLogin'])->name('watch.for.login');

    Route::post('send-verification-code', [WordpressApiController::class, 'sendVerificationEmail'])->name('send.verification.code');

    Route::post('verify-email-code', [WordpressApiController::class, 'verifyEmailCode'])->name('verify.email.code');
});
