<?php

use App\Http\Controllers\App\EmailController;
use App\Http\Controllers\App\RegistrationController;
use App\Http\Controllers\RESTController;
use App\Http\Controllers\ServerController;
use App\Http\Controllers\SmsController;
use Illuminate\Support\Facades\Route;

Route::group(['middleware' => ['log.route']], function () {
    //Mobile App Apis
    Route::post('wp/register/mobile/user', [RegistrationController::class, 'registerUser'])->name('register.mobile.user'); // Mobile

    Route::post('wp/send/sms', [SmsController::class, 'sendOTPCodeSMS'])->name('send.sms');

    Route::post('wp/confirm/register', [RegistrationController::class, 'confirmRegistration'])->name('confirm.sms');

    Route::post('mobile/refresh/token', [ServerController::class, 'refreshToken'])->name('refresh.token');

    Route::post('wp/mobile/refresh/token', [ServerController::class, 'refreshToken'])->name('wp.refresh.token');

    //New Api Register Confirmation with supplier fields

    Route::post('wp/register/supplier/confirmation', [ServerController::class, 'wpRegisterConfirmationWithSupplier'])->name('register.supplier.confirmation'); // supplier fileds added

    Route::post('wp/registered-user-details', [ServerController::class, 'wpRegisteredUserDetails'])->name('registered.user.details'); // Registered User Verification

    //Backup api
    Route::post('backup/validate/user', [ServerController::class, 'validateBackupUser'])->name('validate.backup.user');

    Route::post('backup/wp/websites', [ServerController::class, 'getListOfWebsites'])->name('backup.wp.websites');

    Route::post('backup/auth/website', [ServerController::class, 'authBackupWebsite'])->name('backup.auth.website');

    Route::post('put/website/details', [ServerController::class, 'putCopWebsiteDetails'])->name('put.website.details');

    Route::post('ext/send/notification', [ServerController::class, 'sendExtNotification'])->name('send.ext.notification'); //Extension

    Route::post('put/details', [ServerController::class, 'putDetails'])->name('put.details'); // Mobile

    Route::post('looking/for/details', [ServerController::class, 'listenForCredentials'])->name('looking.for.details');

    Route::post('wp/remove/website', [ServerController::class, 'removeWebsite'])->name('remove.website');

    Route::post('wp/websites', [ServerController::class, 'getWebsitesList'])->name('wp.websites');

    //Log
    Route::post('get/app/logs', [ServerController::class, 'getAppLogs'])->name('get.app.logs');

    //Global Notification
    Route::post('send/global/notification', [ServerController::class, 'sendGlobalNotification'])->name('global.notification');

    // mobile app routes
    Route::post('send/app-auth/notification', [ServerController::class, 'sendAppAuthNotification'])->name('global.app.notification');

    Route::post('global/authenticate', [ServerController::class, 'globalAuthenticate'])->name('global.authenticate');

    Route::post('validate/global/auth', [ServerController::class, 'validateGlobalAuth'])->name('validate.global.auth');

    Route::post('validate/person', [ServerController::class, 'validatePersonGlobalAuth'])->name('validate.person.auth');

    Route::post('validate/global/rest/auth', [ServerController::class, 'validateGlobalRESTAuth'])->name('validate.global.rest.auth');

    Route::post('getuser', [ServerController::class, 'getUserId'])->name('get.user.by.mobile');

    //Save Success Face Auth
    Route::get('save/faceauth/success/{auth_token}', [RESTController::class, 'saveSuccessFaceAuth'])->name('update.success.faceauth');

    //Contact Us ApI
    Route::post('contact/support', [ServerController::class, 'contactSupport'])->name('contact.support');

    Route::post('enrolstatus', [ServerController::class, 'setEnrollment'])->name('set-enrollment');

    Route::post('is_enrolled', [ServerController::class, 'isUserEnrolled'])->name('is-enrolled');

    //Rest API
    Route::group(['prefix' => 'api/v1'], function () {
        Route::post('validate/user', [RESTController::class, 'validateUserFaceAuth'])->name('validate.user.faceauth');

        Route::post('auth', [RESTController::class, 'authenticateUser'])->name('authenticate.user');

        Route::post('login/url', [RESTController::class, 'loginUrl'])->name('login.url');

        Route::get('user/auth/{auth_token}/{uid}', [RESTController::class, 'authUser'])->name('user.auth-auth-token');

        Route::get('redirect/to/merchant/{auth_token}/{mobile}', [RESTController::class, 'redirectToMerchant'])->name('redirect.to.merchant');
    });

    //Door Unlock
    Route::post('validate/auth', [ServerController::class, 'validateGlobalAuth'])->name('validate.auth.door');

    Route::post('validate-geo-fence-auth', [ServerController::class, 'validateGlobalAuthGeoFence'])->name('validate-geo-fence');

    Route::post('validate-admin-auth', [ServerController::class, 'validateGlobalAuthForAdmin'])->name('validate-admin-auth');

    Route::post('send/notification', [ServerController::class, 'sendGlobalNotification'])->name('global.notification.door');

    //Email Verification
    Route::get('ivalt-email-verification', [ServerController::class, 'validateEmail'])->name('validate.email');

    Route::post('check-is-email-verified', [EmailController::class, 'isEmailVerified'])->name('is.email.verified');

    Route::post('/check-imei', [RegistrationController::class, 'checkImei'])->name('check.imei');

    Route::post('user/assign-org', [ServerController::class, 'userAssignOrg'])->name('user.assign-org');

    Route::post('user/check-org-assignment', [ServerController::class, 'userCheckOrgAssignment'])->name('user-check-org-assignment');

    Route::post('/resend-email-verification', [ServerController::class, 'resendEmailVerification']);

    Route::post('/delete-profile', [ServerController::class, 'deleteProfile'])->name('delete.profile');

    Route::post('/update-profile', [ServerController::class, 'updateProfile']);
});

//Email Verification
Route::get('ivalt-email-verification', [EmailController::class, 'validateEmail'])->name('validate.email');

Route::post('/generate-auth-token', [ServerController::class, 'generateAuthToken'])->name('generate.auth.token');
