<?php

use App\Http\Controllers\AsymmetricController;
use App\Http\Controllers\Organization\OrganizationAuthApiController;
use App\Http\Controllers\Organization\OrganizationAuthCodesController;
use App\Http\Controllers\Organization\OrganizationController;
use App\Http\Controllers\Organization\OrganizationGeoFencesController;
use App\Http\Controllers\Organization\OrganizationUserController;
use App\Http\Controllers\ServerController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::get('/', function () {
    return response()->json(['message' => 'Hello World']);
});

Route::group(['middleware' => 'log.route'], function () {
    /**                                   Organizations Routes                            **/
    // Get Organization by Slug/Code
    Route::get('user/{user_id}/organizations/{org_code}', [OrganizationController::class, 'getOrganizationBySlugOrCode'])->name('get-organization-by-slug-or-code');

    // Get All Organizations
    Route::get('/organizations', [OrganizationController::class, 'getAllOrganizations'])->name('get-all-organizations');

    Route::group(['prefix' => 'organization', 'as' => 'organization'], function () {
        // Get Specific Organization
        Route::get('/{orgIdOrSlug}', [OrganizationController::class, 'getOrganizationByIdOrSlug'])->name('get-organization');

        // Create Organization
        Route::post('/create', [OrganizationController::class, 'storeOrganization'])->name('organization-store');

        // Update Organization
        Route::put('/update/{org_id}', [OrganizationController::class, 'updateOrganization'])->name('organization-update');

        // Delete Organization
        Route::delete('/delete/{org_id}', [OrganizationController::class, 'deleteOrganization'])->name('delete-organization');

        /**                                 Organization Users Routes                            **/
        // Get All User of Organization
        Route::get('/{org_id}/users', [OrganizationUserController::class, 'getAllOrganizationUser'])->name('get-all-organization-users');

        // Get Specific User of Organization
        Route::get('/{org_id}/user/{user_id}', [OrganizationUserController::class, 'getOrganizationUser'])->name('get-organization-user');

        // Create Organization User
        Route::post('{org_id}/create/user', [OrganizationUserController::class, 'storeOrganizationUser'])->name('create.user');

        // Update Organization User
        Route::put('{org_id}/update/user/{user_id}', [OrganizationUserController::class, 'updateOrganizationUser'])->name('update.user');

        // Delete Organization User
        Route::delete('{org_id}/delete/user/{user_id}', [OrganizationUserController::class, 'deleteOrganizationUser'])->name('delete.user');

        /**                                   Organization Pool Users Routes                            **/
        //Accept Organization User
        Route::post('{org_id}/user/{user_id}/accept', [OrganizationUserController::class, 'acceptOrganizationUser'])->name('user.accept');

        //Reject Organization User
        Route::post('{org_id}/user/{user_id}/reject', [OrganizationUserController::class, 'rejectOrganizationUser'])->name('user.reject');

        // Create Pending Users
        Route::post('{org_id}/user/{user_id}/pending', [OrganizationUserController::class, 'setOrganizationUserPending'])->name('user.pending');

        // Get Organization All Pending User
        Route::get('/{org_id}/pending/users', [OrganizationUserController::class, 'getAllOrganizationPendingUser'])->name('pending.users.list');

        // remove user from Organization
        Route::post('/remove/user', [OrganizationUserController::class, 'removeOrganizationUser']);

        /**                                     Organization Geo Fencing                            **/
        // Get All Geo Fencing of Organization
        Route::get('/{org_id}/geo-fences', [OrganizationGeoFencesController::class, 'getAllOrganizationGeoFences'])->name('get-all-geo-fences');

        // Get Specific Geo Fencing of Organization
        Route::get('/{org_id}/geo-fence/{geo_fences_id}', [OrganizationGeoFencesController::class, 'getOrganizationGeoFences'])->name('geo-fences-geo-fences-id');

        // Create Geo Fencing
        Route::post('/{org_id}/create/geo-fence', [OrganizationGeoFencesController::class, 'storeOrganizationGeoFences'])->name('geo-fences.create');

        // Update Geo Fencing
        Route::put('/{org_id}/update/geo-fence/{geo_fences_id}', [OrganizationGeoFencesController::class, 'updateOrganizationGeoFences'])->name('geo-fences.update');

        // Delete Geo Fencing
        Route::delete('/{org_id}/delete/geo-fence/{geo_fences_id}', [OrganizationGeoFencesController::class, 'deleteOrganizationGeoFences'])->name('geo-fences.delete');

        /**                                     Organization Auth Codes                            **/
        Route::get('/{org_id}/get-org-auth-codes', [OrganizationAuthCodesController::class, 'getOrgAuthCodes'])->name('get.org-auth-codes');

        // Create Auth Codes
        Route::post('/{org_id}/create/auth-code', [OrganizationAuthCodesController::class, 'storeOrganizationAuthCodes'])->name('auth-codes.create');

        // Update Auth Codes
        Route::put('/{org_id}/update/auth-code/{auth_code_id}', [OrganizationAuthCodesController::class, 'updateOrganizationAuthCodes'])->name('auth-codes.update');

        // Delete Auth Codes
        Route::delete('/{org_id}/delete/auth-code/{auth_code_id}', [OrganizationAuthCodesController::class, 'deleteOrganizationAuthCodes'])->name('auth-codes.delete');

        /**                                     Organization User Details                           **/
        // Get Organization and user details from client_id, client_secret, mobile_number
        Route::post('/user/details', [OrganizationUserController::class, 'getOrganizationUserDetails'])->name('get-org-user-details');
        Route::post('/user/getOrganizations', [OrganizationUserController::class, 'getUserOrganizations'])->name('get-org-user');

        Route::get('/{org_id}/get-org-api-creds', [OrganizationAuthApiController::class, 'getApiCredentials'])->name('get.auth0-api-creds');

        // Create Organization Auth Api
        Route::post('/{org_id}/auth0-api-creds', [OrganizationAuthApiController::class, 'createOrUpdateApiCredentials'])->name('create.auth0-api-creds');
    });

    // time-slots APIs
    Route::get('organization/{org_id}/timeslots', [OrganizationController::class, 'orgTimeslotsList'])->name('get.org.timeslots');
    Route::post('organization/{org_id}/timeslots/add', [OrganizationController::class, 'addOrgTimeslots'])->name('add.org.timeslots');
    Route::put('timeslot/{timeslot}/update', [OrganizationController::class, 'updateOrgTimeslots'])->name('update.org.timeslots');
    Route::delete('timeslot/{timeslot}/delete', [OrganizationController::class, 'deleteOrgTimeslots'])->name('delete.org.timeslots');

    // org user timeslots
    Route::get('user/{user_id}/timeslots', [OrganizationController::class, 'userTimeslotsList'])->name('get.user.timeslots');
    Route::put('user/{user_id}/timeslots/update', [OrganizationController::class, 'userTimeslotsListUpdate'])->name('update.user.timeslots');

    // org user timeslots
    Route::get('user/{user_id}/geofences', [OrganizationController::class, 'userGeoFenceList'])->name('get.user.geofences');
    Route::put('user/{user_id}/geofences/update', [OrganizationController::class, 'userGeoFenceListUpdate'])->name('update.user.geofences');
});

Route::post('verify-user', [AsymmetricController::class, 'verifyUser'])->middleware('encrypt')->name('Verify-user');

Route::get('/testing', function () {
    return response()->json(['message' => 'This is For Testing Purpose'], 200);
});

Route::get('/getUser', [ServerController::class, 'getUser'])->name('get.user');
