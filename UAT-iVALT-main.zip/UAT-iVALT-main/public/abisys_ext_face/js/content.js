$(function(){
    $('form:first').find('input[type=text],input[type=email]').val(window.username);
    $('form:first').find('input[type=password]').val(window.password);
    $('form:first').submit();
});