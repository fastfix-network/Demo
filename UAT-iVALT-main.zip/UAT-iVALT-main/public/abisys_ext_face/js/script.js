chrome.tabs.query({'active': true, 'lastFocusedWindow': true}, function (tabs) {
	window.url = tabs[0].url;
	window.unique_token = Date.now().toString().substr(6);
    // var APIURL = 'http://rahulasr.website/abisys_work/public/';
    // var APIURL = 'http://abisyscorp.com/web_server/public/';
    var APIURL = 'http://localhost/abisyswork/wordpress_server/public/';
	$(document).ready(function(){
        $('.myButton').click(function(){
            console.log(window.unique_token);
            $(this).hide();
            $('.wait_login, .wait_text').show();
            $('input[name=mobile]').attr('readonly','readonly');
            $.ajax({
                type:'POST',
                url: APIURL+'ext/send/notification',
                data: {token:unique_token,'domain':extractRootDomain(window.url),'mobile':$('input[name=mobile]').val()},
                success: function(result){
                    if(result.status == 'success'){
                        apiRequest();
                    }
               }
            });
        });
		

		function apiRequest(){
			$.ajax({
				type:'POST',
                url: APIURL+'looking/for/details',
				data: {token:unique_token},
                cache: false,
				success: function(result){
                    if(result.status == 'error'){
                        setTimeout(function(){
                            apiRequest();
                        },1000);
                    }else{
                        chrome.tabs.executeScript(null, { file: "js/jquery.js" }, function() {
                            chrome.tabs.executeScript(null,{code:'window.username="'+result.username+'"; window.password="'+result.password+'"'});
                            chrome.tabs.executeScript(null, { file: "js/content.js" });
                        });
                        setTimeout(function(){
                            window.close();
                        },1500);
                    }
				},
                error: function(index){
                    setTimeout(function(){
                        apiRequest();
                    },1000);
                }
			});
		}
	});

    function extractHostname(url) {
        var hostname;
        //find & remove protocol (http, ftp, etc.) and get hostname

        if (url.indexOf("//") > -1) {
            hostname = url.split('/')[2];
        }
        else {
            hostname = url.split('/')[0];
        }

        //find & remove port number
        hostname = hostname.split(':')[0];
        //find & remove "?"
        hostname = hostname.split('?')[0];

        return hostname;
    }

    // To address those who want the "root domain," use this function:
    function extractRootDomain(url) {
        var domain = extractHostname(url),
            splitArr = domain.split('.'),
            arrLen = splitArr.length;

        //extracting the root domain here
        //if there is a subdomain 
        if (arrLen > 2) {
            domain = splitArr[arrLen - 2] + '.' + splitArr[arrLen - 1];
            //check to see if it's using a Country Code Top Level Domain (ccTLD) (i.e. ".me.uk")
            if (splitArr[arrLen - 2].length == 2 && splitArr[arrLen - 1].length == 2) {
                //this is using a ccTLD
                domain = splitArr[arrLen - 3] + '.' + domain;
            }
        }
        return domain;
    }
});
