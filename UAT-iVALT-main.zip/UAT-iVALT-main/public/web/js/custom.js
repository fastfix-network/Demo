$(function(){
    $('.validate').click(function(){
        let elem = $(this);
        if($('input[name=mobile]').val().trim() == ''){
            alert('Please enter mobile number');
            return false;
        }else{
            elem.text('Please wait..');
            elem.prop('disabled',true).addClass('disabled');
            $('input[name=mobile]').prop('readonly',true);
            $.ajax({
                type: 'POST',
                url: route+'/send/global/notification',
                data: {
                    mobile: $('input[name=mobile]').val()
                },
                success: function(result){
                    $('.error-message').html('').hide();
                    elem.text('Waiting for face verification...');
                    elem.prop('disabled',false).removeClass('disabled');
                    lookingForAceAuth($('input[name=mobile]').val());
                    console.log(result);
                },
                error: function(error){
                    $('.error-message').html(error.responseJSON.message).show();
                    elem.text('Validate');
                    elem.prop('disabled',false).removeClass('disabled');
                    $('input[name=mobile]').prop('readonly',false);
                }
            })
        }
    });
});

function lookingForAceAuth(mobile){
    $.ajax({
        type: 'POST',
        url: route+'/validate/global/rest/auth',
        data: {
            mobile: mobile,
            auth_token: $('.auth_token').val()
        },
        success: function(result){
            if(result.status == 'error'){
                setTimeout(function(){
                    lookingForAceAuth(mobile);
                },2000);
            }else{
                window.location.href = result.for_redirect+'/'+mobile;
            }
        }
    });
}