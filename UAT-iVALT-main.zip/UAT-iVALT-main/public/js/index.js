// Document ready Start Here //

$(document).ready(function () {
    //Initial startup functions
    window.CheckIsSlotTimeout = false;

    startTime();
    focusOnInput();

    setTimeout(() => {
        window.CheckIsResultTimeout = false;
    }, 3000);

    let body = $("body");
    let tableRowCount = $("#tableBody").find("tr").length;
    var totalTickets = 0;
    $('.totalTickets').html(totalTickets);
    body.on("blur", ".numberOfTickets", function () {

        let selectedRadioButton = $(this).parents("tr").find(".group:checked").val();

        let numberOfTicketsCount = $(this).val();
        if (parseInt(numberOfTicketsCount) === 0) {
            alert('Number of tickets cannot be zero;');
            $(this).focus();
            return 0;
        }

        if (numberOfTicketsCount !== "") {
            if ($(this).parents("tr").find(".number").val() !== "") {
                addNewRow(selectedRadioButton);
                if(selectedRadioButton === 'abc'){
                    numberOfTicketsCount = parseInt(numberOfTicketsCount)*3;
                }
                totalTickets +=  parseInt(numberOfTicketsCount);
            }
        }
        $('.totalTickets').html(totalTickets);
    });

    // $(this).find('tr:last').child().first().val();

    // body.on('keyup', '.number', function() {
    //     let currentValue = $(this).val();
    //     console.log(currentValue,currentValue.length);
    //     if(currentValue.length = 1){
    //         console.log('focus on next');
    //         console.log($(this).next());

    //     }
    // });

    body.on("click", "#removeRow", function () {
        $(this).parents("tr").remove();
    });

    body.on("keyup", ".number", function () {
        let enteredString = $(this).val();
        if (enteredString.length > 1) {
            // alert('Enter digit between only 0 to 9');
            // $(this).val(0);
            $(this).parent("tr").find(".numberOfTickets").focus();
        }
    });

    body.on("change", ".group", function () {
        $(this).parents("tr").find(".group").not(this).prop("checked", false);
    });

    body.on("submit", "#ticketForm", function () {
        $("#timeStopHidden").val(nextTimeSlot());
    });
});

// Document ready ends Here //
function changeTimeFormat(timeString) {
    var H = +timeString.substr(0, 2);
    var h = H % 12 || 12;
    var ampm = H < 12 ? "am" : "pm";
    return h + timeString.substr(2, 3) + ":00 " + ampm;
}

function addMinutes(time, minutes) {
    var date = new Date(
        new Date("01/01/2015 " + time).getTime() + minutes * 60000
    );

    date.toLocaleString("en-US", {
        timeZone: "Asia/Calcutta",
    });

    var tempTime =
        (date.getHours().toString().length == 1
            ? "0" + date.getHours()
            : date.getHours()) +
        ":" +
        (date.getMinutes().toString().length == 1
            ? "0" + date.getMinutes()
            : date.getMinutes()) +
        ":" +
        (date.getSeconds().toString().length == 1
            ? "0" + date.getSeconds()
            : date.getSeconds());
    return tempTime;
}

function nextTimeSlot() {
    let starttime = "09:00:00";
    let interval = "15";
    let endtime = "21:00:00";
    let timeslots = [starttime];
    while (starttime !== endtime) {
        starttime = addMinutes(starttime, interval);
        timeslots.push(starttime);
    }
    let dateObject = new Date();
    let currentDate =
        dateObject.getHours() +
        ":" +
        dateObject.getMinutes() +
        ":" +
        dateObject.getSeconds();
    let newArray = [];

    for (let index = 0; index < timeslots.length; index++) {
        if (timeslots[index] <= currentDate) {
            newArray[index] = timeslots[index];
        }
    }

    let lastKey = newArray.length;
    let lastTime = addMinutes(newArray[lastKey - 1], "15");
    let finalTime = changeTimeFormat(lastTime);
    return finalTime;
}

function startTime() {
    //Varibale declarations and intialization
    let str = "";
    var today = new Date();
    var hours = today.getHours();
    var minutes = today.getMinutes();
    var seconds = today.getSeconds();
    minutes = checkTime(minutes);
    seconds = checkTime(seconds);
    let time = hours + ":" + minutes + ":" + seconds;


    //// New Varibales //// 
    var hoursNew = today.getHours();
  var minutesNew = today.getMinutes();
  var ampm = hours >= 12 ? 'PM' : 'AM';
  hoursNew = hoursNew % 12;
  hoursNew = hoursNew ? hoursNew : 12; // the hour '0' should be '12'
  minutesNew = minutesNew < 10 ? '0'+minutesNew : minutesNew;
  var strTime = hoursNew + ':' + minutesNew + ':'+seconds+ ' ' + ampm;

  $('#liveTime').html(strTime);

    // Call self function after 5 milliseconds
    setTimeout(startTime, 500);
    // Restricted Minutes
    let selectedMinutes = [14, 29, 44, 59];

    let selectedMinutesForResults = [15, 30, 45, 0,'00','0',60];

    //Display Remaining Seconds in error alert

    if (selectedMinutesForResults.includes(minutes)) {
        if(seconds < 30){
            setTimeout(() => {
                $("#resultModal").modal("show");
            }, 4000);
        
            setTimeout(() => {
                $("#resultModal").modal("hide");       
            }, 24000);
        }

    }

    $(".remainingSeconds").html(60 - seconds);

    // Check 1 min before time slot
    if (selectedMinutes.includes(minutes)) {

        if (hours > 8 && hours <= 21) {
            $("#exampleModal").modal("show");
            window.CheckIsSlotTimeout = false;
            $("#exampleModal").modal({
                backdrop: "static",
                keyboard: false,
            });

            $("#saveButton").prop("disabled", true);

            if (60 - seconds == 1) {
                location.reload();
            }
        }
    }
    if (!selectedMinutes.includes(minutes)) {
        $("#exampleModal").modal("hide");
        $(".submitForm").prop("disabled", false);
        window.CheckIsSlotTimeout = true;
    }

}

function checkTime(timeIndex) {
    if (timeIndex < 10) {
        timeIndex = "0" + timeIndex;
    } // add zero in front of numbers < 10
    return timeIndex;
}

var rowNumber = 1;

// Add new Row in Table
function addNewRow(selector) {

    let firstRow = `
        <tr>
            <td>
                <label>A</label>
                    <input type="radio" name="group[${rowNumber}]" value="a" aria-selected="true" class="group groupA"  ${ (selector === 'a') ? 'checked' : '' }>
                <label>B</label>
                    <input type="radio" name="group[${rowNumber}]" value="b"  class="group groupB" ${ (selector === 'b') ? 'checked' : '' }>
                <label>C</label>
                    <input type="radio" name="group[${rowNumber}]" value="c" class="group groupC" ${ (selector === 'c') ? 'checked' : '' }>
                <label>ABC</label>
                    <input type="radio" name="group[${rowNumber}]" value="abc" class="group groupABC" ${ (selector === 'abc') ? 'checked' : '' }>
            </td>
            <td>
                <input type="text" name="ticket_number[${rowNumber}]" id="ticketNumber${rowNumber}" class="form-control number"
                        placeholder="Enter number between 0 to 9">
            </td>
            <td>
                <input type="number" class="form-control numberOfTickets" id="numberOfTickets${rowNumber}" name="number_of_tickets[${rowNumber}]">
            </td>
            <td>
                <button class="btn btn-sm btn-danger" id="removeRow">
                    -
                </button>
            </td>
</tr>`;
    $(".table").find("#tableBody").append(firstRow);
    focusOnInput();
    rowNumber += 1;
}

/// Keyboard Shortcut Function
var currentValue = "";
document.onkeyup = function (evt) {
    evt = evt || window.event;
    var charCode = evt.keyCode || evt.which;
    var charStr = String.fromCharCode(charCode);
    let selectedId = document.activeElement.id;
    if (selectedId == "") {
        selectedId = "numberOfTickets0";
    }

if(charCode !== 97 && charCode !== 98 && charCode !== 99 && charCode !== 100){
    if (charStr == "a" || charStr == "A" ) {
        $("#" + selectedId)
            .parents("tr")
            .find(".groupA")
            .prop("checked", true);
    }

    if (charStr == "b" || charStr == "B") {
        $("#" + selectedId)
            .parents("tr")
            .find(".groupB")
            .prop("checked", true);
    }

    if (charStr == "c" || charStr == "C") {
        $("#" + selectedId)
            .parents("tr")
            .find(".groupC")
            .prop("checked", true);
    }

    if (charStr == "d" || charStr == "D") {
        $("#" + selectedId)
            .parents("tr")
            .find(".groupABC")
            .prop("checked", true);
    }

}

    if(window.CheckIsSlotTimeout){
        if (charCode == 13) {
            $("#formSubmit").submit();
            setTimeout(function () {
                location.reload();
            }, 1500);
        }
    }

    let numbers = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"];

    if (document.activeElement.type != "number") {
        let element = document.activeElement;

        if (numbers.includes(document.activeElement.value)) {
            currentValue = document.activeElement.value;
            let nextEle = element.parentNode.parentNode.getElementsByTagName("td")[2].querySelectorAll('.numberOfTickets');

        } else {

            if (document.activeElement.value == "") {
                document.activeElement.value = "";
                currentValue = "";
            } else {
                if (
                    !(charStr == "a",
                        charStr == "A",
                        charStr == "b",
                        charStr == "B",
                        charStr == "c",
                        charStr == "C",
                        charStr == "d",
                        charStr == "D",
                        charStr == "+")
                ) {
                    document.activeElement.value = currentValue;

                }
            }
        }
    }
};

// Focus in last row selected input
function focusOnInput() {
    let tableRowCount = $("#tableBody").find("tr").length;
    setTimeout(function () {
        $("#ticketNumber" + (tableRowCount - 1)).focus();
    }, 200);
}

$('#formSubmit').on('submit', function () {

    setTimeout(() => { location.reload() }, 1000);

})

// setInterval(function () {
//     $(".displayTime").html(nextTimeSlot());
//     $("#timeStopHidden").val(nextTimeSlot());
// }, 2000);
