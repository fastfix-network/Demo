<?php

use App\Models\UserAppLogs;

/**
 * @param $mobile
 * @param $message
 *
 * @return bool
 */
function saveAppLog($mobile, $message): bool
{
    if (UserAppLogs::create(['mobile' => $mobile, 'detail' => $message])) {
        return true;
    }

    return false;
}
