<?php

use Aws\Ses\Exception\SesException;
use Aws\Ses\SesClient;
use Illuminate\Support\Facades\Log;

/**
 * @param $toAddress
 * @param $name
 * @param $subject
 * @param $message
 */
function sendMail($toAddress, $name, $subject, $message)
{
    $client = new SesClient([
        'version'     => 'latest',
        'region'      => env('MAIL_HOST'),
        'credentials' => [
            'key'    => env('MAIL_USERNAME'),
            'secret' => env('MAIL_PASSWORD'),
        ],
    ]);
    $sendEmailArgs = [
        'Source'      => env('MAIL_FROM_ADDRESS'),
        'Destination' => [
            'ToAddresses' => [$toAddress],
        ],
        'Message' => [
            'Subject' => [
                'Data'    => $subject,
                'Charset' => 'UTF-8',
            ],
            'Body' => [
                'Html' => [
                    'Charset' => 'UTF-8',
                    'Data'    => $message,
                ],
            ],
        ],
    ];

    try {
        $result = $client->sendEmail($sendEmailArgs);
        $messageId = $result->get('MessageId');
        /* Logging the response from Email server. */
        Log::channel('ivaltFcmLogs')->info(json_encode([
            'toAddress' => $toAddress,
            'subject'   => $subject,
            'message'   => "Email sent! Message ID: $messageId",
            'response'  => $result,
        ], true));

        return true;
    } catch (SesException $e) {
        /* Logging the response from Email server. */
        Log::channel('ivaltFcmLogs')->info(json_encode([
            'toAddress' => $toAddress,
            'subject'   => $subject,
            'message'   => 'The email was not sent.',
            'response'  => 'Error message: '.$e->getMessage(),
        ], true));

        return false;
    }
}

/**
 * @throws \PHPMailer\PHPMailer\Exception
 */
function sendRegistrationSuccessEmail($to, $name = null)
{
    $subject = 'Thank You For Registration with iVALT';

    $message = '<html>
      <head>
        <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:400,400i,700,900&display=swap" rel="stylesheet">
      </head>
        <body style="padding: 40px;background: #EBF0F5;">
            <div style="background: white;padding: 60px;border-radius: 4px;box-shadow: 0 2px 3px #C8D0D8;display: inline-block;">
                <center>
                    <div style="border-radius:200px; height:120px; width:120px; background: #F8FAF5;display:flex;">
                        <div style="margin:0 auto;display:flex;">
                            <a href="https://ivalt.com" target="_blank">
                                <img src="https://ivalt.com/mfa/ivalt_logo.png" width="80px" height="80px" style="margin-top: 25%;"/>
                            </a>
                        </div>
                    </div>
                </center>
                <h1 style="color: #235be4;font-weight: 900;font-size: 30px;margin-bottom: 10px;">Hi!</h1>
                <p style="color: #404F5E;font-size:15px;margin: 0;">Thank you for installing the iVALT mobile app!</p><br/>
                <p style="color: #404F5E;font-size:15px;margin: 0;">
                    We will offer a new feature, in the near future, to enable you to set up a backup facial profile in case you cannot use or do not have access to your phone.
                </p><br/>
                <p style="color: #404F5E;font-size:15px;margin: 0;">We will inform you soon after this feature is available.</p><br/>
                <p style="color: #404F5E;font-size:15px;margin: 0;">Thanks and please feel free to reach for any further assistance at <a href="mailto:support@ivalt.com">support@ivalt.com</a></p><br/>
                <h2 style="font-weight: 700;font-size: 15px;margin-bottom: 10px;color:gray">IVALT Support Team</h2>
          </div>
        </body>
    </html>';

    return sendMail($to, $name, $subject, $message);
}

/**
 * @param      $to
 * @param null $name
 */
function sendWebCardRegistrationSuccessEmail($to, $name = null)
{
    $subject = 'Thank You For Registration with WebID';

    $message = '<html>
      <head>
        <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:400,400i,700,900&display=swap" rel="stylesheet">
      </head>
        <body style="padding: 40px;background: #EBF0F5;">
            <div style="background: white;padding: 60px;border-radius: 4px;box-shadow: 0 2px 3px #C8D0D8;display: inline-block;">
                <center>
                    <div style="border-radius:200px; height:110px; width:110px; background: #F8FAF5;display:flex;">
                    <div style="margin:0 auto;display:flex;">
                        <a href="https://web.cards" target="_blank">
                            <img src="https://ivalt.com/images/webcard.png" width="90px" height="90px" style="margin-top: 14%;"/>
                        </a>
                    </div>
                    </div>
                </center>
                <h1 style="color: #235be4;font-weight: 900;font-size: 30px;margin-bottom: 10px;">Hi!</h1>
                <p style="color: #404F5E;font-size:15px;margin: 0;">Thank you for activating your WebID!</p><br/>
                <p style="color: #404F5E;font-size:15px;margin: 0;">You can now use Webcard mobile app to identify yourself easily for any WebID enabled service. You start immediately to open your Webcard mobile app with a single click. For WordPress, please download the WebID WordPress plugin to enable your WebID to protect your site with biometrics.</p><br/>
                <p style="color: #404F5E;font-size:15px;margin: 0;">Thanks and please feel free to reach for any further assistance at <a href="mailto:support@ivalt.com">support@ivalt.com</a></p><br/>
                <h2 style="font-weight: 700;font-size: 15px;margin-bottom: 10px;color:gray">WebID Support Team</h2>
          </div>
        </body>
    </html>';

    return sendMail($to, $name, $subject, $message);
}

/**
 * @param      $to
 * @param      $mobile
 * @param null $token
 *
 * @return bool
 */
function sendMobileAppVerificationEmail($to, $mobile, $token = null)
{
    $callBackURL = env('APP_URL').'/verify-email?token='.$token.'&email='.$to;

    $subject = 'iVALT Email Verification';

    // Compose a simple HTML email message
    $message = '<html>
          <head>
          </head>
            <body style="padding: 10px 30px;background: #e3e5e7;">
            <div style="margin:0 auto;display: inline-block;">
                <div style="background: white;padding: 35px 60px;border-radius: 4px;">
                    <center>
                        <div style="border-radius:200px;height:100px;width:100px;background:#f8faf5;display:flex">
                        <center style="margin:0 auto;display:flex">
                            <a target="_blank" style="text-decoration:none;">
                                <img src="https://ivalt.com/mfa/ivalt_logo.png" width="55px" height="55px" style="margin-top:45%;" class="CToWUd">
                                                    <h1 style="color: #235be4;font-weight: 600;font-size: 20px;margin-bottom: 10px;">iVALT</h1>
                            </a>
                        </center>
                        </div>
                    </center>
                </div>
                <div style="background-color: #235be4;height:150px;padding: 10px 60px;border-radius: 0px;text-align: center;">
                    <div style="text-align: center;margin-top:10px;">
                        <b style="color:white;font-size:25px;padding: 15px;text-align:center;bottom:0;">Please Verify Your Email Address</b>
                    </div>
                    <center>
                        <div style="border-radius:200px;height:80px;width:80px;background:white;margin-top:10px;display:flex">
                        <center style="margin:0 auto;display:flex">
                            <a style="text-decoration:none;">
                            	<img src="https://cdn-icons-png.flaticon.com/512/1828/1828640.png" width="55px" height="55px" style="margin-top:24%;filter: grayscale(100%);" class="CToWUd">
                            </a>
                        </center>
                        </div>
                    </center>
                </div>
                <div style="background: white;padding: 15px 35px;border-radius: 0px;">
                    <h1 style="color: #235be4;font-weight: 600;font-size: 20px;margin-bottom: 10px;">Your account information</h1>
                    <table style="width: 100%;margin-bottom:20px">
                        <tr cellspacing="10">
                            <td style="width:40%;padding: 10px 0px;">
                                <p style="color: #404F5E;font-size:15px;margin: 0;">
                                    Mobile Number
                                </p>
                            </td>
                            <td style="width:60%;padding: 10px 0px;">
                                <p style="color: #404F5E;font-size:15px;margin: 0;">
                                    '.$mobile.'
                                </p>
                            </td>
                        </tr>
                        <tr cellspacing="10">
                            <td style="width:40%;padding: 10px 0px;">
                                <p style="color: #404F5E;font-size:15px;margin: 0;">
                                    Verify Link
                                </p>
                            </td>
                            <td style="width:60%;padding: 10px 0px;">
                                <a target="_blank" href="'.$callBackURL.'" style="color: dodgerblue;font-size:15px;margin: 0;text-decoration:none;">
                                    '.$callBackURL.'
                                </a>
                            </td>
                        </tr>
                    </table>
                    <div style="border-bottom:2px solid #EBF0F5;margin: 20px 0px;"></div>
                    <div style="text-align:center;margin: 40px 0px;">
                        <a target="_blank" href="'.$callBackURL.'" style="
                            background-color: #235be4;
                            text-decoration: none;
                            color: white;
                            font-size:15px;
                            margin: 0;
                            padding: 10px 20px;
                            box-shadow: 2px 2px 4px #a2a2a2;"
                            >VERIFY YOUR EMAIL</a>
                    </div>
                    <p style="color: #404F5E;font-size:15px;margin: 0;">Thank you for installing the iVALT mobile app!</p>

                    <br/>
              </div>
                <div style="background-color: #f5f7f9;padding: 10px 10px;border-radius: 0px;display:flex;flex-direction: row;justify-content: space-between;align-items: center;">
                    <div style="padding:0px 10px;display:flex;">
                        <p style="color: #404F5E;font-size:14px;margin: 0;">Please feel free to contact us
                            <a style="color: dodgerblue;font-size:15px;margin: 0;" target="_blank" href="mailto:support@ivalt.com">support@ivalt.com</a></p><br/>
                    </div>
                    <div style="padding:0px 10px;width:200px">
                        <h2 style="font-weight: 600;font-size: 12px;margin-bottom: 10px;color:gray;">IVALT Support Team</h2>
                    </div>
                </div>
            </div>
            </body>
        </html>';

    return sendMail($to, 'iVALT', $subject, $message);
}

/**
 * @param      $to
 * @param null $code
 */
function sendWordpressVerificationEmail($to, $code = null)
{
    $subject = 'iVALT Wordpress Authentication';
    // Compose a simple HTML email message
    $message = '<html>
          <head>
            <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:400,400i,700,900&display=swap" rel="stylesheet">
          </head>
            <body style="padding: 40px;background: #EBF0F5;">
            <div style="background: white;padding: 60px;border-radius: 4px;box-shadow: 0 2px 3px #C8D0D8;display: inline-block;">
            <div style="margin:0 auto;display:flex;">
                <div style="border-radius:200px; height:120px; width:120px; background: #F8FAF5;display:flex;">
                <div style="margin:0 auto;display:flex;">
                    <a>
                        <img src="https://ivalt.com/mfa/ivalt_logo.png" width="80px" height="80px" style="margin-top: 25%;"/>
                    </a>
                </div>
                </div>
            </div>
                <h1 style="color: #235be4;font-weight: 900;font-size: 30px;margin-bottom: 10px;">Hi!</h1>
                <p style="color: #404F5E;font-size:15px;margin: 0;">Please complete your WordPress login.</p><br/>
                <p style="color: #404F5E;font-size:15px;margin: 0;">
                Bellow is your backup code to log into your WordPress account.
                </p>
                <br/>
                <p style="background: #F8FAF5;border-radius:20px;text-align:center; padding:20px;color: #404F5E;font-size:45px;margin: 0;font-weight:bold;font-family:consolas;">'.$code.'</p>
                <br/>
                <p style="color: #404F5E;font-size:15px;margin: 0;">Thanks and please feel free to reach for any further assistance at <a href="mailto:support@ivalt.com">support@ivalt.com</a></p><br/>
                <h2 style="font-weight: 700;font-size: 15px;margin-bottom: 10px;color:gray">IVALT Support Team</h2>
              </div>
            </body>
        </html>';

    return sendMail($to, 'iVALT', $subject, $message);
}

/**
 * @param $to
 * @param $subject
 * @param $message
 */
function sendContactUsEmail($to, $subject, $message)
{
    return sendMail($to, 'Support Request', $subject, $message);
}
