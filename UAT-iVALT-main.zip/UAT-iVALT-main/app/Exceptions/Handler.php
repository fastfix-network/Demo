<?php

namespace App\Exceptions;

use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Foundation\Exceptions\Handler as ExceptionHandler;
use Throwable;

class Handler extends ExceptionHandler
{
    public function render($request, Throwable $exception)
    {
        if ($exception instanceof ModelNotFoundException && $request->wantsJson()) {
            if (str_contains(request()->getRequestUri(), 'organization')) {
                return response()->json([
                    'data'  => null,
                    'error' => [
                        'type'     => 'https://httpstatuses.com/404',
                        'title'    => 'Organization Not Found',
                        'status'   => 404,
                        'instance' => request()->getRequestUri()],
                    'debug' => [
                        'timestamp'  => now(),
                        'activityId' => $request->headers->get('activityId'),
                    ],
                ], 404);
            } elseif (str_contains(request()->getRequestUri(), 'user')) {
                return response()->json([
                    'data'  => null,
                    'error' => [
                        'type'     => 'https://httpstatuses.com/404',
                        'title'    => 'User Not Found',
                        'status'   => 404,
                        'instance' => request()->getRequestUri()],
                    'debug' => [
                        'timestamp'  => now(),
                        'activityId' => $request->headers->get('activityId'),
                    ],
                ], 404);
            } elseif (str_contains(request()->getRequestUri(), 'timeslot')) {
                return response()->json([
                    'data'  => null,
                    'error' => [
                        'type'     => 'https://httpstatuses.com/404',
                        'title'    => 'Timeslot Not Found',
                        'status'   => 404,
                        'instance' => request()->getRequestUri()],
                    'debug' => [
                        'timestamp'  => now(),
                        'activityId' => $request->headers->get('activityId'),
                    ],
                ], 404);
            }
        }

        if ($exception instanceof NotFoundHttpException) {
            return response()->json([
                'data'  => null,
                'error' => [
                    'type'     => 'https://httpstatuses.com/404',
                    'title'    => 'Route Not Found',
                    'status'   => 404,
                    'instance' => request()->getRequestUri()],
                'debug' => [
                    'timestamp'  => now(),
                    'activityId' => $request->headers->get('activityId'),
                ],
            ], 404);
        }

        return parent::render($request, $exception);
    }

    /**
     * A list of the exception types that are not reported.
     *
     * @var array<int, class-string<Throwable>>
     */
    protected $dontReport = [
        //
    ];

    /**
     * A list of the inputs that are never flashed for validation exceptions.
     *
     * @var array<int, string>
     */
    protected $dontFlash = [
        'current_password',
        'password',
        'password_confirmation',
    ];

    /**
     * Register the exception handling callbacks for the application.
     *
     * @return void
     */
    public function register()
    {
        $this->reportable(function (Throwable $e) {
            //
        });
    }
}
