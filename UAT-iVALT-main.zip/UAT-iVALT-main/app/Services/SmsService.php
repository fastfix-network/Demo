<?php

namespace App\Services;

use App\Http\Controllers\ApiResponseController;
use Illuminate\Http\JsonResponse;
use Twilio\Exceptions\ConfigurationException;
use Twilio\Exceptions\TwilioException;
use Twilio\Rest\Client;

class SmsService extends ApiResponseController
{
    /**
     * @param $to
     * @param $message
     *
     * @return JsonResponse
     */
    public function sendSMS($to, $message): JsonResponse
    {
        $secretsManager = new AwsSecretsManagerService;
        $secretDecoded = $secretsManager->getCredentials('sms');

        if (! isset($secretDecoded['TWILIO_ID']) || ! isset($secretDecoded['TWILIO_SECRET']) || ! isset($secretDecoded['FROM_NUMBER'])) {
            return $this->error(request(), 'Twilio credentials not found', 'Twilio credentials not found', 404);
        }

        try {
            $twilio = new Client($secretDecoded['TWILIO_ID'], $secretDecoded['TWILIO_SECRET']);
            $twilio->messages->create($to, [
                'from' => $secretDecoded['FROM_NUMBER'],
                'body' => $message,
            ]);

            return $this->success(request(), 'SMS sent successfully', 'SMS sent successfully', 200);
        } catch (ConfigurationException|TwilioException $e) {
            saveAppLog($to, 'Twilio SMS send failed : '.$e->getMessage());

            return $this->error(request(), 'SMS send failed', 'SMS send failed, Please try again later.', 500);
        }
    }
}
