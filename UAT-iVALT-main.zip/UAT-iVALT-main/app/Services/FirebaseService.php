<?php

namespace App\Services;

use Kreait\Firebase\Exception\FirebaseException;
use Kreait\Firebase\Exception\MessagingException;
use Kreait\Firebase\Messaging\CloudMessage;
use Kreait\Firebase\Messaging\MulticastSendReport;
use Kreait\Firebase\Messaging\Notification;
use Kreait\Laravel\Firebase\Facades\Firebase;

class FirebaseService
{
    /**
     * @throws FirebaseException
     * @throws MessagingException
     */
    public function sendNotification($token, array $data = [], string $platform = 'android'): array
    {
        $messaging = Firebase::messaging();
        if ($platform === 'android') {
            $message = CloudMessage::withTarget('token', $token)
                ->withData($data);
        } else {
            $message = CloudMessage::withTarget('token', $token)
                ->withNotification($data)
                ->withData($data);
        }

        return $messaging->send($message);
    }

    /**
     * @throws FirebaseException
     * @throws MessagingException
     */
    public function sendMulticastNotification($tokens, $title, $body, array $data = []): MulticastSendReport
    {
        $messaging = Firebase::messaging();

        $message = CloudMessage::new()
            ->withNotification(Notification::create($title, $body))
            ->withData($data);

        return $messaging->sendMulticast($message, $tokens);
    }
}
