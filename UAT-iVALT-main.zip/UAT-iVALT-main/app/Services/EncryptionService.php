<?php

namespace App\Services;

use Illuminate\Contracts\Filesystem\FileNotFoundException;
use Illuminate\Support\Facades\Storage;
use phpseclib3\Crypt\RSA;

class EncryptionService
{
    /**
     * @param $data
     *
     * @throws FileNotFoundException
     * @return string
     */
    public function encrypt($data): string
    {
        $publicKeyPath = 'keys/public_key.pem';

        if (Storage::disk('local')->exists($publicKeyPath)) {
            $publicKey = RSA::load(
                Storage::disk('local')->get($publicKeyPath)

            )->withHash('sha1')->withMGFHash('sha1');
            if (is_array($data)) {
                $data = json_encode($data, true);
            }

            return base64_encode($publicKey->encrypt($data));
        } else {
            throw new FileNotFoundException;
        }
    }

    /**
     * @param $ciphertext
     *
     * @throws FileNotFoundException
     *
     * @return mixed
     */
    public function decrypt($ciphertext): mixed
    {
        $privateKeyPath = 'keys/private_key.pem';
        if (Storage::disk('local')->exists($privateKeyPath)) {
            $privateKey = RSA::load(
                Storage::disk('local')->get($privateKeyPath)
            )->withHash('sha1')->withMGFHash('sha1');

            return $privateKey->decrypt($ciphertext);
        } else {
            throw new FileNotFoundException;
        }
    }
}
