<?php

namespace App\Services;

use Aws\Exception\AwsException;
use Aws\SecretsManager\SecretsManagerClient;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;

class AwsSecretsManagerService
{
    protected SecretsManagerClient $client;

    public function __construct()
    {
        $params = ['version' => 'latest'];
        if (env('AWS_REGION') !== null && env('AWS_ACCESS_KEY_ID') !== null && env('AWS_SECRET_ACCESS_KEY') !== null) {
            if (env('AWS_DEFAULT_REGION') !== '' && env('AWS_DEFAULT_REGION') !== null) {
                $params['region'] = env('AWS_REGION');
            }
            if (env('AWS_ACCESS_KEY_ID') !== '' && env('AWS_SECRET_ACCESS_KEY') !== null) {
                $params['credentials'] = ['key' => env('AWS_ACCESS_KEY_ID'), 'secret' => env('AWS_SECRET_ACCESS_KEY')];
            }
        }
        $this->client = new SecretsManagerClient($params);
    }

    /**
     * Retrieves the credentials from the Secrets Manager.
     *
     * @param string $secretName
     *
     * @return array|null the decoded secret as an associative array or null if the secret is not found.
     */
    public function getCredentials(string $secretName): ?array
    {
        // Check if credentials are cached
        if (env('AWS_REGION') === null && env('AWS_ACCESS_KEY_ID') === null && env('AWS_SECRET_ACCESS_KEY') === null) {
            $cachedCredentials = $this->getCachedCredentials($secretName);
            if ($cachedCredentials !== null) {
                return $cachedCredentials;
            }
        }

        try {
            $result = $this->client->getSecretValue(['SecretId' => $secretName]);
            if (isset($result['SecretString'])) {
                $credentials = json_decode($result['SecretString'], true);
                if (env('AWS_REGION') == null && env('AWS_ACCESS_KEY_ID') == null && env('AWS_SECRET_ACCESS_KEY') === null) {
                    $this->cacheCredentials($secretName, $credentials);
                }

                return $credentials;
            }
        } catch (AwsException $e) {
            dd($e->getAwsErrorMessage());
            //            $this->logError($secretName, $e->getAwsErrorMessage());
        }

        return null;
    }

    /**
     * Retrieves cached credentials.
     *
     * @param string $secretName
     *
     * @return array|null
     */
    protected function getCachedCredentials(string $secretName): ?array
    {
        return Cache::get('credentials_'.$secretName);
    }

    /**
     * Caches credentials for future use.
     *
     * @param string $secretName
     * @param array  $credentials
     *
     * @return void
     */
    protected function cacheCredentials(string $secretName, array $credentials): void
    {
        Cache::put('credentials_'.$secretName, $credentials, now()->addHours(4));
    }

    /**
     * Logs error message.
     *
     * @param string $secretName
     * @param string $errorMessage
     *
     * @return void
     */
    protected function logError(string $secretName, string $errorMessage): void
    {
        //        saveAppLog('ERROR', "Error retrieving secret: " . $errorMessage);
        Log::channel('ivaltFcmLogs')->info(json_encode([
            'secretName' => $secretName,
            'response'   => 'Error retrieving secret: '.$errorMessage,
        ], true));
    }
}
