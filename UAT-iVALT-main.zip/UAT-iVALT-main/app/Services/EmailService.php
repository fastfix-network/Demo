<?php

namespace App\Services;

use App\Http\Controllers\ApiResponseController;
use App\Models\EmailAttempt;
use Aws\Ses\Exception\SesException;
use Aws\Ses\SesClient;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Log;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\PHPMailer;

class EmailService extends ApiResponseController
{
    protected string $smtpService = 'GOOGLE';

    public function __construct()
    {
        $secretsManager = new AwsSecretsManagerService;
        $secretDecoded = $secretsManager->getCredentials('SMTP_SERVICE');

        if (! isset($secretDecoded['SMTP_SERVICE'])) {
            Log::channel('stderr')->debug(json_encode([
                'request'   => request()->all(),
                'message'   => 'SMTP Service not available',
                'timestamp' => date('Y-m-d H:i:s'),
            ], true));

            return $this->error(request(), 'SMTP Service not available', 'SMTP Service not available', 404);
        }

        // Replace these variables with your actual Gmail SMTP credentials
        $this->smtpService = $secretDecoded['SMTP_SERVICE'];
    }

    /**
     * @param $to
     * @param $name
     *
     * @throws Exception
     *
     * @return JsonResponse
     */
    public function sendRegistrationSuccessEmail($to, $name = null): JsonResponse
    {
        $subject = 'Thank You For Registration with iVALT';

        $message = '<html>
<head>
    <title>iVALT</title>
</head>
<body style="display: flex; padding: 1rem; flex-direction: column; justify-content: center; align-items: center; min-height: 100vh; background: #e5e7eb; width: 100%;">
    <div style="padding-top: 2rem; padding-bottom: 2rem; border-radius: 0.5rem; text-align: center; background-color: #ffffff; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06); ">
        <div style="background: white;padding: 35px 60px;border-radius: 4px; text-align: center;">
            <a target="_blank" style="text-decoration:none;">
                <img src="https://ivalt.com/wp-content/uploads/2017/07/logo.png" height="55px">
            </a>
        </div>
        <div style="background-color: #3f3f3f;padding: 20px 30px;border-radius: 0px;text-align: center;">
            <div style="text-align: center;margin-top:10px;">
                <b style="color:white;font-size:25px;padding: 8px;text-align:center;bottom:0;">
                    Please Keep this Email!</b>
            </div>
        </div>
        <div style="background: white;padding: 15px 35px;border-radius: 0px;">
            <h1 style="color: black;font-weight: 600;font-size: 20px;margin-bottom: 10px;">Start with DEEPFAKE Verification
            </h1>
            <h1 style="color: black;font-weight: 600;font-size: 20px;margin-bottom: 10px;">(with Two iVALT Users)
            </h1>
            <br/>
            <h3 style="text-align:left;color: #23558f;font-weight: 400;font-size: 20px;margin-bottom: 10px;">To Request a Verification:
            </h3>
            <div style="border-bottom:2px solid #EBF0F5;margin: 20px 0px;"></div>
		 <div>
           <div>
               <img src="https://ivalt.com/images/home.PNG" width="350px" /><br/><br/>
            </div>
          <b>1. Open App, Click on Middle Icon</b>
         </div>
         <br/><br/><br/>

         		 <div>
           <div>
               <img src="https://ivalt.com/images/menu.PNG" width="350px" /><br/><br/>
            </div>
          <b>2. Click on OnDemandID</b>
         </div>
         <br/><br/><br/>

         		 <div>
           <div>
               <img src="https://ivalt.com/images/ondeamdid.PNG" width="350px" /><br/><br/>
            </div>
          <b>3. Enter Phone # and Send to Request ID Verification</b>
         </div>
         <br/><br/><br/>

         		 <div>
           <div>
               <img src="https://ivalt.com/images/success.PNG" width="350px" /><br/><br/>
            </div>
          <b>4. Success!</b>
         </div>
         <br/><br/><br/>
                     <h3 style="text-align:left;color: #23558f;font-weight: 400;font-size: 20px;margin-bottom: 10px;">To Verify a Request:
            </h3>
         		 <div>
           <div>
               <img src="https://ivalt.com/images/notification.PNG" width="350px" /><br/><br/>
            </div>
          <b>1. Click on Notification</b>
         </div>
         <br/><br/><br/>

         		 <div>
           <div>
               <img src="https://ivalt.com/images/confirm.jpg" width="350px" /><br/><br/>
            </div>
          <b>2. Click YES to Verify and Choose General or Exact Location</b>
         </div>
         <br/><br/><br/>

         		 <div>
           <div>
               <img src="https://ivalt.com/images/face.PNG" width="150px" /><br/><br/>
            </div>
          <b>3. Verify via Face ID and</b><br/><br/><br/>
          <h2>You have Proven Your IDENTITY!🎉</h2>
         </div>
         <br/><br/><br/>

        </div>

        <div
            style="background-color: #f5f7f9;padding: 10px 10px;border-radius: 0px;display:flex;flex-direction: row;justify-content: space-between;align-items: center;">
            <div style="padding:0px 10px;display:flex;">
                <p style="color: #404F5E;font-size:14px;margin: 0;">Please feel free to contact us
                    <a style="color: #23558f;font-size:15px;margin: 0;" target="_blank"
                        href="mailto:support@ivalt.com">support@ivalt.com</a>
                </p><br />
            </div>
            <div style="padding:0px 10px;width:200px">
                <h2 style="font-weight: 600;font-size: 12px;margin-bottom: 10px;color:gray;">IVALT Support Team</h2>
            </div>
        </div>
    </div>
</body>
</html>';
        if ($this->smtpService === 'GOOGLE') {
            return $this->sendGoogleMail($to, $name, $subject, $message);
        } else {
            return $this->sendMail($to, $name, $subject, $message);
        }
    }

    /**
     * @param $toAddress
     * @param $name
     * @param $subject
     * @param $message
     *
     * @throws Exception
     *
     * @return JsonResponse
     */
    private function sendGoogleMail($toAddress, $name, $subject, $message): JsonResponse
    {
        // Verify email sending limit
        $limitVerified = $this->verifyEmailSendingLimit($toAddress, request()->ip(), 15, 24);

        if (! $limitVerified) {
            return $this->error(request(), 'Email sending limit exceeded', 'Email sending limit exceeded', 400);
        }

        $secretsManager = new AwsSecretsManagerService;
        $secretDecoded = $secretsManager->getCredentials('GMAIL_SMTP');

        if (! isset($secretDecoded['SMTP_USERNAME']) || ! isset($secretDecoded['SMTP_PASSWORD'])) {
            Log::channel('stderr')->debug(json_encode([
                'request'   => request()->all(),
                'message'   => 'Mail credentials not found',
                'timestamp' => date('Y-m-d H:i:s'),
            ], true));

            return $this->error(request(), 'Mail credentials not found', 'Mail secret not found', 404);
        }

        // Replace these variables with your actual Gmail SMTP credentials
        $smtpUsername = $secretDecoded['SMTP_USERNAME'];
        $smtpPassword = $secretDecoded['SMTP_PASSWORD'];

        // Email headers
        $headers = "From: $smtpUsername\r\n";
        $headers .= "Reply-To: $smtpUsername\r\n";

        // Create a PHPMailer instance
        $mail = new PHPMailer;

        // SMTP configuration
        $mail->isSMTP();
        $mail->SMTPDebug = 0;
        $mail->Host = 'smtp.gmail.com';
        $mail->Port = 587;
        $mail->SMTPAuth = true;
        $mail->SMTPSecure = 'tls';
        $mail->Username = $smtpUsername;
        $mail->Password = $smtpPassword;

        // Email content
        $mail->setFrom($smtpUsername);
        $mail->addAddress($toAddress, $name); // Add recipient name here
        $mail->Subject = $subject;
        $mail->Body = $message;
        $mail->isHTML(true);

        // Send email
        if ($mail->send()) {
            Log::channel('ivaltFcmLogs')->info(json_encode([
                'toAddress' => $toAddress,
                'subject'   => $subject,
                'message'   => 'Email sent! Message ID: '.$mail->getLastMessageID(),
                'response'  => 'Email sent!',
            ], true));

            Log::channel('stderr')->debug(json_encode([
                'request'   => request()->all(),
                'toAddress' => $toAddress,
                'subject'   => $subject,
                'message'   => 'Email sent! Message ID: '.$mail->getLastMessageID(),
                'timestamp' => date('Y-m-d H:i:s'),
            ], true));

            return $this->success(request(), [
                'messageId' => $mail->getLastMessageID(),
                'toAddress' => $toAddress,
                'subject'   => $subject,
            ], 'Email sent!', 200);
        } else {
            Log::channel('stderr')->debug(json_encode([
                'request'   => request()->all(),
                'toAddress' => $toAddress,
                'subject'   => $subject,
                'response'  => 'Error message: '.$mail->ErrorInfo,
                'message'   => 'Failed to send email!',
                'timestamp' => date('Y-m-d H:i:s'),
            ], true));

            /* Logging the response from Email server. */
            Log::channel('ivaltFcmLogs')->info(json_encode([
                'toAddress' => $toAddress,
                'subject'   => $subject,
                'message'   => 'Failed to send email!',
                'response'  => 'Error message: '.$mail->ErrorInfo,
            ], true));

            return $this->error(request(), 'Failed to send email!', 'Error message: '.$mail->ErrorInfo, 500);
        }
    }

    /**
     * Verify if the maximum number of email attempts has been reached.
     *
     * @param string $toAddress   The email address to which the email is being sent.
     * @param string $ipAddress   The IP address from which the email is being sent.
     * @param int    $maxAttempts The maximum number of allowed attempts.
     * @param int    $timeFrame   The time frame in hours within which the attempts are counted.
     *
     * @return bool True if the maximum attempts are not reached, false otherwise.
     */
    private function verifyEmailSendingLimit(string $toAddress, string $ipAddress, int $maxAttempts = 15, int $timeFrame = 24)
    {
        $emailAttempt = EmailAttempt::where('to_address', $toAddress)
            ->where('ip_address', $ipAddress)
            ->first();

        if ($emailAttempt) {
            // Check if the last attempt was made within the specified time frame
            if ($emailAttempt->last_attempt_date->diffInHours(Carbon::now()) >= $timeFrame) {
                // Reset attempt count if more than the specified time frame has passed
                $emailAttempt->attempt_count = 1;
            } else {
                // Check if maximum attempts for the time frame are reached
                if ($emailAttempt->attempt_count >= $maxAttempts) {
                    return false; // Maximum attempts reached
                }
            }
            $emailAttempt->last_attempt_date = Carbon::now();
            $emailAttempt->attempt_count += 1;
            $emailAttempt->save();
        } else {
            // Create new attempt record
            EmailAttempt::create([
                'to_address'        => $toAddress,
                'ip_address'        => $ipAddress,
                'last_attempt_date' => Carbon::now(),
                'attempt_count'     => 1,
            ]);
        }

        return true; // Maximum attempts not reached
    }

    /**
     * @param $to
     * @param $name
     *
     * @throws Exception
     *
     * @return JsonResponse
     */
    public function sendRegistrationSuccessOnOldEmail($to, $name = null): JsonResponse
    {
        $subject = 'Hi '.$name.', your iVALT account has been activated with a new email ID. Welcome back to iVALT!';

        $message = '<html>
<head>
    <title>iVALT</title>
</head>
<body style="display: flex; padding: 1rem; flex-direction: column; justify-content: center; align-items: center; min-height: 100vh; background: #e5e7eb; width: 100%;">
    <div style="padding-top: 2rem; padding-bottom: 2rem; border-radius: 0.5rem; text-align: center; background-color: #ffffff; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06); ">
        <div style="background: white;padding: 35px 60px;border-radius: 4px; text-align: center;">
            <a target="_blank" style="text-decoration:none;">
                <img src="https://ivalt.com/wp-content/uploads/2017/07/logo.png" height="55px">
            </a>
        </div>
        <div style="background-color: #3f3f3f;padding: 20px 30px;border-radius: 0px;text-align: center;">
            <div style="text-align: center;margin-top:10px;">
                <b style="color:white;font-size:25px;padding: 8px;text-align:center;bottom:0;">
                    Please Keep this Email!</b>
            </div>
        </div>
        <div style="background: white;padding: 15px 35px;border-radius: 0px;">
            <h1 style="color: black;font-weight: 600;font-size: 20px;margin-bottom: 10px;">Start with DEEPFAKE Verification
            </h1>
            <h1 style="color: black;font-weight: 600;font-size: 20px;margin-bottom: 10px;">(with Two iVALT Users)
            </h1>
            <br/>
            <h3 style="text-align:left;color: #23558f;font-weight: 400;font-size: 20px;margin-bottom: 10px;">To Request a Verification:
            </h3>
            <div style="border-bottom:2px solid #EBF0F5;margin: 20px 0px;"></div>
		 <div>
           <div>
               <img src="https://ivalt.com/images/home.PNG" width="350px" /><br/><br/>
            </div>
          <b>1. Open App, Click on Middle Icon</b>
         </div>
         <br/><br/><br/>

         		 <div>
           <div>
               <img src="https://ivalt.com/images/menu.PNG" width="350px" /><br/><br/>
            </div>
          <b>2. Click on OnDemandID</b>
         </div>
         <br/><br/><br/>

         		 <div>
           <div>
               <img src="https://ivalt.com/images/ondeamdid.PNG" width="350px" /><br/><br/>
            </div>
          <b>3. Enter Phone # and Send to Request ID Verification</b>
         </div>
         <br/><br/><br/>

         		 <div>
           <div>
               <img src="https://ivalt.com/images/success.PNG" width="350px" /><br/><br/>
            </div>
          <b>4. Success!</b>
         </div>
         <br/><br/><br/>
                     <h3 style="text-align:left;color: #23558f;font-weight: 400;font-size: 20px;margin-bottom: 10px;">To Verify a Request:
            </h3>
         		 <div>
           <div>
               <img src="https://ivalt.com/images/notification.PNG" width="350px" /><br/><br/>
            </div>
          <b>1. Click on Notification</b>
         </div>
         <br/><br/><br/>

         		 <div>
           <div>
               <img src="https://ivalt.com/images/confirm.jpg" width="350px" /><br/><br/>
            </div>
          <b>2. Click YES to Verify and Choose General or Exact Location</b>
         </div>
         <br/><br/><br/>

         		 <div>
           <div>
               <img src="https://ivalt.com/images/face.PNG" width="150px" /><br/><br/>
            </div>
          <b>3. Verify via Face ID and</b><br/><br/><br/>
          <h2>You have Proven Your IDENTITY!🎉</h2>
         </div>
         <br/><br/><br/>

        </div>

        <div
            style="background-color: #f5f7f9;padding: 10px 10px;border-radius: 0px;display:flex;flex-direction: row;justify-content: space-between;align-items: center;">
            <div style="padding:0px 10px;display:flex;">
                <p style="color: #404F5E;font-size:14px;margin: 0;">Please feel free to contact us
                    <a style="color: #23558f;font-size:15px;margin: 0;" target="_blank"
                        href="mailto:support@ivalt.com">support@ivalt.com</a>
                </p><br />
            </div>
            <div style="padding:0px 10px;width:200px">
                <h2 style="font-weight: 600;font-size: 12px;margin-bottom: 10px;color:gray;">IVALT Support Team</h2>
            </div>
        </div>
    </div>
</body>
</html>';
        if ($this->smtpService === 'GOOGLE') {
            return $this->sendGoogleMail($to, $name, $subject, $message);
        } else {
            return $this->sendMail($to, $name, $subject, $message);
        }
    }

    /**
     * @param      $to
     * @param null $name
     *
     * @throws Exception
     *
     * @return JsonResponse
     */
    public function sendWebCardRegistrationSuccessEmail($to, $name = null): JsonResponse
    {
        $subject = 'Thank You For Registration with WebID';

        $message = '<html>
      <head>
        <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:400,400i,700,900&display=swap" rel="stylesheet">
      </head>
        <body style="padding: 40px;background: #EBF0F5;">
            <div style="background: white;padding: 60px;border-radius: 4px;box-shadow: 0 2px 3px #C8D0D8;display: inline-block;">
                <center>
                    <div style="border-radius:200px; height:110px; width:110px; background: #F8FAF5;display:flex;">
                    <div style="margin:0 auto;display:flex;">
                        <a href="https://web.cards" target="_blank">
                            <img src="https://ivalt.com/images/webcard.png" width="90px" height="90px" style="margin-top: 14%;"/>
                        </a>
                    </div>
                    </div>
                </center>
                <h1 style="color: #23558f;font-weight: 900;font-size: 30px;margin-bottom: 10px;">Hi!</h1>
                <p style="color: #404F5E;font-size:15px;margin: 0;">Thank you for activating your WebID!</p><br/>
                <p style="color: #404F5E;font-size:15px;margin: 0;">You can now use Webcard mobile app to identify yourself easily for any WebID enabled service. You start immediately to open your Webcard mobile app with a single click. For WordPress, please download the WebID WordPress plugin to enable your WebID to protect your site with biometrics.</p><br/>
                <p style="color: #404F5E;font-size:15px;margin: 0;">Thanks and please feel free to reach for any further assistance at <a href="mailto:support@ivalt.com">support@ivalt.com</a></p><br/>
                <h2 style="font-weight: 700;font-size: 15px;margin-bottom: 10px;color:gray">WebID Support Team</h2>
          </div>
        </body>
    </html>';
        if ($this->smtpService === 'GOOGLE') {
            return $this->sendGoogleMail($to, $name, $subject, $message);
        } else {
            return $this->sendMail($to, $name, $subject, $message);
        }
    }

    /**
     * @param      $name
     * @param      $to
     * @param      $mobile
     * @param null $token
     *
     * @throws Exception
     *
     * @return JsonResponse
     */
    public function sendMobileAppVerificationEmail($name, $to, $mobile, $token = null): JsonResponse
    {
        $callBackURL = env('APP_URL').'/verify-email?token='.$token.'&email='.$to;

        $subject = 'iVALT Email Verification';
        // Compose a simple HTML email message
        $message = '<html>
<head>
    <title>iVALT</title>
</head>
<body style="display: flex; padding: 1rem; flex-direction: column; justify-content: center; align-items: center; min-height: 100vh; background: #e5e7eb; width: 100%;">
    <div style="padding-top: 2rem; padding-bottom: 2rem; border-radius: 0.5rem; text-align: center; background-color: #ffffff; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06); ">
        <div style="background: white;padding: 35px 60px;border-radius: 4px; text-align: center;">
            <a target="_blank" style="text-decoration:none;">
                <img src="https://ivalt.com/wp-content/uploads/2017/07/logo.png" height="55px">
            </a>
        </div>
        <div style="background-color: #3f3f3f;padding: 20px 30px;border-radius: 0px;text-align: center;">
            <div style="text-align: center;margin-top:10px;">
                <b style="color:white;font-size:25px;padding: 10px;text-align:center;bottom:0;">
                    Please Verify This Email Address</b><br /><br />
                <b style="color:white;font-size:18px;padding: 10px;text-align:center;bottom:0;">
                    ( For Security & Future Communications )</b>
            </div>
        </div>
        <div style="background: white;padding: 15px 35px;border-radius: 0px;">
            <h1 style="color: #23558f;font-weight: 600;font-size: 20px;margin-bottom: 10px;">Your account information
            </h1>
            <table style="width: 100%;margin-bottom:20px">
                <tr cellspacing="10">
                    <td style="width:40%;padding: 10px 0px;">
                        <p style="color: #404F5E;font-size:15px;margin: 0;">
                            Mobile Number
                        </p>
                    </td>
                    <td style="width:60%;padding: 10px 0px;">
                        <p style="color: #404F5E;font-size:15px;margin: 0;">
                            '.$mobile.'
                        </p>
                    </td>
                </tr>
                <tr cellspacing="10">
                    <td style="width:40%;padding: 10px 0px;">
                        <p style="color: #404F5E;font-size:15px;margin: 0;">
                            Email
                        </p>
                    </td>
                    <td style="width:60%;padding: 10px 0px;">
                        <span style="color: #23558f;font-size:15px;margin: 0;text-decoration:none;">
                            '.$to.'
                        </span>
                    </td>
                </tr>
            </table>

            <div style="border-bottom:2px solid #EBF0F5;margin: 20px 0px;"></div>

            <div style="text-align:center;margin: 40px 0px;">
                <a target="_blank" href="'.$callBackURL.'" style="background-color: #23558f;text-decoration: none;color: white;font-size:15px;margin: 0;padding: 10px 20px;border-radius: 4px;">VERIFY YOUR EMAIL</a>
            </div>

            <a href="'.$callBackURL.'" target="_blank" style="color:#23558f;font-size:15px;margin: 10px 0px;">
                '.$callBackURL.'
            </a><br /><br />
            <p style="color: #404F5E;font-size:15px;margin: 20 0;">Thank you for installing the iVALT mobile app!</p>
            <br />
        </div>
        <div
            style="background-color: #f5f7f9;padding: 10px 10px;border-radius: 0px;display:flex;flex-direction: row;justify-content: space-between;align-items: center;">
            <div style="padding:0px 10px;display:flex;">
                <p style="color: #404F5E;font-size:14px;margin: 0;">Please feel free to contact us
                    <a style="color: #23558f;font-size:15px;margin: 0;" target="_blank"
                        href="mailto:support@ivalt.com">support@ivalt.com</a>
                </p><br />
            </div>
            <div style="padding:0px 10px;width:200px">
                <h2 style="font-weight: 600;font-size: 12px;margin-bottom: 10px;color:gray;">IVALT Support Team</h2>
            </div>
        </div>
    </div>
</body>
</html>
';
        if ($this->smtpService === 'GOOGLE') {
            return $this->sendGoogleMail($to, $name, $subject, $message);
        } else {
            return $this->sendMail($to, $name, $subject, $message);
        }
    }

    /**
     * @param      $to
     * @param null $code
     *
     * @throws Exception
     *
     * @return JsonResponse
     */
    public function sendWordpressVerificationEmail($to, $code = null): JsonResponse
    {
        $subject = 'iVALT Wordpress Authentication';
        // Compose a simple HTML email message
        $message = '<html>
          <head>
            <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:400,400i,700,900&display=swap" rel="stylesheet">
          </head>
            <body style="padding: 40px;background: #EBF0F5;">
            <div style="background: white;padding: 60px;border-radius: 4px;box-shadow: 0 2px 3px #C8D0D8;display: inline-block;">
            <div style="margin:0 auto;display:flex;">
                <div style="border-radius:200px; height:120px; width:120px; background: #F8FAF5;display:flex;">
                <div style="margin:0 auto;display:flex;">
                    <a>
                        <img src="https://ivalt.com/mfa/ivalt_logo.png" width="80px" height="80px" style="margin-top: 25%;"/>
                    </a>
                </div>
                </div>
            </div>
                <h1 style="color: #23558f;font-weight: 900;font-size: 30px;margin-bottom: 10px;">Hi!</h1>
                <p style="color: #404F5E;font-size:15px;margin: 0;">Please complete your WordPress login.</p><br/>
                <p style="color: #404F5E;font-size:15px;margin: 0;">
                Bellow is your backup code to log into your WordPress account.
                </p>
                <br/>
                <p style="background: #F8FAF5;border-radius:20px;text-align:center; padding:20px;color: #404F5E;font-size:45px;margin: 0;font-weight:bold;font-family:consolas;">'.$code.'</p>
                <br/>
                <p style="color: #404F5E;font-size:15px;margin: 0;">Thanks and please feel free to reach for any further assistance at <a href="mailto:support@ivalt.com">support@ivalt.com</a></p><br/>
                <h2 style="font-weight: 700;font-size: 15px;margin-bottom: 10px;color:gray">IVALT Support Team</h2>
              </div>
            </body>
        </html>';
        if ($this->smtpService === 'GOOGLE') {
            return $this->sendGoogleMail($to, 'iVALT', $subject, $message);
        } else {
            return $this->sendMail($to, 'iVALT', $subject, $message);
        }
    }

    /**
     * @param $to
     * @param $subject
     * @param $message
     *
     * @throws Exception
     *
     * @return JsonResponse
     */
    public function sendContactUsEmail($to, $subject, $message): JsonResponse
    {
        if ($this->smtpService === 'GOOGLE') {
            return $this->sendGoogleMail($to, 'Support Request', $subject, $message);
        } else {
            return $this->sendMail($to, 'Support Request', $subject, $message);
        }
    }

    /**
     * @param $toAddress
     * @param $name
     * @param $subject
     * @param $message
     *
     * @return JsonResponse
     */
    private function sendMail($toAddress, $name, $subject, $message): JsonResponse
    {
        // Verify email sending limit
        $limitVerified = $this->verifyEmailSendingLimit($toAddress, request()->ip(), 15, 24);

        if (! $limitVerified) {
            return $this->error(request(), 'Email sending limit exceeded', 'Email sending limit exceeded', 400);
        }

        $secretsManager = new AwsSecretsManagerService;
        $secretDecoded = $secretsManager->getCredentials('SES_SMTP');

        if (! isset($secretDecoded['USERNAME']) || ! isset($secretDecoded['PASSWORD'])) {
            Log::channel('stderr')->debug(json_encode([
                'request'   => request()->all(),
                'message'   => 'Mail credentials not found',
                'timestamp' => date('Y-m-d H:i:s'),
            ], true));

            return $this->error(request(), 'Mail credentials not found', 'Mail secret not found', 404);
        }

        $client = new SesClient([
            'region' => $secretDecoded['MAIL_HOST'],
            'key'    => $secretDecoded['USERNAME'],
            'secret' => $secretDecoded['PASSWORD'],
        ]);

        $sendEmailArgs = [
            'Source'      => $secretDecoded['MAIL_FROM_ADDRESS'],
            'Destination' => [
                'ToAddresses' => [$toAddress],
            ],
            'Message' => [
                'Subject' => [
                    'Data'    => $subject,
                    'Charset' => 'UTF-8',
                ],
                'Body' => [
                    'Html' => [
                        'Charset' => 'UTF-8',
                        'Data'    => $message,
                    ],
                ],
            ],
        ];

        try {
            $result = $client->sendEmail($sendEmailArgs);
            $messageId = $result->get('MessageId');
            /* Logging the response from Email server. */
            Log::channel('ivaltFcmLogs')->info(json_encode([
                'toAddress' => $toAddress,
                'subject'   => $subject,
                'message'   => "Email sent! Message ID: $messageId",
                'response'  => $result,
            ], true));

            return $this->success(request(), [
                'messageId' => $messageId,
                'toAddress' => $toAddress,
                'subject'   => $subject,
                'response'  => $result,
            ], 'Email sent successfully!');

        } catch (SesException $e) {
            /* Logging the response from Email server. */
            Log::channel('ivaltFcmLogs')->info(json_encode([
                'toAddress' => $toAddress,
                'subject'   => $subject,
                'message'   => 'Failed to send email!',
                'response'  => 'Error message: '.$e->getMessage(),
            ], true));

            return response()->json([
                'status'  => false,
                'code'    => 500,
                'message' => 'Failed to send email!',
                'details' => [
                    'toAddress' => $toAddress,
                    'subject'   => $subject,
                    'response'  => 'Error message: '.$e->getMessage(),
                ],
            ], 500);
        }
    }
}
