<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WebCardUserDeviceTokens extends Model
{
    protected $table = 'webcard_user_devices';

    protected $fillable = ['user_id', 'device_token', 'imei', 'platform'];

    public function user_rel()
    {
        return $this->belongsTo(WebCardUser::class, 'id', 'user_id');
    }
}
