<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SMSAttempt extends Model
{
    use HasFactory;

    protected $table = 'sms_attempts';

    protected $fillable = [
        'phone_number',
        'ip_address',
        'last_attempt_date',
        'attempt_count',
    ];

    protected $casts = [
        'last_attempt_date' => 'datetime',
    ];
}
