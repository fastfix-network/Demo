<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EmailAttempt extends Model
{
    use HasFactory;

    protected $table = 'email_attempts';

    protected $fillable = [
        'to_address',
        'ip_address',
        'last_attempt_date',
        'attempt_count',
    ];

    protected $casts = [
        'last_attempt_date' => 'datetime',
    ];
}
