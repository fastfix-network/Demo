<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RegisterOtp extends Model
{
    use HasFactory;

    protected $table = 'register_otps';

    protected $fillable = ['mobile', 'otp', 'country_code', 'user_code'];
}
