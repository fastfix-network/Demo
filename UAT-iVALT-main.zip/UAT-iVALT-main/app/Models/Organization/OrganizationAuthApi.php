<?php

namespace App\Models\Organization;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class OrganizationAuthApi extends Model
{
    use HasFactory;

    protected $table = 'organization_auth_apis';

    protected $fillable = ['organization_id', 'domain', 'api_token', 'client_id', 'client_secret', 'grant_type', 'audience'];

    public function organization(): BelongsTo
    {
        return $this->belongsTo(Organization::class, 'organization_id', 'id');
    }
}
