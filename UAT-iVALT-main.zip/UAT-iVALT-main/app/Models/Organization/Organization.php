<?php

namespace App\Models\Organization;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

//use Illuminate\Database\Eloquent\SoftDeletes;

class Organization extends Model
{
    //    use HasFactory;
    //    use SoftDeletes;

    protected $table = 'organizations';

    protected $fillable = ['name', 'organization_code', 'has_geo_fencing', 'number_geo_fencing', 'is_active'];
    //    protected $with = ['users', 'geoGeoFences', 'pendingUsers', 'authCodes'];

    /**
     * @return HasMany
     */
    public function geoGeoFences(): HasMany
    {
        return $this->hasMany(OrganizationGeoFences::class, 'organization_id', 'id');
    }

    /**
     * @return BelongsToMany
     */
    public function users(): BelongsToMany
    {
        return $this->belongsToMany(User::class, OrganizationUser::class, 'organization_id', 'user_id');
    }

    /**
     * @return BelongsToMany
     */
    public function pendingUsers(): BelongsToMany
    {
        return $this->belongsToMany(User::class, OrganizationUserPool::class, 'organization_id', 'user_id');
    }

    /**
     * @return HasOne
     */
    public function authCodes(): HasOne
    {
        return $this->hasOne(OrganizationAuthCode::class, 'organization_id', 'id');
    }

    /**
     * @return HasOne
     */
    public function authApiCredentials(): HasOne
    {
        return $this->hasOne(OrganizationAuthApi::class, 'organization_id', 'id');
    }
}
