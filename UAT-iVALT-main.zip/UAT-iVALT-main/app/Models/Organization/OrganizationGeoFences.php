<?php

namespace App\Models\Organization;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class OrganizationGeoFences extends Model
{
    use HasFactory;

    protected $table = 'organization_geo_fence';

    protected $fillable = ['organization_id', 'name', 'latitude', 'longitude', 'radius', 'is_active'];

    /**
     * @return BelongsTo
     */
    public function organization()
    {
        return $this->belongsTo(Organization::class, 'organization_id');
    }

    public function users()
    {
        return $this->belongsToMany(OrganizationGeoFences::class, 'user_geo_fence', 'user_id', 'geo_fence_id');
    }
}
