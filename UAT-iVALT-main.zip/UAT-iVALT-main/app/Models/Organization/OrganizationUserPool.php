<?php

namespace App\Models\Organization;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class OrganizationUserPool extends Model
{
    use HasFactory;

    protected $table = 'organization_user_pool';

    protected $fillable = ['organization_id', 'user_id', 'is_active'];
}
