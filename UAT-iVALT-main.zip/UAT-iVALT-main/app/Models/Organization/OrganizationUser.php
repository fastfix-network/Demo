<?php

namespace App\Models\Organization;

use App\Models\User;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class OrganizationUser extends Model
{
    use HasFactory;

    protected $table = 'organization_users';

    protected $fillable = ['organization_id', 'user_id', 'is_admin', 'time_slot_id', 'is_timeslot_verification_active', 'is_geo_fence_verification_active'];

    /**
     * @return HasMany
     */
    public function timeSlots()
    {
        return $this->hasMany(TimeSlot::class, 'time_slot_id');
    }

    /**
     * @return HasMany
     */
    public function users()
    {
        return $this->hasMany(User::class, 'user_id');
    }
}
