<?php

namespace App\Models\Organization;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class OrganizationAuthCode extends Model
{
    use HasFactory;

    protected $fillable = ['organization_id', 'client_id', 'client_secret'];

    public function organization()
    {
        return $this->belongsTo(Organization::class, 'organization_id');
    }
}
