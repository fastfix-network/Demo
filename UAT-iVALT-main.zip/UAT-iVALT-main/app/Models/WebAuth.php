<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class WebAuth extends Model
{
    use HasFactory;

    protected $table = 'web_auth';

    protected $guarded = [];
}
