<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class OrganizationAuthCode extends Model
{
    use HasFactory;

    protected $table = 'organization_auth_codes';

    protected $fillable = ['organization_id', 'client_id', 'client_secret'];
}
