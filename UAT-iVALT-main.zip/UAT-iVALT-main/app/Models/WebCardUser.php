<?php

namespace App\Models;

use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Foundation\Auth\Access\Authorizable;

class WebCardUser extends \Illuminate\Foundation\Auth\User
{
    use Authenticatable;
    use Authorizable;

    protected $table = 'webcard_users';

    protected $guarded = ['id'];

    protected $hidden = ['password'];

    /**
     * @return HasMany
     */
    public function device_tokens(): HasMany
    {
        return $this->hasMany(WebCardUserDeviceTokens::class, 'user_id', 'id');
    }
}
