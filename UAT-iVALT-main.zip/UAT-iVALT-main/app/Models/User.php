<?php

namespace App\Models;

use App\Models\Organization\Organization;
use App\Models\Organization\OrganizationGeoFences;
use App\Models\Organization\OrganizationUser;
use App\Models\Organization\OrganizationUserPool;
use App\Models\Organization\TimeSlot;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens;
    use HasFactory;
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $guarded = ['id'];

    protected $appends = ['is_admin', 'is_active'];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [
        'password',
        'mapping_table',
        'user_pool_active',
        'pivot',
        'is_admin',
        'is_active',
        'created_at',
        'updated_at',
    ];

    /**
     * @return HasMany
     */
    public function device_tokens(): HasMany
    {
        return $this->hasMany(UserDeviceTokens::class, 'user_id', 'id');
    }

    /**
     * @return HasOne
     */
    public function mapping_table(): HasOne
    {
        return $this->hasOne(OrganizationUser::class, 'user_id', 'id');
    }

    /**
     * @return HasOne
     */
    public function user_pool_active(): HasOne
    {
        return $this->hasOne(OrganizationUserPool::class, 'user_id', 'id');
    }

    /**
     * @return null || status of admin verfication
     */
    public function getIsAdminAttribute()
    {
        if (is_null($this->mapping_table)) {
            return;
        }

        return $this->mapping_table->is_admin;
    }

    /**
     * @return null || status of user
     */
    public function getIsActiveAttribute()
    {
        if (is_null($this->user_pool_active)) {
            return;
        }

        return $this->user_pool_active->is_active;
    }

    /**
     * @return BelongsToMany
     */
    public function organizations(): BelongsToMany
    {
        return $this->belongsToMany(Organization::class, OrganizationUser::class, 'user_id', 'organization_id')
            ->where('organization_code', '!=', 'ivalt')
            ->where('organization_code', '!=', 'iVALT');
    }

    /**
     * @return BelongsToMany
     */
    public function pendingOrganizations(): BelongsToMany
    {
        return $this->belongsToMany(Organization::class, OrganizationUserPool::class, 'user_id', 'organization_id')->withPivot('is_Active');
    }

    /**
     * @return HasMany
     */
    public function timeSlots(): HasMany
    {
        return $this->hasMany(TimeSlot::class, 'user_id', 'id');
    }

    /**
     * @return BelongsToMany
     */
    public function orgTimeSlots(): BelongsToMany
    {
        return $this->belongsToMany(TimeSlot::class, 'users_timeslots');
    }

    /**
     * @return BelongsToMany
     */
    public function orgGeoFences(): BelongsToMany
    {
        return $this->belongsToMany(OrganizationGeoFences::class, 'user_geo_fence', 'user_id', 'geo_fence_id');
    }
}
