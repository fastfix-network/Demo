<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class UserDeviceTokens extends Model
{
    protected $table = 'user_devices';

    protected $guarded = ['id'];

    /**
     * @return BelongsTo
     */
    public function user_rel(): BelongsTo
    {
        return $this->belongsTo(User::class, 'id', 'user_id');
    }
}
