<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class WordpressEmailAuth extends Model
{
    use HasFactory;

    protected $table = 'wordpress_email_auth';

    protected $fillable = ['domain', 'email', 'code', 'auth_status'];
}
