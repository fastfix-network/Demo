<?php

namespace App\Http\Middleware;

use App\Services\EncryptionService;
use Closure;
use Illuminate\Contracts\Filesystem\FileNotFoundException;
use Illuminate\Http\Request;

class EncryptionMiddleware
{
    /**
     * @throws FileNotFoundException
     */
    public function handle(Request $request, Closure $next)
    {
        $encryptionService = new EncryptionService;
        $decrypted = $encryptionService->decrypt(base64_decode($request->data));
        $request->request->add(json_decode($decrypted, true));

        return $next($request);
    }
}
