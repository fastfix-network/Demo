<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

class LogRoute
{
    /**
     * Logs the request and response before & after calls to the controller
     *
     * @param Request $request
     * @param Closure $next
     *
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        // generate a random string for this request
        $activityId = Str::random(32);

        // add activityId to session for retrieving in success & error response formatting of ApiResponseController
        $request->headers->set('activityId', $activityId);

        $requestData = json_encode($request->all(), true);

        // build response log message
        $requestLog = [
            'applicationId' => 'iValt',
            'type'          => 'Request',
            'activityId'    => $activityId,
            'method'        => $request->getMethod(),
            'path'          => $request->path(),
            'requestData'   => $requestData,
        ];

        // log request
        Log::channel('stderr')->debug(json_encode($requestLog, true));

        // set start time
        $startTime = round(microtime(true) * 1000);

        // perform the request
        $response = $next($request);

        // set stop time
        $stopTime = round(microtime(true) * 1000);

        // determine elapsed time
        $elapsedTime = $stopTime - $startTime;

        /* Checking if the response has an exception. If it does, it will log the exception. */
        $exception = $response->exception;

        if (! is_null($exception)) {
            // build response log exception
            $exceptionLog = [
                'applicationId' => 'iValt',
                'type'          => 'Exception',
                'activityId'    => $activityId,
                'method'        => $request->getMethod(),
                'path'          => $request->path(),
                'exception'     => json_encode([
                    'exceptionMessage' => $exception->getMessage(),
                    'exceptionCode'    => $exception->getCode(),
                    'exceptionFile'    => $exception->getFile(),
                    'exceptionLine'    => $exception->getLine(),
                ], true),
                'requestData' => $requestData,
            ];
            /* Logging the exception to the stderr log channel. */
            Log::channel('stderr')->error(json_encode($exceptionLog, true));

            return response()->json([
                'data'  => null,
                'error' => [
                    'type'     => 'https://httpstatuses.com/500',
                    'title'    => 'Internal Server Error',
                    'status'   => 500,
                    'instance' => request()->getRequestUri()],
                'debug' => [
                    'timestamp'    => now(),
                    'activityId'   => $request->headers->get('activityId'),
                    'exceptionLog' => $exceptionLog,
                ],
            ], 500);
        } else {
            // build response log response
            $responseLog = [
                'applicationId' => 'iValt',
                'type'          => 'Response',
                'activityId'    => $activityId,
                'elapsedTime'   => $elapsedTime,
                'method'        => $request->getMethod(),
                'path'          => $request->path(),
                'httpCode'      => $response->getStatusCode(),
                'response'      => $response->getContent(),
                'requestData'   => $requestData,
            ];

            /* Logging the response to the stderr log channel. */
            Log::channel('stderr')->debug(json_encode($responseLog, true));
        }

        return $response;
    }
}
