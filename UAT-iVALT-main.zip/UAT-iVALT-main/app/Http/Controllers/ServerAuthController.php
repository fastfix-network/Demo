<?php

namespace App\Http\Controllers;

use App\Models\WpUser;
use DB;
use FCM;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use LaravelFCM\Message\Exceptions\InvalidOptionsException;
use LaravelFCM\Message\OptionsBuilder;
use LaravelFCM\Message\PayloadDataBuilder;
use LaravelFCM\Message\PayloadNotificationBuilder;

class ServerAuthController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    public function watch(Request $request)
    {
        $model = DB::table('listenings')->where('unique_token', $request->token)->first();
        if ($model != null) {
            DB::table('listenings')->where('unique_token', $request->token)->delete();

            return response()->json(['status' => 'true', 'result' => $model]);
        } else {
            return response()->json(['status' => 'false', 'result' => []]);
        }
    }

    public function update(Request $request)
    {
        $insertArray = [
            'username'     => $request->username,
            'password'     => $request->password,
            'unique_token' => $request->token,
        ];
        $model = DB::table('listenings')->insert($insertArray);

        return ['status' => 'true', 'message' => 'Updated Successfully!'];
    }

    /**
     * WordPress Registration Check For Users
     */
    public function checkUserRegistration(Request $request): JsonResponse
    {
        $userEmail = $request->email;
        $model = WpUser::firstWhere('email', $userEmail);
        if ($model != null) {
            return response()->json(['status' => 'true', 'message' => 'User Exists'], 200);
        } else {
            return response()->json(['status' => 'false', 'message' => 'User not exists'], 401);
        }
    }

    /**
     * Listen user registration
     */
    public function listenRegister(Request $request): JsonResponse
    {
        $userEmail = $request->email;
        $token = $request->token;
        $model = WpUser::firstWhere(['email' => $userEmail, 'user_token' => $token]);
        if ($model != null) {
            return response()->json(['status' => 'true', 'message' => 'User registered successfully!'], 200);
        } else {
            return response()->json(['status' => 'false', 'message' => 'User still not found'], 404);
        }
    }

    /**
     * Register new wordpress user
     */
    public function registerNewUser(Request $request): JsonResponse
    {
        $userEmail = $request->email_id;
        $token = $request->token;
        $model = DB::table('wp_users')->insert(['email' => $userEmail, 'user_token' => $token]);

        return response()->json(['status' => 'true', 'message' => 'User Register successfully!'], 200);
    }

    /**
     * Watch user logging status from wp
     */
    public function watchLoginedOrNot(Request $request): JsonResponse
    {
        $userEmail = $request->email;
        $token = $request->token;
        $model = WpUser::firstWhere(['email' => $userEmail, 'user_token' => $token]);
        if ($model != null && $model->app_auth_status != '' && $model->app_auth_status == 'true') {
            DB::table('wp_users')->where(['email' => $userEmail, 'user_token' => $token])->update(['app_auth_status' => '']);

            return response()->json(['status' => 'true', 'message' => 'Successfully logined!'], 200);
        } else {
            return response()->json(['status' => 'false', 'message' => 'Not loginned yet!'], 404);
        }
    }

    /**
     * Login to WordPress user
     */
    public function loginToUser(Request $request): JsonResponse
    {
        $userEmail = $request->email;
        $token = $request->token;
        $model = WpUser::firstWhere(['email' => $userEmail, 'user_token' => $token]);
        if ($model != null) {
            WpUser::where(['email' => $userEmail, 'user_token' => $token])->update(['app_auth_status' => 'true']);

            return response()->json(['status' => 'true', 'message' => 'User logined success!']);
        } else {
            WpUser::where(['email' => $userEmail, 'user_token' => $token])->update(['app_auth_status' => '']);

            return response()->json(['status' => 'false', 'message' => 'Wrong user details!'], 404);
        }
    }

    /**
     * @param Request $request
     *
     * @throws InvalidOptionsException
     *
     * @return JsonResponse
     */
    public function fcm(Request $request): JsonResponse
    {
        if ($request->has('mobile')) {
            $model = DB::table('users')->where(['mobile' => $request->mobile])->first();
            if ($model == null) {
                return response()->json(['status' => 'error', 'message' => 'Mobile number not found in database!'], 500);
            } else {
                $optionBuilder = new OptionsBuilder;
                $optionBuilder->setTimeToLive(60 * 20);
                if ($request->has('title')) {
                    $title = $request->title;
                } else {
                    $title = 'Authentication Request';
                    // $title = 'default_title';
                }
                if ($request->has('body')) {
                    $body = $request->body;
                } else {
                    $sent_token = md5(uniqid(rand(), true));
                    $body = $sent_token;
                }
                $sent_token = md5(uniqid(rand(), true));
                DB::table('users')->where(['mobile' => $request->mobile])->update(['sent_token' => $sent_token]);
                $notificationBuilder = new PayloadNotificationBuilder($title);
                $notificationBuilder->setBody('You have new notification!')
                    ->setSound('default');

                $dataBuilder = new PayloadDataBuilder;
                $dataBuilder->addData(['token' => $sent_token, 'type' => 'wordpress']);

                $option = $optionBuilder->build();
                $notification = $notificationBuilder->build();
                $data = $dataBuilder->build();

                $token = $model->device_token;

                $downstreamResponse = FCM::sendTo($token, $option, $notification, $data);

                return response()->json(['status' => 'success', 'message' => 'Request sent to FCM', 'succes_resp' => $downstreamResponse->numberSuccess(), 'fail_resp' => $downstreamResponse->numberFailure(), 'number_modification' => $downstreamResponse->numberModification(), 'sent_token' => $sent_token], 200);
                /*$downstreamResponse->numberSuccess();
                $downstreamResponse->numberFailure();
                $downstreamResponse->numberModification();*/
            }
        } else {
            return response()->json(['status' => 'error', 'message' => 'Please send mobile number!'], 500);
        }
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function wpLoginWithToken(Request $request): JsonResponse
    {
        if ($request->has('mobile') && $request->has('login_token')) {
            $model = DB::table('users')->where(['mobile' => $request->mobile, 'sent_token' => $request->login_token])->first();
            if ($model != null) {
                $model = DB::table('users')->where(['mobile' => $request->mobile])->update(['login_token' => $request->login_token]);

                return response()->json(['status' => 'success', 'message' => 'Token successfully saved for login!'], 200);
            } else {
                return response()->json(['status' => 'error', 'message' => 'Mobile number not found in database!'], 500);
            }
        } else {
            return response()->json(['status' => 'error', 'message' => 'Send mobile number & login token!'], 500);
        }
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function createOrUpdateUser(Request $request): JsonResponse
    {
        if ($request->has('mobile') && $request->has('device_token')) {
            $model = DB::table('users');
            $data = $model->where(['mobile' => $request->mobile])->first();
            if ($data == null) {
                $model = DB::table('users')->insertGetId(['mobile' => $request->mobile, 'device_token' => $request->device_token]);

                return response()->json(['status' => 'success', 'message' => 'Successfully registered!', 'id' => $model], 200);
            } else {
                $model = DB::table('users')->where(['mobile' => $request->mobile])->update(['device_token' => $request->device_token]);

                return response()->json(['status' => 'success', 'message' => 'User updated successfully!'], 200);
            }
        } else {
            return response()->json(['status' => 'error', 'message' => 'Token or name missing!'], 500);
        }
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function watchFaceDetection(Request $request): JsonResponse
    {
        $sent_token = $request->sent_token;
        $model = DB::table('users')->where(['sent_token' => $sent_token])->first();
        if ($model == null) {
            return response()->json(['status' => 'error', 'message' => 'User not found in database!'], 500);
        } else {
            if ($sent_token == $model->login_token) {
                DB::table('users')->where(['sent_token' => $sent_token])->update(['sent_token' => '', 'login_token' => '']);

                return response()->json(['status' => 'success', 'message' => 'User logined success!'], 200);
            } else {
                return response()->json(['status' => 'wait', 'message' => 'User not yet scan face!'], 200);
            }
        }
    }

    /**
     * @param Request $request
     *
     * @throws InvalidOptionsException
     *
     * @return JsonResponse
     */
    public function borswerExt(Request $request): JsonResponse
    {
        if ($request->has('mobile') && $request->has('website') && $request->has('token')) {
            $model = DB::table('users')->where(['mobile' => $request->mobile])->first();
            if ($model == null) {
                return response()->json(['status' => 'error', 'message' => 'Mobile number not found in database!'], 500);
            } else {
                $optionBuilder = new OptionsBuilder;
                $optionBuilder->setTimeToLive(60 * 20);
                if ($request->has('title')) {
                    $title = $request->title;
                } else {
                    // $title = 'default_title';
                    $title = 'Authentication Request';
                }

                $sent_token = $request->token;

                $body = 'You have new notification!'; //json_encode(['token'=>$sent_token,'website'=>$request->website]);
                // DB::table('listenings')->update(['unique_token'=>$sent_token]);

                $notificationBuilder = new PayloadNotificationBuilder($title);
                $notificationBuilder->setBody($body)
                    ->setSound('default');

                $dataBuilder = new PayloadDataBuilder;
                $dataBuilder->addData(['token' => $sent_token, 'website' => $request->website, 'type' => 'extension']);

                $option = $optionBuilder->build();
                $notification = $notificationBuilder->build();
                $data = $dataBuilder->build();

                $token = $model->device_token;

                $downstreamResponse = FCM::sendTo($token, $option, $notification, $data);

                return response()->json(['status' => 'success', 'message' => 'Request sent to FCM', 'succes_resp' => $downstreamResponse->numberSuccess(), 'fail_resp' => $downstreamResponse->numberFailure(), 'number_modification' => $downstreamResponse->numberModification(), 'sent_token' => $sent_token], 200);
                /*$downstreamResponse->numberSuccess();
                $downstreamResponse->numberFailure();
                $downstreamResponse->numberModification();*/
            }
        } else {
            return response()->json(['status' => 'error', 'message' => 'Please send mobile number!'], 500);
        }
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function getWebsiteDetails(Request $request): JsonResponse
    {
        if ($request->has('website_link')) {
            $model = DB::table('websites')->where('website_link', 'like', '%'.$request->website_link.'%')->first();
            if ($model != null) {
                $responseArray = [];
                $responseArray['username'] = $model->email;
                $responseArray['password'] = $model->password;

                return response()->json(['status' => 'success', 'data' => $responseArray], 200);
            } else {
                return response()->json(['status' => 'error', 'message' => 'No website details found!'], 200);
            }
        } else {
            return response()->json(['status' => 'error', 'message' => 'Website link is required!'], 200);
        }
    }
}
