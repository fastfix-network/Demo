<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\WordpressEmailAuth;
use App\Models\WpUser;
use App\Services\EmailService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use PHPMailer\PHPMailer\Exception;

class WordpressApiController extends ApiResponseController
{
    public EmailService $emailService;

    /**
     * Constructor for the class.
     *
     * @param EmailService $emailService The SMS service to be injected
     */
    public function __construct(EmailService $emailService)
    {
        $this->emailService = $emailService;
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function registerForWp(Request $request): JsonResponse
    {
        $requiredParams = ['country_code', 'mobile', 'email', 'domain'];
        if (! $this->validateRequiredParams($request, $requiredParams)) {
            $message = $this->requiredFieldValidation($request, $requiredParams);

            return $this->error($request,
                'Missing Required Parameters',
                $message,
                400);
        } else {
            $ivaltUserModel = User::with('device_tokens')->where(['country_code' => $request->country_code, 'mobile' => $request->mobile])->first();

            saveAppLog($request->mobile, 'Registered in '.$request->domain);

            $registerToken = Str::random(20);
            $response = [];

            if (is_null($ivaltUserModel)) {
                return $this->error($request,
                    'Not Found',
                    'The mobile number provided ('.$request->country_code.$request->mobile.') was not found.',
                    404);
            }

            WpUser::where([
                'country_code' => $request->country_code,
                'mobile'       => $request->mobile,
                'website'      => $request->domain,
                'email'        => $request->email,
            ])->delete();

            WpUser::create([
                'country_code'             => $request->country_code,
                'mobile'                   => $request->mobile,
                'mobile_with_country_code' => $request->country_code.$request->mobile,
                'email'                    => $request->email,
                'website'                  => $request->domain,
                'user_token'               => $registerToken,
            ]);

            $notificationController = new NotificationController(new \App\Services\FirebaseService);
            $notificationController->registerForWpSendNotifications($ivaltUserModel, $request, $registerToken, 'iVALT');

            return $this->success($request, ['sent_token' => $registerToken], 'Biometric Auth Request successfully sent.');
        }
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function wpRegisterConfirmation(Request $request): JsonResponse
    {
        $requiredParams = ['country_code', 'mobile', 'domain', 'token'];
        if (! $this->validateRequiredParams($request, $requiredParams)) {
            $message = $this->requiredFieldValidation($request, $requiredParams);

            return $this->error($request, 'Missing Required Parameters', $message, 400);
        } else {
            if ($request->has('supplier') && $request->has('supplier_id')) {
                $update = WpUser::where(['country_code' => $request->country_code, 'mobile' => $request->mobile, 'website' => $request->domain, 'user_token' => $request->token, 'supplier_id' => $request->supplier_id, 'supplier' => $request->supplier])
                    ->update(['confirmed' => 1]);
            } else {
                $update = WpUser::where(['country_code' => $request->country_code, 'mobile' => $request->mobile, 'website' => $request->domain, 'user_token' => $request->token])
                    ->update(['confirmed' => 1]);
            }

            if ($update == 0) {
                return $this->error($request, 'Not Found', 'The mobile number provided ('.$request->country_code.$request->mobile.') was not found.', 404);
            } else {
                return $this->success($request, null, 'Registration confirmed.');
            }
        }
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function confirmWpAuth(Request $request): JsonResponse
    {
        $requiredParams = ['country_code', 'mobile', 'domain', 'token'];
        if (! $this->validateRequiredParams($request, $requiredParams)) {
            $message = $this->requiredFieldValidation($request, $requiredParams);

            return $this->error($request,
                'Missing Required Parameters',
                $message,
                400
            );
        } else {
            $wpUserModel = WpUser::firstWhere(['country_code' => $request->country_code, 'mobile' => $request->mobile, 'website' => $request->domain, 'user_token' => $request->token]);

            if (is_null($wpUserModel)) {
                return $this->error($request,
                    'Not Found',
                    'An authorization request for mobile number ('.$request->country_code.$request->mobile.') was not found for website ('.$request->domain.'). Please resend the Authorization request.',
                    404);
            } else {
                return $this->success($request, [
                    'confirm'     => $wpUserModel->confirmed,
                    'auth_status' => $wpUserModel->app_auth_status,
                    'userDetails' => $wpUserModel,
                ], 'User authenticate successfull.');
            }
        }
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function isWpRegisteredAndConfirmed(Request $request): JsonResponse
    {
        $requiredParams = ['country_code', 'mobile', 'email', 'domain'];
        if (! $this->validateRequiredParams($request, $requiredParams)) {
            $message = $this->requiredFieldValidation($request, $requiredParams);

            return $this->error($request,
                'Missing Required Parameters',
                $message,
                400
            );
        } else {
            $wpUserModel = WpUser::firstWhere(['country_code' => $request->country_code, 'email' => $request->email, 'website' => $request->domain, 'mobile' => $request->mobile]);

            if (! is_null($wpUserModel) && ($wpUserModel->confirmed == 1)) {
                return $this->error($request,
                    'Already Registered',
                    'User already registered with iVALT.',
                    422);
            } else {
                return $this->error($request,
                    'Not Found',
                    'The mobile number provided ('.$request->country_code.' '.$request->mobile.') is not registered with iVALT.',
                    404);
            }
        }
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function sendNotification(Request $request): JsonResponse
    {
        $requiredParams = ['country_code', 'mobile', 'domain', 'email'];
        if (! $this->validateRequiredParams($request, $requiredParams)) {
            $message = $this->requiredFieldValidation($request, $requiredParams);

            return $this->error($request,
                'Missing Required Parameters',
                $message,
                400,
            );
        } else {
            $ivaltUserModel = User::with('device_tokens')->where(['country_code' => $request->country_code, 'mobile' => $request->mobile])->first();

            if ($ivaltUserModel == null) {
                return $this->error($request,
                    'Not Found',
                    'The mobile number provided ('.$request->country_code.$request->mobile.') is not registered with iVALT.',
                    404);
            }

            $notificationController = new NotificationController(new \App\Services\FirebaseService);
            $notificationController->wpVerificationSendNotification($ivaltUserModel, $request, 'iVALT');

            return $this->success($request, null, 'Biometric Auth Request successfully sent.');
        }
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function confirmAppAuthLoginForWp(Request $request): JsonResponse
    {
        $requiredParams = ['country_code', 'mobile', 'domain', 'token'];
        if (! $this->validateRequiredParams($request, $requiredParams)) {
            $message = $this->requiredFieldValidation($request, $requiredParams);

            return $this->error($request,
                'Missing Required Parameters',
                $message,
                400);
        } else {
            saveAppLog($request->mobile, 'Log In into '.$request->domain);
            $isWpUserUpdated = WpUser::where(['user_token' => $request->token, 'website' => $request->domain, 'country_code' => $request->country_code, 'mobile' => $request->mobile])
                ->update(['app_auth_status' => 'true']);

            if ($isWpUserUpdated) {
                return $this->success($request, null, 'Authentication Successful.');
            } else {
                return $this->error($request,
                    'Authentication Failed',
                    'A precondition of establishing a valid token for mobile number '.$request->country_code.$request->mobile.' and domain '.$request->domain.' was not met. Please try to re-authenticate.',
                    400);
            }
        }
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function watchForWpLogin(Request $request): JsonResponse
    {
        $requiredParams = ['country_code', 'mobile', 'email', 'domain'];
        if (! $this->validateRequiredParams($request, $requiredParams)) {
            $message = $this->requiredFieldValidation($request, $requiredParams);

            return $this->error($request,
                'Missing Required Parameters',
                $message,
                400);
        } else {
            $wpUserModel = WpUser::firstWhere([
                'country_code' => $request->country_code,
                'mobile'       => $request->mobile,
                'website'      => $request->domain,
                'email'        => $request->email,
            ]);

            if (! is_null($wpUserModel) && ($wpUserModel->app_auth_status == 'true')) {
                $token = $wpUserModel->user_token;
                $isAppAuthStatusUpdated = WpUser::where([
                    'country_code' => $request->country_code,
                    'mobile'       => $request->mobile,
                    'website'      => $request->domain,
                    'email'        => $request->email])
                    ->update(['app_auth_status' => '']);

                if ($isAppAuthStatusUpdated) {
                    return $this->success($request, ['token' => $token], 'Authentication Successful.');
                }

                return $this->error(
                    $request,
                    'Authentication failed!',
                    'User authentication failed!',
                    403);
            } else {
                return $this->error(
                    $request,
                    'Unprocessable Request',
                    'The mobile number ('.$request->country_code.$request->mobile.') was not in a valid state. Please initiate the Biometric Auth Request again before checking results.',
                    422);
            }
        }
    }

    /**
     * @param Request $request
     *
     * @throws Exception
     * @return JsonResponse
     */
    public function sendVerificationEmail(Request $request)
    {
        $requiredParams = ['domain', 'email'];
        if (! $this->validateRequiredParams($request, $requiredParams)) {
            $message = $this->requiredFieldValidation($request, $requiredParams);

            return $this->error($request,
                'Missing Required Parameters',
                $message,
                400);
        }
        $randomNumber = rand(100000, 999999);
        $this->emailService->sendWordpressVerificationEmail($request->email, $randomNumber);
        WordpressEmailAuth::updateOrCreate([
            'email'  => $request->email,
            'domain' => $request->domain,
        ], [
            'email'       => $request->email,
            'domain'      => $request->domain,
            'code'        => $randomNumber,
            'auth_status' => 0,
        ]);

        return $this->success($request, null, 'Verification email sent successfully.');
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function verifyEmailCode(Request $request): JsonResponse
    {
        $requiredParams = ['domain', 'email', 'verificationCode', 'country_code', 'mobile'];

        if (! $this->validateRequiredParams($request, $requiredParams)) {
            $message = $this->requiredFieldValidation($request, $requiredParams);

            return $this->error($request,
                'Missing Required Parameters',
                $message,
                400);
        }

        $wpUserModel = WpUser::firstWhere([
            'country_code' => $request->country_code,
            'mobile'       => $request->mobile,
            'website'      => $request->domain,
            'email'        => $request->email,
        ]);

        if (is_null($wpUserModel)) {
            return $this->error($request,
                'Email Verification Failed.',
                $request->domain.' is not found!',
                404);
        }

        $wordpressEmailAuth = WordpressEmailAuth::where([
            'email'  => $request->email,
            'domain' => $request->domain,
            'code'   => $request->verificationCode,
        ])->first();

        if (is_null($wordpressEmailAuth)) {
            return $this->error($request,
                'Email Verification Failed.',
                'Invalid verification code!',
                400);
        }

        if ($wordpressEmailAuth->delete()) {
            return $this->success($request, ['token' => $wpUserModel->user_token], 'Email verified successfully.');
        }

        return $this->error($request,
            'Email Verification Failed.',
            'Invalid verification code!',
            400);
    }
}
