<?php

namespace App\Http\Controllers;

use App\Models\User;
use DB;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Contracts\View\Factory;
use Illuminate\Contracts\View\View;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

/**
 * Class BlockchainController
 */
class BlockchainController extends Controller
{
    /**
     * @param $request
     *
     * @return mixed
     */
    public static function saveUser($request)
    {
        $insertArray = [
            '$class'              => 'org.example.mynetwork.User',
            'majorVersion'        => 0,
            'minorVersion'        => 0,
            'party_id_public_key' => 'krishna%12356%89',
            'user_name'           => $request->mobile.$request->email,
            'org_id'              => 'ivalt@321',
            'gln'                 => 'ivalt@321',
            'name'                => $request->name,
            'mname'               => $request->platform,
            'lname'               => $request->imei,
            'lname2'              => $request->device_token,
            'title'               => $request->email,
            'suffix'              => 'iValt',
            'photo_url'           => null,
            'is_admin'            => false,
            'active'              => false,
            'metadata'            => [],
            'id'                  => $request->mobile];

        return HttpController::post('User', $insertArray);
    }

    /**
     * @param $id
     *
     * @return JsonResponse
     */
    public static function getUser($id): JsonResponse
    {
        $response = HttpController::get('User', $id);

        return response()->json($response);
    }

    /**
     * @param $id
     *
     * @return JsonResponse
     */
    public static function deleteUser($id): JsonResponse
    {
        $response = HttpController::delete('User', $id);

        return response()->json($response);
    }

    /**
     * @param Request $request
     * @param null    $id
     *
     * @return mixed
     */
    public static function updateUser($request, $id = null)
    {
        return self::extractedUserDetails($request);
    }

    /**
     * @param $request
     *
     * @return JsonResponse|void
     */
    public static function extractedUserDetails($request)
    {
        $user = User::where('mobile', $request->mobile)->first();

        if (! is_null($user)) {
            $updateArray = [
                '$class'              => 'org.example.mynetwork.User',
                'majorVersion'        => 0,
                'minorVersion'        => 0,
                'party_id_public_key' => 'krishna%12356%89',
                'user_name'           => $user->mobile.$user->email,
                'org_id'              => 'ivalt@321',
                'gln'                 => 'ivalt@321',
                'name'                => $user->name,
                'mname'               => $user->platform,
                'lname'               => $user->imei,
                'lname2'              => $user->device_token,
                'title'               => $user->email,
                'suffix'              => 'iValt',
                'photo_url'           => null,
                'is_admin'            => false,
                'active'              => true,
                'metadata'            => [],
                'id'                  => $user->mobile];
            $response = HttpController::put('User', $updateArray, $user->mobile.$user->email);

            return response()->json($response);
        }
    }

    /**
     * @param Request $request
     * @param null    $id
     *
     * @return mixed
     */
    public static function updateUserSetActive($request, $id = null)
    {
        return self::extractedUserDetails($request);
    }

    public function saveUserApi($request)
    {
        return HttpController::post('User', $request->toArray());
    }

    public function updateUserApi($request, $id)
    {
        return HttpController::put('User', $request->toArray(), $id);
    }

    //  Views

    public function loginView()
    {
        return view('login');
    }

    public function listOfUsers()
    {
        $user = User::whereNotNull('chain_id')->get();

        return view('blockchain.index', ['users' => $user]);
    }

    public function userDetails(Request $request)
    {
        $user = HttpController::get('User', $request->id);

        return view('blockchain.user', ['user' => $user]);
    }

    public function userLogin(Request $request)
    {
        if ($request->password == 'krishna@321' && $request->email == 'info@ivalt.com') {
            $_SESSION['user'] = [
                'email'    => $request->email,
                'password' => $request->password,
            ];

            return redirect()->route('blackchain.users');
        } else {
            return view('login', ['error' => 'These credentials do not match with our records !']);
        }
    }

    public function allUsers()
    {
        $users = User::whereNotNull('email')->whereNotNull('name')->orderByDesc('id')->get();

        return view('blockchain.all-users', ['users' => $users]);
    }

    /**
     * @param Request $request
     *
     * @return Application|Factory|View|void
     */
    public function getUserLogs(Request $request)
    {
        if ($request->has('mobile')) {
            $logs = DB::table('logs')->where('mobile', $request->mobile)->get();

            return view('blockchain.user-logs', ['logs' => $logs]);
        }
    }

    /**
     * @return Application|Factory|View
     */
    public function logout()
    {
        session_destroy();

        return view('login');
    }
}
