<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\WpUser;
use App\Services\FirebaseService;
use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Kreait\Firebase\Exception\FirebaseException;
use Kreait\Firebase\Exception\MessagingException;

class NotificationController extends ApiResponseController
{
    protected FirebaseService $firebaseService;

    public function __construct()
    {
        $this->firebaseService = new FirebaseService;
    }

    /**
     * @param User $userModel
     * @param string $appName
     * @param string|null $mobile
     * @param string $requestFrom
     * @throws MessagingException
     * @throws FirebaseException
     * @return JsonResponse
     */
    public function sendNotificationForAuth(User $userModel, string $appName = 'iVALT', ?string $mobile = null, string $requestFrom = 'iVALT'): JsonResponse
    {

        $payloadData = [
            'title'       => $appName,
            'body'        => 'ID Request From '.$requestFrom,
            'type'        => 'global',
            'sound'       => 'default',
            'request_for' => 'login',
            'mobile'      => $mobile,
            'user_id'     => $userModel->id,
        ];

        try {
            $result = $this->firebaseService->sendNotification(
                $userModel->device_token,
                $payloadData,
                $userModel->platform
            );

            Log::channel('stderr')->debug(json_encode([
                'status'   => 'success',
                'message'  => 'Notification sent successfully',
                'request'  => request()->all(),
                'response' => $result,
                'payload'  => $payloadData,
            ], true));

            return $this->success(\request(), ['result' => $result], 'Biometric Auth Request successfully sent.');

        } catch (Exception $e) {

            Log::channel('stderr')->debug(json_encode([
                'status'   => 'error',
                'message'  => 'Failed to send notification',
                'mobile'   => $mobile,
                'response' => $e->getMessage(),
            ], true));

            return $this->error(\request(), 'Failed to send Biometric Auth Request. ', $e->getMessage(), 500);
        }
    }

    /**
     * @param User $userModel
     * @param Request $request
     * @param string $registerToken
     * @param string $appName
     *
     * @throws FirebaseException
     * @throws MessagingException
     * @return JsonResponse
     */
    public function registerForWpSendNotifications(User $userModel, Request $request, string $registerToken, string $appName): JsonResponse
    {

        $payloadData = [
            'token'       => $registerToken,
            'title'       => $appName,
            'type'        => 'wordpress',
            'website'     => $request->input('domain'),
            'mobile'      => $request->input('mobile'),
            'user_id'     => $userModel->id,
            'request_for' => 'reg_auth',
            'sound'       => 'default',
        ];

        try {
            $result = $this->firebaseService->sendNotification(
                $userModel->device_token,
                $payloadData,
                $userModel->platform
            );

            Log::channel('stderr')->debug(json_encode([
                'status'   => 'success',
                'message'  => 'Login request from wordpress',
                'request'  => $request->all(),
                'response' => $result,
                'payload'  => $payloadData,
            ], true));

            return $this->success(\request(), ['result' => $result], 'Login request from wordpress');

        } catch (Exception $e) {
            Log::channel('stderr')->debug(json_encode([
                'status'   => 'error',
                'message'  => 'Failed to send notification',
                'mobile'   => $request->input('mobile'),
                'response' => $e->getMessage(),
                'payload'  => $payloadData,
            ], true));

            return $this->error(\request(), 'Failed to send notification', $e->getMessage(), 500);
        }
    }

    /**
     * @param User $userModel
     * @param Request $request
     * @param string $appName
     *
     * @throws FirebaseException
     * @throws MessagingException
     * @return JsonResponse
     */
    public function wpVerificationSendNotification(User $userModel, Request $request, string $appName): JsonResponse
    {
        $wpModel = WpUser::firstWhere([
            'email'   => $request->input('email'),
            'mobile'  => $request->input('mobile'),
            'website' => $request->input('domain'),
        ]);

        $payloadData = [
            'title'       => $appName,
            'body'        => 'ID Request From Wordpress',
            'token'       => (! is_null($wpModel)) ? $wpModel->user_token : '',
            'type'        => 'wordpress',
            'website'     => $request->input('domain'),
            'mobile'      => $request->input('mobile'),
            'request_for' => 'login',
            'user_id'     => $userModel->id,
        ];

        try {
            $result = $this->firebaseService->sendNotification(
                $userModel->device_token,
                $payloadData,
                $userModel->platform
            );

            Log::channel('stderr')->debug(json_encode([
                'status'   => 'success',
                'message'  => 'ID Request From Wordpress',
                'request'  => $request->all(),
                'response' => $result,
                'payload'  => $payloadData,
            ], true));

            return $this->success(\request(), ['result' => $result], 'ID Request From Wordpress');

        } catch (Exception $e) {
            Log::channel('stderr')->debug(json_encode([
                'status'   => 'error',
                'message'  => 'Failed to send notification',
                'mobile'   => $request->input('mobile'),
                'response' => $e->getMessage(),                'payload'  => $payloadData,
            ], true));

            return $this->error(\request(), 'Failed to send notification', $e->getMessage(), 500);
        }

    }

    /**
     * @param User $userModel
     * @param string $appName
     * @param string $mobile
     * @param string $request_from_mobile
     *
     * @throws MessagingException
     * @throws FirebaseException
     * @return JsonResponse
     */
    public function sendNotificationForMobileAuth(User $userModel, string $appName, string $mobile, string $request_from_mobile): JsonResponse
    {
        $notificationBody = 'ID Request from '.$request_from_mobile;
        $payloadData = [
            'title'               => $appName,
            'body'                => $notificationBody,
            'type'                => 'mobile_auth',
            'mobile'              => $mobile,
            'request_from_mobile' => $request_from_mobile,
            'request_for'         => 'mobile_auth',
            'user_id'             => $userModel->id,
            'sound'               => 'default',
        ];

        try {
            $result = $this->firebaseService->sendNotification(
                $userModel->device_token,
                $payloadData,
                $userModel->platform
            );

            Log::channel('stderr')->debug(json_encode([
                'status'   => 'success',
                'message'  => 'Login request from wordpress',
                'request'  => request()->all(),
                'response' => $result,
                'payload'  => $payloadData,
            ], true));

            return $this->success(\request(), ['result' => $result], 'Biometric Auth Request Successfully Sent.');

        } catch (Exception $e) {
            Log::channel('stderr')->debug(json_encode([
                'status'   => 'error',
                'message'  => 'Failed to send notification',
                'mobile'   => $mobile,
                'response' => $e->getMessage(),
                'payload'  => $payloadData,
            ], true));

            return $this->error(\request(), 'Failed to send notification', $e->getMessage(), 500);
        }
    }

    /**
     * @param User $userModel
     * @param string $appName
     * @param string $mobile
     * @param string $notificationTitle
     * @param string $request_from_mobile
     * @param $authStatus
     *
     * @throws MessagingException
     * @throws FirebaseException
     * @return JsonResponse
     */
    public function sendNotificationAuthStatus(User $userModel, string $appName, string $mobile, string $notificationTitle, string $request_from_mobile, $authStatus): JsonResponse
    {
        $payloadData = [
            'title'               => $appName,
            'body'                => $notificationTitle,
            'type'                => 'auth_status',
            'mobile'              => $mobile,
            'request_from_mobile' => $request_from_mobile,
            'auth_status'         => $authStatus,
            'request_for'         => 'auth_status',
            'user_id'             => $userModel->id,
        ];

        try {
            $result = $this->firebaseService->sendNotification(
                $userModel->device_token,
                $payloadData,
                $userModel->platform
            );
            Log::channel('stderr')->debug(json_encode([
                'status'   => 'success',
                'message'  => 'Login request from wordpress',
                'request'  => request()->all(),
                'response' => $result,
                'payload'  => $payloadData,
            ], true));

            return $this->success(\request(), ['result' => $result], $notificationTitle);

        } catch (Exception $e) {
            Log::channel('stderr')->debug(json_encode([
                'status'   => 'error',
                'message'  => 'Failed to send notification',
                'mobile'   => $mobile,
                'response' => $e->getMessage(),
                'payload'  => $payloadData,
            ], true));

            return $this->error(\request(), 'Failed to send notification', $e->getMessage(), 500);
        }
    }
}
