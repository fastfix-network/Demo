<?php

namespace App\Http\Controllers;

use App\Models\SMSAttempt;
use App\Models\User;
use App\Services\SmsService;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SmsController extends ApiResponseController
{
    public SmsService $smsService;

    /**
     * Constructor for the class.
     *
     * @param SmsService $smsService The SMS service to be injected
     */
    public function __construct(SmsService $smsService)
    {
        $this->smsService = $smsService;
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function sendOTPCodeSMS(Request $request): JsonResponse
    {

        $requiredParams = ['mobile'];
        if (! $this->validateRequiredParams($request, $requiredParams)) {
            return $this->error(
                $request,
                'Missing Required Parameters',
                $this->requiredFieldValidation($request, $requiredParams),
                400
            );
        }

        if ($request->has('mobile') && $request->mobile == '+1123456789') {
            return $this->success(request(), 'SMS sent successfully', 'SMS sent successfully', 200);
        }

        if (! $this->isEligibleToSendSMS($request)) {
            return $this->error($request, 'Too Many Requests', 'Maximum number of SMS attempts reached for today.', 429);
        }

        if ($request->has('email')) {
            $userModel = new User;
            if ($userModel->where('email', $request->email)
                ->where(function ($query) use ($request) {
                    $query->where('mobile_with_country_code', '!=', $request->mobile);
                })
                ->exists()) {
                return $this->error(
                    $request,
                    'Email Already Exists',
                    'This email is already associated with a different mobile number.',
                    422
                );
            }
        }

        $random = rand(1111, 9999);
        $Query = DB::table('register_otps');

        $message = 'iVALT registration code is: '.$random;
        $Query->insert(['mobile' => $request->mobile, 'otp' => $random]);

        return $this->smsService->sendSMS($request->mobile, $message);
    }

    /**
     * @param Request $request
     *
     * @return bool|JsonResponse
     */
    private function isEligibleToSendSMS(Request $request)
    {
        if (! $request->has('mobile')) {
            return $this->error($request, 'Missing Required Parameters', 'The mobile number is required', 400);
        }

        $to = $request->mobile;
        $maxAttempts = 10;
        $ipAddress = request()->ip();

        $smsAttempt = SMSAttempt::where('phone_number', $to)
            ->where('ip_address', $ipAddress)
            ->first();

        // Check if the attempt record exists
        if ($smsAttempt) {
            // Check if the last attempt was made within the last 24 hours
            if ($smsAttempt->last_attempt_date && $smsAttempt->last_attempt_date->diffInHours(Carbon::now()) >= 24) {
                // Reset attempt count if more than 24 hours have passed
                $smsAttempt->attempt_count = 1;
            } else {
                // Check if maximum attempts for the day are reached
                if ($smsAttempt->attempt_count >= $maxAttempts) {
                    return false;
                }
            }
            $smsAttempt->last_attempt_date = Carbon::now();
            $smsAttempt->attempt_count += 1;
            $smsAttempt->save();
        } else {
            SMSAttempt::create([
                'phone_number'      => $to,
                'ip_address'        => $ipAddress,
                'last_attempt_date' => Carbon::now(),
                'attempt_count'     => 1,
            ]);
        }

        return true;
    }

    /**
     * Sends a success registration SMS to the user.
     *
     * @param string $to The recipient's phone number.
     * @param string $name The recipient's name.
     *
     * @return JsonResponse The response from the SMS service.
     */
    public function successReRegistrationSMS($to, $name): JsonResponse
    {
        $message = 'Hi '.$name.', your registration is successful on new device. Welcome back to iVALT!';

        return $this->smsService->sendSMS($to, $message);
    }

    /**
     * Sends a success registration SMS to the user.
     *
     * @param string $to The recipient's phone number.
     * @param string $name The recipient's name.
     *
     * @return JsonResponse The response from the SMS service.
     */
    public function successRegistrationSMS($to, $name): JsonResponse
    {
        $message = 'Hi '.$name.', your registration is successful. Welcome to iVALT!';

        return $this->smsService->sendSMS($to, $message);
    }
}
