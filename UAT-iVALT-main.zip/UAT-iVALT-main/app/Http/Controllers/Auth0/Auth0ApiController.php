<?php

namespace App\Http\Controllers\Auth0;

use App\Http\Controllers\Controller;
use App\Models\Organization\OrganizationAuthApi;

class Auth0ApiController extends Controller
{
    /**
     * @param $orgId
     * @param $user
     *
     * @return mixed|null
     */
    public static function createUser($orgId, $request)
    {
        $orgAuthApiModal = self::verifyApiToken($orgId);

        $postData = [
            'connection'    => 'Username-Password-Authentication',
            'email'         => $request->email,
            'password'      => $request->auth0_user_password,
            'user_metadata' => [
                'mobile' => $request->country_code.$request->mobile,
            ],
            'email_verified' => false,
        ];

        if (is_null($orgAuthApiModal)) {
            return;
        }

        return self::post($orgAuthApiModal->domain, 'api/v2/users', $postData, $orgAuthApiModal->api_token);
    }

    /**
     * @param $orgId
     * @param $email
     *
     * @return mixed|null
     */
    public static function checkIfUserExistOnAuth0($orgId, $email)
    {
        $orgAuthApiModal = self::verifyApiToken($orgId);
        if (is_null($orgAuthApiModal)) {
            return;
        }

        return self::get($orgAuthApiModal->domain, 'api/v2/users-by-email', ['email' => $email], $orgAuthApiModal->api_token);
    }

    /**
     * @param $orgId
     * @param $mobile
     * @param $auth0UserId
     *
     * @return mixed|null
     */
    public static function updateUser($orgId, $mobile, $auth0UserId)
    {
        $orgAuthApiModal = self::verifyApiToken($orgId);
        $postData = [
            'blocked'        => false,
            'email_verified' => false,
            'user_metadata'  => [
                'mobile' => $mobile,
            ],
        ];
        if (is_null($orgAuthApiModal)) {
            return;
        }

        return self::patch($orgAuthApiModal->domain, 'api/v2/users/'.$auth0UserId, $postData, $orgAuthApiModal->api_token);
    }

    /**
     * @param $orgId
     *
     * @return null
     */
    public static function verifyApiToken($orgId)
    {
        $orgAuthApiModal = OrganizationAuthApi::where(['organization_id' => $orgId])->first();
        $twentyFourHoursAgo = now()->subHours(24);
        if (is_null($orgAuthApiModal)) {
            return;
        }

        if (($orgAuthApiModal->updated_at >= $twentyFourHoursAgo || $orgAuthApiModal->created_at >= $twentyFourHoursAgo) && ! is_null($orgAuthApiModal->api_token)) {
            return $orgAuthApiModal;
        } else {
            return self::generateAuthToken($orgAuthApiModal);
        }
    }

    /**
     * @param $orgAuthApiModal
     *
     * @return mixed
     */
    public static function generateAuthToken($orgAuthApiModal)
    {
        $postData = [
            'client_id'     => $orgAuthApiModal->client_id,
            'client_secret' => $orgAuthApiModal->client_secret,
            'audience'      => $orgAuthApiModal->audience,
            'grant_type'    => $orgAuthApiModal->grant_type,
        ];

        $response = self::post($orgAuthApiModal->domain, 'oauth/token', $postData);
        $orgAuthApiModal->update([
            'api_token' => $response['access_token'],
        ]);

        return $orgAuthApiModal;
    }

    /**
     * @param      $auth0_domain
     * @param      $endPoint
     * @param      $data
     * @param null $auth0_token
     *
     * @return mixed
     */
    protected static function get($auth0_domain, $endPoint, $data, $auth0_token = null)
    {
        if (! is_null($data)) {
            $response = self::apiRequest($auth0_domain, $endPoint, 'GET', http_build_query($data).'', $auth0_token);
        } else {
            $response = self::apiRequest($auth0_domain, $endPoint, 'GET', $data, $auth0_token);
        }

        return $response;
    }

    /**
     * @param      $auth0_domain
     * @param      $endPoint
     * @param      $data
     * @param null $auth0_token
     *
     * @return mixed
     */
    protected static function post($auth0_domain, $endPoint, $data, $auth0_token = null)
    {
        return self::apiRequest($auth0_domain, $endPoint, 'POST', json_encode($data), $auth0_token);
    }

    /**
     * @param      $auth0_domain
     * @param      $endPoint
     * @param      $data
     * @param null $auth0_token
     *
     * @return mixed
     */
    protected static function patch($auth0_domain, $endPoint, $data, $auth0_token = null)
    {
        return self::apiRequest($auth0_domain, $endPoint, 'PATCH', json_encode($data), $auth0_token);
    }

    /**
     * @param      $auth0_domain
     * @param      $endPoint
     * @param      $id
     * @param null $auth0_token
     *
     * @return mixed
     */
    protected function delete($auth0_domain, $endPoint, $id, $auth0_token = null)
    {
        return self::apiRequest($auth0_domain, $endPoint, 'DELETE', $id, $auth0_token);
    }

    /**
     * @param      $auth0_domain
     * @param      $endPoint
     * @param      $id
     * @param null $auth0_token
     *
     * @return mixed
     */
    protected function head($auth0_domain, $endPoint, $id, $auth0_token = null)
    {
        $data = ['id' => $id];

        return self::apiRequest($auth0_domain, $endPoint, 'HEAD', $data, $auth0_token);
    }

    /**
     * @param      $auth0_domain
     * @param      $endPoint
     * @param      $data
     * @param null $auth0_token
     *
     * @return mixed
     */
    protected function put($auth0_domain, $endPoint, $data, $id = null)
    {
        return self::apiRequest($auth0_domain, $endPoint, 'PUT', json_encode($data), $id);
    }

    /**
     * @param      $auth0_domain
     * @param      $endpoint
     * @param      $type
     * @param      $data
     * @param null $auth0_token
     *
     * @return mixed
     */
    protected static function apiRequest($auth0_domain, $endpoint, $type, $data, $auth0_token = null)
    {
        $curl = curl_init();
        if (($type === 'GET' || $type === 'DELETE') && $data !== null) {
            $url = $auth0_domain.'/'.$endpoint.'?'.$data;
        } elseif ($type === 'PUT' && $auth0_token != null) {
            $url = $auth0_domain.'/'.$endpoint.'/'.$auth0_token;
        } else {
            $url = $auth0_domain.'/'.$endpoint;
        }

        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_ENCODING, '');
        curl_setopt($curl, CURLOPT_MAXREDIRS, 10);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($curl, CURLOPT_TIMEOUT, 0);
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($curl, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $type);

        $headerData = [
            'Content-Type: application/json',
            'Cookie: did=s%3Av0%3A4aa81210-7dd8-11ed-bbd8-551d8195b450.bQVh0pKGz5SwjiiZR%2Fy9vQq9dDLcF%2FIrHA1MbRg4zoQ; did_compat=s%3Av0%3A4aa81210-7dd8-11ed-bbd8-551d8195b450.bQVh0pKGz5SwjiiZR%2Fy9vQq9dDLcF%2FIrHA1MbRg4zoQ',
        ];

        if (! is_null($auth0_token)) {
            $headerData[] = 'Authorization: Bearer '.$auth0_token;
        }

        if (($type === 'POST' || $type === 'PUT' || $type === 'PATCH') && $data != null) {
            curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
        }

        curl_setopt($curl, CURLOPT_HTTPHEADER, $headerData);
        $response = json_decode(curl_exec($curl), true);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
            echo 'cURL Error #:'.$err;
            dd(['$err' => $err]);
        } else {
            return $response;
        }
    }
}
