<?php

namespace App\Http\Controllers;

use App\Models\Organization\Organization;
use App\Models\Organization\OrganizationUser;
use App\Models\Organization\OrganizationUserPool;
use App\Models\Organization\TimeSlot;
use App\Models\PersonalAccessClient;
use App\Models\RegisterOtp;
use App\Models\User;
use App\Models\UserDeviceTokens;
use App\Models\WebAuth;
use App\Models\WebCardUser;
use App\Models\WpUser;
use App\Services\EmailService;
use Carbon\Carbon;
use FCM;
use Illuminate\Auth\AuthenticationException;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Contracts\Routing\ResponseFactory;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Kreait\Firebase\Exception\FirebaseException;
use Kreait\Firebase\Exception\MessagingException;
use LaravelFCM\Message\OptionsBuilder;
use LaravelFCM\Message\PayloadDataBuilder;
use LaravelFCM\Message\PayloadNotificationBuilder;
use PHPMailer\PHPMailer\Exception;

class ServerController extends ApiResponseController
{
    private EmailService $emailService;

    /**
     * Constructor for the class.
     *
     * @param EmailService $emailService The SMS service to be injected
     */
    public function __construct(EmailService $emailService)
    {
        $this->emailService = $emailService;
    }

    /**
     * @param Request $request
     *
     * @throws Exception
     * @return JsonResponse
     */
    public function sendExtNotification(Request $request): JsonResponse
    {
        $requiredParams = ['mobile', 'domain', 'token'];
        if (! $this->validateRequiredParams($request, $requiredParams)) {
            $message = $this->requiredFieldValidation($request, $requiredParams);

            return $this->error(
                $request,
                'Missing Required Parameters',
                $message,
                400
            );
        } else {
            $model = User::where(['mobile' => $request->mobile])->first();
            if (is_null($model)) {
                return $this->error(
                    $request,
                    'Not Found',
                    'The mobile number provided (' . $request->mobile . ') is not registered with iValt.',
                    404
                );
            } else {
                $optionBuilder = new OptionsBuilder;
                $optionBuilder->setTimeToLive(60 * 20);
                $title = 'WP Login Request';
                $notificationBuilder = new PayloadNotificationBuilder($title);
                $notificationBuilder->setBody('New iVault Extension Request')->setSound('default')->setClickAction('FCM_PLUGIN_ACTIVITY');
                $dataBuilder = new PayloadDataBuilder;
                $dataBuilder->addData(['token' => $request->token, 'type' => 'extension', 'website' => $request->domain, 'mobile' => $request->mobile, 'request_for' => 'extension_login', 'user_id' => $model->id]);
                $option = $optionBuilder->build();
                $notification = $notificationBuilder->build();
                $data = $dataBuilder->build();
                $token = $model->device_token;
                $downstreamResponse = FCM::sendTo($token, $option, $notification, $data);

                return $this->success($request, null, 'Biometric Auth Request successfully sent.');
            }
        }
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function putDetails(Request $request): JsonResponse
    {
        $requiredParams = ['username', 'password', 'token'];
        if (! $this->validateRequiredParams($request, $requiredParams)) {
            $message = $this->requiredFieldValidation($request, $requiredParams);

            return $this->error(
                $request,
                'Missing Required Parameters',
                $message,
                400
            );
        } else {
            $insertData = ['username' => $request->username, 'password' => $request->password, 'unique_token' => $request->token];
            DB::table('listenings')->insert($insertData);

            return $this->success($request, null, 'Credentials updated successfully.');
        }
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function listenForCredentials(Request $request): JsonResponse
    {
        if (! $request->has('token')) {
            $message = $this->requiredFieldValidation($request, ['token']);

            return $this->error(
                $request,
                'Missing Required Parameters',
                $message,
                400
            );
        } else {
            $model = DB::table('listenings')->where('unique_token', $request->token)->first();
            if (is_null($model)) {
                return $this->error(
                    $request,
                    'Unprocessable Request',
                    'The token (' . $request->token . ') was not in a valid state. Please initiate the Biometric Auth Request again before checking results.',
                    422
                );
            } else {
                DB::table('listenings')->where('unique_token', $request->token)->delete();

                return $this->success($request, [
                    'username' => $model->username,
                    'password' => $model->password,
                ], 'Credentials retrieved successfully.');
            }
        }
    }

    /**
     * @param Request $request
     *
     * @throws Exception
     * @return JsonResponse
     */
    public function confirmRegistration(Request $request): JsonResponse
    {
        $requiredParams = ['mobile', 'user_code', 'country_code'];
        if (! $this->validateRequiredParams($request, $requiredParams)) {
            $message = $this->requiredFieldValidation($request, $requiredParams);

            return $this->error(
                $request,
                'Missing Required Parameters',
                $message,
                400
            );
        } else {
            $mobile = $request->mobile;
            $smsCode = $request->user_code;
            $countryCode = $request->country_code;

            $isOTPValid = RegisterOtp::where(['mobile' => $countryCode . $mobile, 'otp' => $smsCode])->count();

            if ($isOTPValid > 0) {
                RegisterOtp::where(['mobile' => $countryCode . $mobile])->delete();

                return $this->registerUser($request);
            } else {
                return $this->error(
                    $request,
                    'Invalid OTP',
                    'The OTP provided is not valid.',
                    422
                );
            }
        }
    }

    /**
     * @param Request $request
     *
     * @throws Exception
     * @return JsonResponse
     */
    public function registerUser(Request $request): JsonResponse
    {
        $requiredParams = ['mobile', 'country_code', 'name', 'platform', 'email', 'imei', 'device_token', 'user_code'];
        if (! $this->validateRequiredParams($request, $requiredParams)) {
            $message = $this->requiredFieldValidation($request, $requiredParams);

            return $this->error(
                $request,
                'Missing Required Parameters',
                $message,
                400
            );
        } else {
            $platform = 'ios';
            if ($request->has('platform') && $request->platform == 'android') {
                $platform = 'android';
            } else {
                return $this->error(
                    $request,
                    'Invalid Platform',
                    'The platform provided is not valid.',
                    422
                );
            }

            return $this->storeIValtUser($request, $platform);
        }
    }

    /**
     * @param $request
     * @param $platform
     *
     * @throws Exception
     * @return JsonResponse
     */
    public function storeIValtUser($request, $platform): JsonResponse
    {
        //Store user details on blockchain server
        $chainId = null;
        $emailVerificationToken = $this->randomString(36);

        // try {
        //     $blockChainResponse = BlockchainController::saveUser($request);
        // } catch (Exception $e) {
        //     return $this->error(
        //         $request,
        //         'Internal Server Error',
        //         'An error occurred while saving user details on blockchain server.',
        //         500
        //     );
        // }

        // if (isset($blockChainResponse['user_name'])) {
        //     $chainId = $blockChainResponse['user_name'];
        // }

        $model = new User;
        $data = $model->where(['country_code' => $request->country_code, 'mobile' => $request->mobile])->first();

        if ($data == null) {
            $insertArray = [
                'country_code'             => $request->country_code,
                'mobile'                   => $request->mobile,
                'mobile_with_country_code' => $request->country_code . $request->mobile,
                'device_token'             => $request->device_token,
                'platform'                 => $platform,
                'chain_id'                 => $chainId,
                'is_email_verified'        => 0,
                'email_verification_token' => $emailVerificationToken,
            ];

            if ($request->has(['name', 'imei'])) {
                $insertArray['name'] = $request->name;
                $insertArray['imei'] = $request->imei;
            }

            if ($request->has(['supplier_id', 'supplier'])) {
                $insertArray['supplier_id'] = $request->supplier_id;
                $insertArray['supplier'] = $request->supplier;
            }

            if ($request->has('email')) {
                $insertArray['email'] = $request->email;
                $insertArray['created_at'] = now();
                $this->emailService->sendMobileAppVerificationEmail($request->email, $this->hideMobileNumber($request->mobile), $emailVerificationToken);
            }

            $model = User::insertGetId($insertArray);

            if ($model > 0) {
                $userDeviceTokenModel = new UserDeviceTokens;
                $status = $userDeviceTokenModel->create(['user_id' => $model, 'device_token' => $request->device_token, 'imei' => $request->imei, 'platform' => $platform]);
            }

            return $this->success(
                $request,
                ['id' => $model, 'mobile' => $request->mobile, 'blockChainResponse' => $blockChainResponse ?? null],
                'User registered successfully.',
                200
            );
        } else {
            $userDeviceTokenModel = new UserDeviceTokens;
            $isExist = $userDeviceTokenModel->where(['user_id' => $data->id, 'imei' => $request->imei])->get();
            if ($isExist->count() == 0) {
                $status = $userDeviceTokenModel->create(['user_id' => $data->id, 'device_token' => $request->device_token, 'imei' => $request->imei, 'platform' => $platform]);
            }
            if ($request->has('email')) {
                $insertArray = [
                    'country_code'             => $request->country_code,
                    'mobile_with_country_code' => $request->country_code . $request->mobile,
                    'device_token'             => $request->device_token,
                    'email'                    => $request->email,
                    'platform'                 => $platform,
                    'is_email_verified'        => 0,
                    'email_verification_token' => $emailVerificationToken,
                ];

                if (is_null($data->chain_id) && ! is_null($chainId)) {
                    $insertArray['chain_id'] = $chainId;
                }

                if ($request->has('name') && $request->has('imei')) {
                    $insertArray['name'] = $request->name;
                    $insertArray['imei'] = $request->imei;
                    $insertArray['updated_at'] = date('Y-m-d h:i:s');
                }

                if ($request->has('supplier_id') && $request->has('supplier')) {
                    $insertArray['supplier_id'] = $request->supplier_id;
                    $insertArray['supplier'] = $request->supplier;
                }

                $model->where(['mobile' => $request->mobile])->update($insertArray);
                $userDeviceTokenModel->where(['user_id' => $data->id, 'imei' => $request->imei])->update(['device_token' => $request->device_token]);
            } else {
                $userDeviceTokenModel->where(['user_id' => $data->id, 'imei' => $request->imei])->update(['device_token' => $request->device_token]);
            }

            $data = $model->where(['mobile' => $request->mobile])->first();

            $this->emailService->sendMobileAppVerificationEmail($request->email, $this->hideMobileNumber($request->mobile), $emailVerificationToken);

            return $this->success(
                $request,
                ['id' => $data->id, 'mobile' => $request->mobile, 'blockChainResponse' => $blockChainResponse ?? null],
                'User registered successfully.',
                200
            );
        }
    }

    protected function randomString($length)
    {
        $keys = array_merge(range(0, 9), range('a', 'z'), range('A', 'Z'));

        $key = '';
        for ($i = 0; $i < $length; $i++) {
            $key .= $keys[mt_rand(0, count($keys) - 1)];
        }

        return $key;
    }

    protected function hideMobileNumber($mobileNumber)
    {
        return
            substr($mobileNumber, 0, 2) .
            str_repeat('*', strlen($mobileNumber) - 6) .
            substr($mobileNumber, -4);
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function putCopWebsiteDetails(Request $request): JsonResponse
    {
        $requiredParams = ['domain', 'token'];
        if (! $this->validateRequiredParams($request, $requiredParams)) {
            $message = $this->requiredFieldValidation($request, $requiredParams);

            return $this->error(
                $request,
                'Missing Required Parameters',
                $message,
                400
            );
        }

        $model = DB::table('websites')->where('website_link', $request->domain)->first();

        if (is_null($model)) {
            return $this->error(
                $request,
                'Not found',
                'The website you are looking for does not exist.',
                400
            );
        }

        DB::table('listenings')->insert([
            'username'     => $model->email,
            'password'     => $model->password,
            'unique_token' => $request->token,
        ]);

        return $this->success(
            $request,
            'Credentials updated successfully.',
            ['status' => 'success'],
            200
        );
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function validateBackupUser(Request $request): JsonResponse
    {
        if (! $request->has('mobile')) {
            return $this->error(
                $request,
                'Missing Required Parameters',
                'Mobile number is required.',
                400
            );
        } else {
            $model = User::where('mobile', $request->mobile)->first();

            saveAppLog($request->mobile, 'Log In from backup system');

            if (is_null($model)) {
                return $this->error(
                    $request,
                    'Not Found',
                    'The mobile number provided (' . $request->mobile . ') is not registered with iValt.',
                    404
                );
            }

            return $this->success(
                $request,
                [
                    'user' => [
                        'id'     => $model->id,
                        'mobile' => $request->mobile,
                    ],
                ],
                'User found.',
                200
            );
        }
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function getListOfWebsites(Request $request): JsonResponse
    {
        if (! $request->has('mobile')) {
            return $this->error(
                $request,
                'Missing Required Parameters',
                'Mobile number is required.',
                400
            );
        } else {
            $wpUserModel = WpUser::where('mobile', $request->mobile);

            if ($wpUserModel->count() == 0) {
                return $this->success(
                    $request,
                    [],
                    'Websites not found.',
                    200
                );
            }

            return $this->success(
                $request,
                $wpUserModel->get()->toArray(),
                'Websites found.',
                200
            );
        }
    }

    public function authBackupWebsite(Request $request)
    {
        if (! $request->has('token')) {
            return $this->error(
                $request,
                'Missing Required Parameters',
                'Token is required.',
                400
            );
        }
        $userModel = WpUser::where(['user_token' => $request->token]);

        if ($userModel->count() == 0) {
            return $this->error(
                $request,
                'Not Found',
                'The token provided (' . $request->token . ') is not valid.',
                404
            );
        }

        $isUserUpdated = $userModel->update(['app_auth_status' => 'true']);

        return $this->success(
            $request,
            'User authenticated successfully.',
            ['user_id' => $isUserUpdated->id],
            200
        );
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function refreshToken(Request $request): JsonResponse
    {
        $requiredParams = ['mobile', 'token', 'imei'];

        if (! $this->validateRequiredParams($request, $requiredParams)) {
            $message = $this->requiredFieldValidation($request, $requiredParams);

            return $this->error(
                $request,
                'Missing Required Parameters.',
                $message,
                400
            );
        }

        $ivaltUserModel = User::where('mobile', $request->mobile)->first();

        if ($ivaltUserModel == null) {
            return $this->error(
                $request,
                'Not Found',
                'The mobile number provided (' . $request->mobile . ') is not registered with iValt.',
                404
            );
        } else {
            $isImeiExist = UserDeviceTokens::where('imei', '=', $request->imei)->first();
            if (is_null($isImeiExist)) {
                return $this->error(
                    $request,
                    'Not Found',
                    'Provided imei is not valid.',
                    404
                );
            } else {
                UserDeviceTokens::where('imei', '=', $request->imei)->update(['device_token' => $request->token]);
                User::where('mobile', $request->mobile)->update(['device_token' => $request->token, 'imei' => $request->imei]);
            }
        }

        return $this->success(
            $request,
            ['blockChainResponse' => $blockChainResponse ?? null],
            'Device token updated successfully.',
            200
        );
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function removeWebsite(Request $request): JsonResponse
    {
        $requiredParams = ['mobile', 'email', 'website'];

        if (! $this->validateRequiredParams($request, $requiredParams)) {
            $message = $this->requiredFieldValidation($request, $requiredParams);

            return $this->error(
                $request,
                'Missing Required Parameters.',
                $message,
                400
            );
        }

        $Query = WpUser::where([
            'email'   => $request->email,
            'website' => $request->website,
            'mobile'  => $request->mobile,
        ])->delete();

        if ($Query) {
            return $this->success(
                $request,
                'Website removed successfully.',
                ['website' => $request->website],
                200
            );
        }

        return $this->error(
            $request,
            'Not Found',
            'Website not found.',
            404
        );
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function getWebsitesList(Request $request): JsonResponse
    {
        if (! $request->has('mobile')) {
            $message = $this->requiredFieldValidation($request, ['mobile']);

            return $this->error(
                $request,
                'Missing Required Parameters.',
                $message,
                400
            );
        }

        $wpUserModel = WpUser::where('mobile', $request->mobile);

        if ($wpUserModel->count() == 0) {
            return $this->success(
                $request,
                [],
                'No websites found.',
                404
            );
        }

        $websites = [];
        foreach ($wpUserModel->get() as $website) {
            $websites[] = $website->website;
        }

        return $this->success(
            $request,
            ['websites' => $websites],
            'Websites available.',
            200
        );
    }

    /**
     * @param Request $request
     *
     * @throws MessagingException
     * @throws FirebaseException
     * @return JsonResponse
     */
    public function sendGlobalNotification(Request $request): JsonResponse
    {
        $requiredParams = ['mobile'];
        $requestFrom = $request->has('requestFrom') ? $request->requestFrom : 'OnDemandID.com';
        if (! $this->validateRequiredParams($request, $requiredParams)) {
            $message = $this->requiredFieldValidation($request, $requiredParams);

            return $this->error(
                $request,
                'Missing Required Parameters',
                $message,
                400
            );
        } else {
            $userModel = User::where(['mobile_with_country_code' => $request->mobile])->first();

            if (! is_null($userModel)) {
                // Delete records older than 5 minutes from the table WebAuth
                WebAuth::where('mobile_with_country_code', $request->mobile)->delete();

                $notification = new NotificationController;

                return $notification->sendNotificationForAuth(
                    $userModel,
                    'iVALT',
                    $request->mobile,
                    $requestFrom
                );
            } else {
                return $this->error(
                    $request,
                    'Not Found',
                    'The mobile number provided (' . $request->mobile . ') was not found.',
                    404
                );
            }
        }
    }

    /**
     * @param Request $request
     *
     * @throws FirebaseException
     * @throws MessagingException
     * @return JsonResponse
     */
    public function globalAuthenticate(Request $request): JsonResponse
    {
        $requiredParams = ['mobile', 'status', 'country_code'];
        if (! $this->validateRequiredParams($request, $requiredParams)) {
            $message = $this->requiredFieldValidation($request, $requiredParams);

            return $this->error(
                $request,
                'Missing Required Parameters',
                $message,
                400
            );
        } else {
            $userModel = User::where([
                'country_code' => $request->country_code,
                'mobile'       => $request->mobile,
            ])->first();

            if (is_null($userModel)) {
                return $this->error(
                    $request,
                    'User Not Found',
                    'No user found with the provided mobile number',
                    404
                );
            }

            $webAuthModel = DB::table('web_auth');

            if ($request->has('request_from_mobile')) {
                $userModel = User::where([
                    'mobile_with_country_code' => $request->request_from_mobile,
                ])->first();
                if (! is_null($userModel)) {
                    $notificationController = new NotificationController;
                    $fullMobileNumber = $request->country_code . $request->mobile;

                    if ($request->status === true || $request->status === 'true' || $request->status === '1' || $request->status === 1) {
                        $notificationMessage = $fullMobileNumber . ' Authenticated Successfully.';
                    } else {
                        $notificationMessage = $fullMobileNumber . ' Authenticated Failed.';
                    }

                    $notificationController->sendNotificationAuthStatus(
                        $userModel,
                        'iVALT',
                        $request->mobile,
                        $notificationMessage,
                        $fullMobileNumber,
                        $request->status
                    );
                }
            }

            $insertArray = [
                'country_code'             => $request->country_code,
                'mobile'                   => $request->mobile,
                'mobile_with_country_code' => $request->country_code . $request->mobile,
                'request_from_mobile'      => $request->has('request_from_mobile') ? $request->request_from_mobile : null,
                'imei'                     => $request->imei ?? null,
            ];

            if ($request->has('full_address') && ($request->full_address === true || $request->full_address === 'true' || $request->full_address === '1' || $request->full_address === 1)) {
                $insertArray['full_address'] = 1;
            } else {
                $insertArray['full_address'] = 0;
            }

            if ($request->has(['timezone', 'time'])) {
                $insertArray['timezone'] = json_encode($request->timezone, true);
                $insertArray['time'] = Carbon::parse($request->time)->format('h:i A');
            }

            if ($request->has(['latitude', 'longitude'])) {
                $insertArray['latitude'] = $request->latitude;
                $insertArray['longitude'] = $request->longitude;
            }

            if ($request->has('address')) {
                $insertArray['address'] = $request->address;
            }

            if ($request->status === true || $request->status === 'true' || $request->status === '1' || $request->status === 1) {
                $insertArray['login_status'] = 1;
                $webAuthModel->insert($insertArray);
            } else {
                $insertArray['login_status'] = 0;
                $webAuthModel->insert($insertArray);
            }

            return $this->success($request, null, 'iVALT ID Verification Request Sent.');
        }
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function validateGlobalAuth(Request $request): JsonResponse
    {
        $requiredParams = ['mobile'];
        /* Checking if the request has a mobile number. If not, it will return an error. */
        if (! $this->validateRequiredParams($request, $requiredParams)) {
            $message = $this->requiredFieldValidation($request, $requiredParams);

            return $this->error(
                $request,
                'Missing Required Parameters',
                $message,
                400
            );
        }

        $mobileNumberWithCountryCode = $request->mobile;

        // get the user
        $userModel = $this->getUserModel($mobileNumberWithCountryCode);

        if (is_null($userModel)) {
            // return an error to the user
            return $this->error(
                $request,
                'Not Found',
                'The mobile number provided (' . $mobileNumberWithCountryCode . ') was not found.',
                404
            );
        }

        // $timestamp5MinutesAgo = Carbon::now()->subMinutes(5);

        // // Delete records older than 5 minutes
        // WebAuth::where('created_at', '<', $timestamp5MinutesAgo)->delete();

        $webAuthModel = WebAuth::where('mobile_with_country_code', $mobileNumberWithCountryCode)
            // ->where('created_at', '>=', $timestamp5MinutesAgo)
            ->first();

        // if the login request was not found, stop now
        if (is_null($webAuthModel)) {
            // return an error to the user
            return $this->error(
                $request,
                'Unprocessable Request',
                'The mobile number (' . $mobileNumberWithCountryCode . ') was not in a valid state. Please initiate the Biometric Auth Request again before checking results.',
                422
            );
        }

        // check if the user's status is valid.
        if ($webAuthModel->login_status === 0 || $webAuthModel->login_status === '0') {
            $this->deleteWebAuthUser($mobileNumberWithCountryCode);

            return $this->error(
                $request,
                'Unauthorized',
                'The mobile number (' . $mobileNumberWithCountryCode . ') is not authenticated.',
                401
            );
        }

        /* Fetching the location of the user from the database and then using the latitude and longitude to get the address of the user. */
        $address = $this->fetchLocation($webAuthModel->latitude, $webAuthModel->longitude, $webAuthModel->full_address);

        /* Check to see if location data is present */
        $responseData = [
            'id'           => $webAuthModel->id,
            'name'         => $userModel->name,
            'email'        => $userModel->email,
            'country_code' => $userModel->country_code,
            'mobile'       => $userModel->mobile,
            'latitude'     => $webAuthModel->latitude,
            'longitude'    => $webAuthModel->longitude,
            'imei'         => $userModel->imei,
        ];

        if (! is_null($address) && $address !== '') {
            $responseData['address'] = $address;
        }

        /*
            Delete all records matching this mobile number just in case the number IS in the database but was added over 120 seconds ago
            OR User Authenticated Successfully
        */
        $this->deleteWebAuthUser($mobileNumberWithCountryCode);

        /* Saving the user's mobile number and the action "Log In with Face Authentication" to the database. */
        saveAppLog($userModel->mobile, 'Log In with Face Authentication');

        return $this->success($request, $responseData, 'Biometric Authentication successfully done.');
    }

    /**
     * @param $mobileNumberWithCountryCode
     *
     * @return User|WebCardUser
     */
    private function getUserModel($mobileNumberWithCountryCode)
    {
        // first check the WebCardUser table.
        $userModel = WebCardUser::where(['mobile_with_country_code' => $mobileNumberWithCountryCode])->first();

        // if not in User table, check the users table.  This means that the user is an iValt user, not webcard
        if (is_null($userModel)) {
            $userModel = User::where(['mobile_with_country_code' => $mobileNumberWithCountryCode])->first();
        }

        return $userModel;
    }

    /**
     * @param $mobileNumberWithCountryCode
     *
     * @return void
     */
    private function deleteWebAuthUser($mobileNumberWithCountryCode): void
    {
        WebAuth::where(['mobile_with_country_code' => $mobileNumberWithCountryCode])->delete();
    }

    /**
     * @param float $latitude
     * @param float $longitude
     * @param bool $fullAddress
     *
     * @return mixed
     */
    public function fetchLocation($latitude, $longitude, $fullAddress = false)
    {
        $apiKey = 'AIzaSyALJEtMA1fp-GhxP3IyS-50wxRrNav5GrA'; // Replace 'YOUR_GOOGLE_MAPS_API_KEY' with your actual API key

        // Construct the API URL for Google Maps Geocoding API
        $url = 'https://maps.googleapis.com/maps/api/geocode/json?latlng=' . $latitude . ',' . $longitude . '&key=' . $apiKey;

        // Using cURL to fetch data from Google Maps Geocoding API
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $result = curl_exec($ch);

        curl_close($ch);

        $decodedResult = json_decode($result, true);

        if (! isset($decodedResult['results']) || (count($decodedResult['results']) === 0) || is_null($decodedResult) || empty($decodedResult)) {
            return '';
        }

        // Check if full address flag is true or false and return accordingly
        if ($fullAddress) {
            return $decodedResult['results'][0]['formatted_address'];
        } else {
            $city = '';
            $state = '';
            $country = '';
            // Extracting city, state, and country information from the response
            foreach ($decodedResult['results'][0]['address_components'] as $component) {
                if (in_array('locality', $component['types'])) {
                    $city = $component['long_name'];
                }
                if (in_array('administrative_area_level_1', $component['types'])) {
                    $state = $component['long_name'];
                }
                if (in_array('country', $component['types'])) {
                    $country = $component['long_name'];
                }
            }

            // Returning the formatted address
            return $city . ', ' . $state . ', ' . $country;
        }
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function validateGlobalAuthGeoFence(Request $request): JsonResponse
    {
        $requiredParams = ['mobile'];
        /* Checking if the request has a mobile number. If not, it will return an error. */
        if (! $request->has($requiredParams)) {
            $message = $this->requiredFieldValidation($request, $requiredParams);

            return $this->error(
                $request,
                'Missing Required Parameters',
                $message,
                400
            );
        }
        $mobileNumberWithCountryCode = $request->mobile;

        // find the user in the web_auth table in the last 120 seconds
        $webAuthModel = WebAuth::where(['mobile_with_country_code' => $mobileNumberWithCountryCode])->first();

        //        if ($webAuthModel) {
        //            $createdAt = $webAuthModel->created_at;
        //            $now = Carbon::now();
        //            $createdAtDateTime = Carbon::parse($createdAt);
        //            $diffInMinutes = $now->diffInMinutes($createdAtDateTime);
        //
        //            if ($diffInMinutes > 5) {
        //                $webAuthModel->delete();
        //            }
        //        }

        // if the login request was not found, stop now
        if (is_null($webAuthModel)) {
            // return an error to the user
            return $this->error(
                $request,
                'Not Found',
                'The mobile number provided (' . $mobileNumberWithCountryCode . ') was not found.',
                404
            );
        }

        // check if the user's status is valid.
        if ($webAuthModel->login_status == 0) {
            return $this->error(
                $request,
                'Unprocessable Request',
                'The mobile number (' . $mobileNumberWithCountryCode . ') was not in a valid state. Please initiate the Biometric Auth Request again before checking results.',
                422
            );
        }

        // get the user
        $userModel = User::where(['mobile_with_country_code' => $mobileNumberWithCountryCode])->first();

        if (is_null($userModel)) {
            return $this->error(
                $request,
                'Not Found',
                'The mobile number provided (' . $mobileNumberWithCountryCode . ') was not found.',
                404
            );
        }

        // check imei
        //        if($userModel->imei !== $webAuthModel->imei){
        //            return $this->error(
        //                $request,
        //                'Unprocessable Request',
        //                'The device id is not matched.',
        //                404
        //            );
        //        }

        if ($userModel->verify_timeslots) {
            $userTimezone = json_decode($webAuthModel->timezone, true);
            if ($userModel->orgTimeSlots->count() > 0) {
                $isTimeZoneValid = [];
                foreach ($userModel->orgTimeSlots as $key => $timeSlotData) {
                    $timeSlotTimeZoneArray = json_decode($timeSlotData->timezone, true);

                    // Check if the user's time zone matches the stored time zone
                    if ($userTimezone['value'] === $timeSlotTimeZoneArray['value']) {
                        // Set the timezone for the user's current time
                        $currentTime = Carbon::parse($webAuthModel->time);

                        // Get the start and end times from the request and set their timezones to the user's timezone
                        $startTime = Carbon::parse($timeSlotData->start_time);

                        $endTime = Carbon::parse($timeSlotData->end_time);

                        // Verify if the current time is between the start and end times
                        if ($currentTime->between($startTime, $endTime)) {
                            $isTimeZoneValid[] = true;
                        } else {
                            $isTimeZoneValid[] = false;
                        }
                    } else {
                        $isTimeZoneValid[] = false;
                    }
                }

                $isUserInTimeZoneCollection = collect($isTimeZoneValid)->filter(function ($value) {
                    return $value !== false;
                });

                if ($isUserInTimeZoneCollection->count() === 0) {
                    $this->deleteWebAuthUser($mobileNumberWithCountryCode);

                    return $this->error($request, 'Invalid details', 'You are not within the timezone.', 403);
                }
            }
        }

        // Verify geofencing only if enabled for requested user
        if ($userModel->verify_geo_fencing) {
            $isUserInGeoFencing = [];
            if ($userModel->orgGeoFences->count() > 0) {
                if (! is_null($userModel->organizations)) {
                    $isUserInGeoFencing[] = $this->checkLocationInCollection(
                        $webAuthModel->latitude,
                        $webAuthModel->longitude,
                        $userModel->orgGeoFences
                    );

                    $isUserInGeoFencingCollection = collect($isUserInGeoFencing)->filter(function ($value) {
                        return $value !== null;
                    });
                    if ($isUserInGeoFencingCollection->count() === 0) {
                        $this->deleteWebAuthUser($mobileNumberWithCountryCode);

                        return $this->error($request, 'Invalid details', 'You are not within the geofencing location.', 403);
                    }
                }
            }
        }

        /* Fetching the location of the user from the database and then using the latitude and longitude to get the address of the user. */
        $address = $this->fetchLocation($webAuthModel->latitude, $webAuthModel->longitude, $webAuthModel->full_address);

        /* Check to see if location data is present */
        $responseData = [
            'id'           => $webAuthModel->id,
            'name'         => $userModel->name,
            'email'        => $userModel->email,
            'country_code' => $userModel->country_code,
            'mobile'       => $userModel->mobile,
            'latitude'     => $webAuthModel->latitude,
            'longitude'    => $webAuthModel->longitude,
            'imei'         => $userModel->imei,
        ];

        if (! is_null($address) && $address !== '') {
            $responseData['address'] = $address;
        }

        /*
            Delete all records matching this mobile number just in case the number IS in the database but was added over 120 seconds ago
            OR User Authenticated Successfully
        */
        $this->deleteWebAuthUser($mobileNumberWithCountryCode);

        /* Saving the user's mobile number and the action "Log In with Face Authentication" to the database. */
        saveAppLog($userModel->mobile, 'Log In with Face Authentication');

        return $this->success($request, $responseData, 'Biometric Authentication successfully done.');
    }

    /**
     * @param $inputLatitude
     * @param $inputLongitude
     * @param $locations
     *
     * @return null
     */
    public function checkLocationInCollection($inputLatitude, $inputLongitude, $locations = null)
    {
        if (is_null($locations)) {
            return $locations;
        }
        foreach ($locations as $location) {
            $distance = $this->calculateDistance($inputLatitude, $inputLongitude, $location->latitude, $location->longitude);
            if (($distance <= $location->radius) && ($location->is_active === 1 || $location->is_active === '1')) {
                return $location;
            }
        }
    }

    /**
     * @param $userInputLatitude
     * @param $userInputLongitude
     * @param $dbStoredLatitude
     * @param $dbStoredLongitude
     *
     * @return float|int
     */
    private function calculateDistance($userInputLatitude, $userInputLongitude, $dbStoredLatitude, $dbStoredLongitude)
    {
        $earthRadius = 3959;
        $latFrom = deg2rad($userInputLatitude);
        $longFrom = deg2rad($userInputLongitude);
        $latTo = deg2rad($dbStoredLatitude);
        $longTo = deg2rad($dbStoredLongitude);
        $latDelta = $latTo - $latFrom;
        $longDelta = $longTo - $longFrom;

        $angle = 2 * asin(sqrt(pow(sin($latDelta / 2), 2) + cos($latFrom) * cos($latTo) * pow(sin($longDelta / 2), 2)));

        return $angle * $earthRadius;
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function getAppLogs(Request $request): JsonResponse
    {
        $requiredParams = ['mobile'];
        if (! $this->validateRequiredParams($request, $requiredParams)) {
            $message = $this->requiredFieldValidation($request, $requiredParams);

            return $this->error(
                $request,
                'Missing Required Parameters',
                $message,
                400
            );
        }

        $logsModel = DB::table('logs')->where(['mobile' => $request->mobile]);

        if ($logsModel->count() > 0) {
            $logs = $logsModel->orderBy('id', 'desc')->get()->toArray();

            return $this->success(request(), ['logs' => $logs], 'Logs fetched successfully.');
        }

        return $this->success(request(), [], 'Logs not available.', 200);
    }

    /**
     * @param Request $request
     *
     * @throws Exception
     * @return JsonResponse
     */
    public function contactSupport(Request $request): JsonResponse
    {
        $requiredParams = ['mobile', 'email', 'message'];
        if (! $this->validateRequiredParams($request, $requiredParams)) {
            $message = $this->requiredFieldValidation($request, $requiredParams);

            return $this->error(
                $request,
                'Missing Required Parameters',
                $message,
                400
            );
        } else {
            $to = 'baldev@ivalt.com'; // this is your Email address
            $subject = 'Support Request';
            $message = 'Mobile : ' . $request->mobile . '<br/> Email : ' . $request->email . '<br/><br/>  wrote the following:<p>' . "\n" . $request->message . '</p>';
            $this->emailService->sendContactUsEmail($to, $subject, $message);
        }

        return $this->success($request, null, 'Email sent successfully.');
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse|void
     */
    public function validateGlobalRESTAuth(Request $request)
    {
        if ($request->has('mobile') && $request->has('auth_token')) {
            $webAuthModel = WebAuth::where(['mobile' => $request->mobile])->first();

            if (is_null($webAuthModel)) {
                return $this->error(
                    $request,
                    'Not Found',
                    'The mobile number provided (' . $request->mobile . ') was not found.',
                    404
                );
            } else {
                WebAuth::where(['mobile' => $request->mobile])->delete();
                if ($webAuthModel->login_status == 0) {
                    return $this->error(
                        $request,
                        'Unprocessable Request',
                        'The mobile number (' . $request->mobile . ') was not in a valid state. Please initiate the Biometric Auth Request again before checking results.',
                        422
                    );
                } else {
                    return $this->success($request, [
                        'for_redirect' => route('api.merchant.redirect', ['auth_token' => $request->auth_token, 'mobile' => $request->mobile]),
                    ], 'Biometric Authentication successfully done.');
                }
            }
        }
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function getUserId(Request $request): JsonResponse
    {
        if (! $request->has('mobile')) {
            return $this->error(
                $request,
                'Missing Required Parameters',
                'The mobile number is required.',
                400
            );
        }

        $userModel = User::where('mobile', $request->mobile)->first();

        if (is_null($userModel)) {
            return $this->error(
                $request,
                'Not Found',
                'The mobile number provided (' . $request->mobile . ') is not registered with iValt.',
                404
            );
        }

        DB::table('user_logs')->insert(['mobile' => $request->mobile, 'type' => 'authenticate']);

        return $this->success($request, ['id' => $userModel->id], 'User ID successfully fetched.');
    }

    /**
     * @param Request $request
     *
     * @return Application|ResponseFactory|JsonResponse|Response
     */
    public function enrolUserForXamUser(Request $request)
    {
        if (! $request->has('mobile')) {
            return $this->error(
                $request,
                'Missing Required Parameters',
                'The mobile number is required.',
                400
            );
        }

        $userModel = User::where('mobile', $request->mobile)->first();

        if (is_null($userModel)) {
            $userModel = User::insertGetId(['mobile' => $request->mobile]);
            DB::table('user_logs')->insert(['mobile' => $request->mobile, 'type' => 'enrollment']);

            return $this->success($request, ['user' => $userModel], 'User successfully enrolled.');
        }

        return $this->error(
            $request,
            'Failed.',
            'User could not be enrolled because the mobile number has already been registered.',
            400
        );
    }

    //Validate Person Auth

    /**
     * @return JsonResponse
     */
    public function getUserLogs(): JsonResponse
    {
        date_default_timezone_set('Asia/Kolkata');

        /* Fetching the data from the database and converting the timezone of the created_at column. */
        $model = DB::table('user_logs')
            ->select('mobile', 'type', DB::raw('CONVERT_TZ(created_at,"+00:00","+05:30") as request_at'))
            ->orderBy('id', 'desc')
            ->get();

        return $this->success(request(), ['logs' => $model], 'User logs successfully fetched.');
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function isUserEnrolled(Request $request): JsonResponse
    {
        if (! $request->has('mobile')) {
            return $this->error(
                $request,
                'Missing Required Parameters',
                'The mobile number is required.',
                400
            );
        }

        $userModel = User::where(['mobile' => $request->mobile, 'is_enrolled' => 1])->first();

        if (is_null($userModel)) {
            return $this->success($request, [
                'is_enrolled'      => 0,
                'enrollmentStatus' => false,
            ], 'User is not enrolled.');
        }

        return $this->success($request, [
            'is_enrolled'      => 1,
            'enrollmentStatus' => true,
        ], 'User is enrolled.');
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function setEnrollment(Request $request): JsonResponse
    {
        if (! $request->has('mobile')) {
            return $this->error(
                $request,
                'Missing Required Parameters',
                'The mobile number is required.',
                400
            );
        }

        $userModel = User::where('mobile', $request->mobile);
        $blockChainResponse = null;

        if (is_null($userModel->first())) {
            return $this->error(
                $request,
                'Not Found',
                'The mobile number provided (' . $request->mobile . ') is not registered with iValt.',
                404
            );
        }

        $userModel->update(['is_enrolled' => 1]);
        // $blockChainResponse = BlockchainController::updateUserSetActive($request);

        return $this->success($request, [
            'is_enrolled'        => $userModel->first()->is_enrolled,
            'blockChainResponse' => $blockChainResponse,
        ], 'User is enrolled.');
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function validatePersonGlobalAuth(Request $request): JsonResponse
    {
        if (! $request->has('mobile')) {
            return $this->error(
                $request,
                'Missing Required Parameters',
                'The mobile number is required.',
                400
            );
        }

        $userModel = WebAuth::where(['mobile' => $request->mobile])->whereRaw('TIME_TO_SEC(TIMEDIFF(now(), created_at)) < 30')->first();

        if (is_null($userModel)) {
            return $this->error(
                $request,
                'Not Found',
                'The mobile number provided (' . $request->mobile . ') was not found.',
                404
            );
        } else {
            if ($userModel->login_status == 0) {
                WebAuth::where(['mobile' => $request->mobile])->delete();

                return $this->error(
                    $request,
                    'Unprocessable Request',
                    'The mobile number (' . $request->mobile . ') was not in a valid state. Please initiate the Biometric Auth Request again before checking results.',
                    422
                );
            } else {
                $model = WebAuth::where(['mobile' => $request->mobile])->first();

                $userModelDetails = User::where(['mobile' => $request->mobile])->first();

                if ($userModelDetails != null) {
                    $user = User::find($userModelDetails->id);
                }

                $ch = curl_init('https://api.opencagedata.com/geocode/v1/json?q=' . $model->latitude . ',' . $model->longitude . '&key=1da5ec3afbc048eeb9e49c9d4aea012c');

                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

                $result = curl_exec($ch);

                curl_close($ch);

                $records = json_decode($result, true);
                $model = WebAuth::where(['mobile' => $request->mobile])->delete();

                if (isset($records['results'][0]['formatted'])) {
                    return $this->success($request, [
                        'id'           => $userModel->id,
                        'name'         => $userModelDetails->name,
                        'imei'         => $userModelDetails->imei,
                        'address'      => $records['results'][0]['formatted'],
                        'latitude'     => $model->latitude,
                        'longitude'    => $model->longitude,
                        'login_status' => $userModel->login_status,
                    ], 'User is authenticated.');
                } else {
                    return $this->success($request, [
                        'id'   => $userModel->id,
                        'name' => $userModelDetails->name,
                        'imei' => $userModelDetails->imei,
                    ], 'User is authenticated.');
                }
            }
        }
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function wpRegisterConfirmationWithSupplier(Request $request): JsonResponse
    {
        $requiredParams = ['mobile', 'domain', 'token', 'supplier', 'supplier_id'];
        if (! $this->validateRequiredParams($request, $requiredParams)) {
            $message = $this->requiredFieldValidation($request, $requiredParams);

            return $this->error(
                $request,
                'Missing Required Parameters',
                $message,
                400
            );
        }
        $update = WpUser::where([
            'mobile'      => $request->mobile,
            'website'     => $request->domain,
            'supplier_id' => $request->supplier_id,
            'supplier'    => $request->supplier,
            'user_token'  => $request->token,
        ])
            ->update(['confirmed' => 1]);

        if ($update) {
            return $this->success($request, [], 'Authentication success.');
        }

        return $this->error(
            $request,
            'Not Found',
            'The mobile number provided (' . $request->mobile . ') is not registered with iValt.',
            404
        );
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function wpRegisteredUserDetails(Request $request): JsonResponse
    {
        if (! $request->has('imei')) {
            return $this->error(
                $request,
                'Missing Required Parameters',
                'The IMEI is required.',
                400
            );
        }

        /* Removing all the spaces from the imei number. */
        $imei = preg_replace('/\s+/', '', $request->imei);
        $ivaltUser = UserDeviceTokens::where('imei', $imei)->get();

        if ($ivaltUser->count() > 0) {
            $user = User::where('id', '=', $ivaltUser->first()->user_id)->get();

            return $this->success($request, ['userDetails' => $user], 'Authentication successful.');
        }

        return $this->error(
            $request,
            'Not Found',
            'The IMEI provided (' . $request->imei . ') is not registered with iValt.',
            404
        );
    }

    /**
     * @param Request $request
     *
     * @throws Exception
     * @return JsonResponse|RedirectResponse
     */
    public function validateEmail(Request $request)
    {
        $userAgent = $request->header('User-Agent');
        $returnJson = (str_contains($userAgent, 'Postman') || str_contains($userAgent, 'Insomnia') || $request->ajax() || $request->wantsJson() || str_contains($userAgent, 'Burp'));
        $requiredParams = ['token', 'email'];

        if (! $this->validateRequiredParams($request, $requiredParams)) {
            return $this->error(
                $request,
                'Missing Required Parameters',
                $this->requiredFieldValidation($request, $requiredParams),
                400
            );
        }

        $userModel = User::where(['email' => $request->email, 'email_verification_token' => $request->token])->first();

        if (is_null($userModel)) {
            if ($returnJson) {
                return $this->error($request, 'Not Found', 'The email provided (' . $request->email . ') is not registered with iVALT.', 404);
            }

            return redirect()->away(env('MAIL_VERIFICATION_FAILED_CALLBACK_URL'));
        } else {
            $this->emailService->sendRegistrationSuccessEmail($userModel->email, $userModel->name);

            $userModel->email_verification_token = null;
            $userModel->is_email_verified = 1;
            $userModel->save();
            if ($returnJson) {
                return $this->success($request, [], 'Email verified successfully.');
            }

            return redirect()->away(env('MAIL_VERIFICATION_SUCCESS_CALLBACK_URL'));
        }
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function isEmailVerified(Request $request)
    {
        $requiredParams = ['country_code', 'mobile', 'platform', 'email'];
        if (! $this->validateRequiredParams($request, $requiredParams)) {
            $message = $this->requiredFieldValidation($request, $requiredParams);

            return $this->error(
                $request,
                'Missing Required Parameters',
                $message,
                400
            );
        }

        if (! in_array($request->platform, ['android', 'iOS'])) {
            return $this->error(
                $request,
                'Bad Request',
                'Provided platform is not valid.',
                400
            );
        }

        $platform = ($request->platform == 'android') ? 'android' : 'ios';

        $userModel = User::where([
            'country_code' => $request->country_code,
            'mobile'       => $request->mobile,
            'platform'     => $platform,
            'email'        => $request->email,
        ])->first();

        if (is_null($userModel)) {
            return $this->error(
                $request,
                'Not Found',
                'The email provided (' . $request->email . ') was not found.',
                404
            );
        } else {
            if ($userModel->is_email_verified == 1) {
                return $this->success($request, $userModel->toArray(), 'Email has been verified.');
            } else {
                return $this->error(
                    $request,
                    'Not Found',
                    'The email provided (' . $request->email . ') has not been verified.',
                    404
                );
            }
        }
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function userAssignOrg(Request $request)
    {
        $requiredParams = ['country_code', 'mobile', 'organization_code'];
        if (! $this->validateRequiredParams($request, $requiredParams)) {
            $message = $this->requiredFieldValidation($request, $requiredParams);

            return $this->error(
                $request,
                'Missing Required Parameters',
                $message,
                400
            );
        }

        $orgModel = Organization::where(['organization_code' => $request->organization_code])->first();

        if (is_null($orgModel)) {
            return $this->error(
                $request,
                'Not Found',
                'The organization code provided (' . $request->organization_code . ') is not registered with iVALT.',
                404
            );
        }

        $userModel = User::where(['country_code' => $request->country_code, 'mobile' => $request->mobile])->first();

        if (is_null($userModel)) {
            return $this->error(
                $request,
                'Not Found',
                'The mobile number provided (' . $request->country_code . $request->mobile . ') is not registered with iVALT.',
                404
            );
        }

        $orgModel->users()->detach($userModel->id);
        $orgModel->pendingUsers()->attach($userModel->id);

        return $this->success(request(), ['user_id' => $userModel->id], 'User status updated successfully.');
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function userCheckOrgAssignment(Request $request)
    {
        $requiredParams = ['country_code', 'mobile'];
        if (! $this->validateRequiredParams($request, $requiredParams)) {
            $message = $this->requiredFieldValidation($request, $requiredParams);

            return $this->error(
                $request,
                'Missing Required Parameters',
                $message,
                400
            );
        }

        $userModel = User::where(['country_code' => $request->country_code, 'mobile' => $request->mobile])->first();

        if (is_null($userModel)) {
            return $this->error(
                $request,
                'Not Found',
                'The mobile number provided (' . $request->country_code . ' ' . $request->mobile . ') is not registered with iVALT.',
                404
            );
        }

        $orgUserPoolModel = OrganizationUserPool::firstWhere(['user_id' => $userModel->id]);
        $orgUserModel = OrganizationUser::firstWhere(['user_id' => $userModel->id]);

        if ($orgUserPoolModel || $orgUserModel) {
            return $this->success($request, null, 'User assigned to organization');
        } else {
            return $this->error(
                $request,
                'Not Found',
                'User not assigned to organization',
                404
            );
        }
    }

    // org timeslots CRUD

    /**
     * @param Organization $org_id
     *
     * @return JsonResponse
     */
    public function orgTimeslotsList(Organization $org_id)
    {
        if (is_null($org_id)) {
            return $this->error(request(), 'Not Found', 'Organization not found', 404);
        }
        $org_timeslots = TimeSlot::where('org_id', $org_id->id)->latest()->get();

        return $this->success(request(), $org_timeslots, 'Org timeslots list.');
    }

    public function addOrgTimeslots(Organization $org_id, Request $request)
    {
        if (is_null($org_id)) {
            return $this->error(request(), 'Not Found', 'Organization not found', 404);
        }

        $requiredParams = ['timezone', 'start_time', 'end_time', 'status'];
        if (! $this->validateRequiredParams($request, $requiredParams)) {
            $message = $this->requiredFieldValidation($request, $requiredParams);

            return $this->error(
                $request,
                'Missing Required Parameters',
                $message,
                400
            );
        }

        $timeslots = TimeSlot::create([
            'org_id'     => $org_id->id,
            'timezone'   => $request->timezone,
            'start_time' => $request->start_time,
            'end_time'   => $request->end_time,
            'status'     => $request->status,
        ]);

        if ($timeslots) {
            return $this->success($request, $timeslots, 'Time Slot added to organization');
        } else {
            return $this->error(
                $request,
                'Unprocessable Request',
                'Time Slot did not add to organization',
                404
            );
        }
    }

    public function updateOrgTimeslots(TimeSlot $timeslot, Request $request)
    {
        if (is_null($timeslot)) {
            return $this->error(request(), 'Not Found', 'TimeSlot not found', 404);
        }

        $requiredParams = ['timezone', 'start_time', 'end_time', 'status'];
        if (! $this->validateRequiredParams($request, $requiredParams)) {
            $message = $this->requiredFieldValidation($request, $requiredParams);

            return $this->error(
                $request,
                'Missing Required Parameters',
                $message,
                400
            );
        }

        $timeslots = $timeslot->update([
            'timezone'   => $request->timezone,
            'start_time' => $request->start_time,
            'end_time'   => $request->end_time,
            'status'     => $request->status,
        ]);

        if ($timeslots) {
            return $this->success($request, TimeSlot::find($timeslot->id), 'Time Slot has been updated');
        } else {
            return $this->error(
                $request,
                'Unprocessable Request',
                'Time Slot did not update',
                404
            );
        }
    }

    public function deleteOrgTimeslots(TimeSlot $timeslot, Request $request)
    {
        if (is_null($timeslot)) {
            return $this->error(request(), 'Not Found', 'TimeSlot not found', 404);
        }

        $timeslots = $timeslot->delete();

        if ($timeslots) {
            return $this->success($request, [], 'Time Slot has been deleted');
        } else {
            return $this->error(
                $request,
                'Unprocessable Request',
                'Time Slot did not delete yet',
                404
            );
        }
    }

    public function userTimeslotsList(User $user_id)
    {
        if (is_null($user_id)) {
            return $this->error(request(), 'Not Found', 'User not found', 404);
        }

        $user_timeslots = $user_id->orgTimeSlots;
        // dd($user_timeslots);

        return $this->success(request(), $user_timeslots, 'User timeslots list.');
    }

    public function userTimeslotsListUpdate(User $user_id, Request $request)
    {
        if (is_null($user_id)) {
            return $this->error($request, 'Not Found', 'User not found', 404);
        }

        $requiredParams = ['timeslot_ids'];
        if (! $this->validateRequiredParams($request, $requiredParams)) {
            $message = $this->requiredFieldValidation($request, $requiredParams);

            return $this->error(
                $request,
                'Missing Required Parameters',
                $message,
                400
            );
        }

        $user_id->orgTimeSlots()->detach();
        $user_id->orgTimeSlots()->attach($request->timeslot_ids);

        $user_timeslots = $user_id->orgTimeSlots;

        return $this->success($request, $user_timeslots, 'Org timeslots list.');
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function sendAppAuthNotification(Request $request): JsonResponse
    {
        $requiredParams = ['request_to_mobile', 'request_from_mobile'];

        if (! $this->validateRequiredParams($request, $requiredParams)) {
            $message = $this->requiredFieldValidation($request, $requiredParams);

            return $this->error(
                $request,
                'Missing Required Parameters',
                $message,
                400
            );
        } else {
            $userModel = User::where(['mobile_with_country_code' => $request->request_to_mobile])->first();

            if (! is_null($userModel)) {
                $notificationController = new NotificationController;

                return $notificationController->sendNotificationForMobileAuth(
                    $userModel,
                    'iVALT',
                    $request->request_to_mobile,
                    $request->request_from_mobile
                );
            } else {
                return $this->error(
                    $request,
                    'Not Found',
                    'The mobile number provided (' . $request->request_to_mobile . ') was not found.',
                    404
                );
            }
        }
    }

    /**
     * Generates an authentication token for the given request.
     *
     * @param Request $request The incoming request.
     *
     * @throws AuthenticationException If the required parameters are missing.
     * @return JsonResponse            The authentication token.
     */
    public function generateAuthToken(Request $request): JsonResponse
    {
        $requiredParams = ['client_id', 'client_secret'];

        if (! $this->validateRequiredParams($request, $requiredParams)) {
            $message = $this->requiredFieldValidation($request, $requiredParams);

            return $this->error(
                $request,
                'Missing Required Parameters',
                $message,
                400
            );
        }

        // Find the authentication model for the client
        $authModel = PersonalAccessClient::where([
            'client_id'     => $request->client_id,
            'client_secret' => $request->client_secret,
        ])->first();

        // Check if the authentication model was found
        if (! $authModel) {
            // Return an error response if the client credentials are invalid
            return $this->error(
                $request,
                'Not Found',
                'Invalid client credentials',
                404
            );
        }

        // Check if the user already has a personal access token
        if (Auth::guard('api')->loginUsingId($authModel->id)) {
            // Return an error response if the user already has a personal access token
            $authUser = Auth::guard('api')->user();

            // Revoke a specific token...
            //            $authUser->tokens()->delete();

            $authToken = $authUser->createToken('api-auth-' . $authModel->id)->plainTextToken;

            // Return the authentication token
            return $this->success(
                $request,
                ['token' => $authToken],
                'Authentication token successfully generated.'
            );
        }
    }

    /**
     * @param Request $request
     * @throws Exception
     * @return JsonResponse
     */
    public function resendEmailVerification(Request $request): JsonResponse
    {
        $requiredParams = ['mobile', 'email', 'country_code'];
        if (! $this->validateRequiredParams($request, $requiredParams)) {
            $validationMessage = $this->requiredFieldValidation($request, $requiredParams);

            return $this->error($request, 'Missing Required Parameters', $validationMessage, 400);
        }

        $userCriteria = [
            'country_code' => $request->country_code,
            'mobile'       => $request->mobile,
            'email'        => $request->email,
        ];

        $user = User::where($userCriteria)->first();

        if (! $user) {
            return $this->error($request, 'Not Found', 'The mobile number provided (' . $request->mobile . ') was not found.', 404);
        }

        $emailVerificationToken = $this->randomString(36);
        $user->update(['email_verification_token' => $emailVerificationToken]);

        $maskedMobile = $this->hideMobileNumber($request->mobile);

        return $this->emailService->sendMobileAppVerificationEmail('iVALT', $request->email, $maskedMobile, $emailVerificationToken);
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function deleteProfile(Request $request): JsonResponse
    {
        $requiredParams = ['country_code', 'mobile'];

        if (! $this->validateRequiredParams($request, $requiredParams)) {
            $message = $this->requiredFieldValidation($request, $requiredParams);

            return $this->error(
                $request,
                'Missing Required Parameters',
                $message,
                400
            );
        }

        $where = ['country_code' => $request->country_code, 'mobile' => $request->mobile];

        if (! (User::where($where)->exists())) {
            return $this->error(
                $request,
                'Not Found',
                'The mobile number provided (' . $request->mobile . ') was not found.',
                404
            );
        }

        User::where($where)->delete();

        return $this->success(
            $request,
            null,
            'Profile successfully deleted.'
        );
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function updateProfile(Request $request): JsonResponse
    {
        $requiredParams = ['country_code', 'mobile', 'name'];

        if (! $this->validateRequiredParams($request, $requiredParams)) {
            $message = $this->requiredFieldValidation($request, $requiredParams);

            return $this->error(
                $request,
                'Missing Required Parameters',
                $message,
                400
            );
        }
        if (strlen($request->name) > 20) {
            return $this->error(
                $request,
                'Not Found',
                'Name should not be greater than 20 characters.',
                403
            );
        }

        $where = ['country_code' => $request->country_code, 'mobile' => $request->mobile];

        if (! (User::where($where)->exists())) {
            return $this->error(
                $request,
                'Not Found',
                'The mobile number provided (' . $request->mobile . ') was not found.',
                404
            );
        }

        User::where($where)->update(['name' => $request->name]);

        return $this->success(
            $request,
            null,
            'Profile successfully updated.'
        );
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function validateGlobalAuthForAdmin(Request $request): JsonResponse
    {
        $requiredParams = ['mobile'];
        /* Checking if the request has a mobile number. If not, it will return an error. */
        if (! $request->has($requiredParams)) {
            $message = $this->requiredFieldValidation($request, $requiredParams);

            return $this->error(
                $request,
                'Missing Required Parameters',
                $message,
                400
            );
        }

        $mobileNumberWithCountryCode = $request->mobile;

        // get the user
        $userModel = User::where(['mobile_with_country_code' => $mobileNumberWithCountryCode])->get();

        if ($userModel->count() == 0) {
            // return an error to the user
            return $this->error(
                $request,
                'Not Found',
                'The mobile number provided (' . $mobileNumberWithCountryCode . ') was not found.',
                404
            );
        }

        // find the user in the web_auth table in the last 120 seconds
        $webAuthModel = WebAuth::where(['mobile_with_country_code' => $mobileNumberWithCountryCode])->first();

        if (is_null($webAuthModel)) {
            return $this->error(
                $request,
                'Unprocessable Request',
                'The mobile number (' . $mobileNumberWithCountryCode . ') was not in a valid state. Please initiate the Biometric Auth Request again before checking results.',
                422
            );
        }

        // check if the user's status is valid.
        if ($webAuthModel->login_status == 0) {
            return $this->error(
                $request,
                'Unprocessable Request',
                'The mobile number (' . $mobileNumberWithCountryCode . ') was not in a valid state. Please initiate the Biometric Auth Request again before checking results.',
                422
            );
        }

        /* Fetching the location of the user from the database and then using the latitude and longitude to get the address of the user. */
        $records = $this->fetchLocation($webAuthModel->latitude, $webAuthModel->longitude);

        /* Check to see if location data is present */
        $responseData = [
            'id'            => $webAuthModel->id,
            'name'          => $userModel->first()->name,
            'email'         => $userModel->first()->email,
            'latitude'      => $webAuthModel->latitude,
            'longitude'     => $webAuthModel->longitude,
            'imei'          => $userModel->first()->imei,
            'user'          => $userModel->first(),
            'is_admin'      => $userModel->first()->is_admin,
            'organizations' => $userModel->first()->organizations,
        ];

        if (isset($records['results'][0]['formatted'])) {
            $responseData['address'] = $records['results'][0]['formatted'];
        }

        /*
            Delete all records matching this mobile number just in case the number IS in the database but was added over 120 seconds ago
            OR User Authenticated Successfully
        */
        $this->deleteWebAuthUser($mobileNumberWithCountryCode);

        /* Saving the user's mobile number and the action "Log In with Face Authentication" to the database. */
        saveAppLog($userModel->first()->mobile, 'Log In with Face Authentication for admin.');

        return $this->success($request, $responseData, 'Biometric Authentication successfully done.');
    }

    public function getUser(): JsonResponse
    {
        return $this->success(request(), User::get(), 'User fetched successfully');
    }
}