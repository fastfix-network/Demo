<?php

namespace App\Http\Controllers;

use App\Models\WebAuth;
use App\Models\WebCardUser;
use App\Models\WebCardUserDeviceTokens;
use App\Services\EmailService;
use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class WebCardApiController extends ApiResponseController
{
    protected EmailService $emailService;

    /**
     * Constructor for the class.
     *
     * @param EmailService $emailService The SMS service to be injected
     */
    public function __construct(EmailService $emailService)
    {
        $this->emailService = $emailService;
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function webCardRefreshToken(Request $request): JsonResponse
    {
        $requiredParams = ['mobile', 'token', 'imei'];
        if (! $request->has($requiredParams)) {
            $message = $this->requiredFieldValidation($request, $requiredParams);

            return $this->error($request,
                'Missing Required Parameters',
                $message,
                400);
        } else {
            $webCardUserModel = WebCardUser::where('mobile', $request->mobile)->first();

            if ($webCardUserModel != null) {
                WebCardUser::where('mobile', $request->mobile)->update(['device_token' => $request->token, 'imei' => $request->imei]);
                WebCardUserDeviceTokens::where('user_id', $webCardUserModel->id)->update(['device_token' => $request->token]);

                return $this->success($request, null, 'Token updated successfully!');
            } else {
                return $this->error($request,
                    'Not Found',
                    'The mobile number provided ('.$request->mobile.') is not registered with iValt.',
                    404);
            }
        }
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function sendGlobalNotificationWebCard(Request $request): JsonResponse
    {
        $requestFrom = $request->has('requestFrom') ? $request->requestFrom : 'WebId';
        if (! $request->has('mobile')) {
            return $this->error($request,
                'Bad Request',
                'Please provide a mobile number.',
                400);
        } else {
            $userModel = WebCardUser::firstWhere(['mobile_with_country_code' => $request->mobile]);
            if ($userModel != null) {
                $notificationController = new NotificationController;

                /* This is sending a notification to the user's device. */
                $fcmResponse = $notificationController->sendNotificationForAuth($userModel, 'Webcard', $request->mobile, $requestFrom);

                /* Logging the response from FCM server. */
                Log::channel('webCardFcmLogs')->info(json_encode(['mobile' => $request->mobile, 'response' => $fcmResponse], true));

                return $this->success($request, null, 'Biometric Auth Request successfully sent.');
            } else {
                return $this->error($request,
                    'Not Found',
                    'The mobile number provided ('.$request->mobile.') was not found.',
                    404);
            }
        }
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function webCardSetEnrollment(Request $request): JsonResponse
    {
        if (! $request->has('supplier_id')) {
            $message = $this->requiredFieldValidation($request, ['supplier_id']);

            return $this->error($request,
                'Missing Required Parameters',
                $message,
                400);
        }

        $model = WebCardUser::where('supplier_id', $request->supplier_id)->first();

        if ($model == null) {
            return $this->error($request,
                'Not Found',
                'The supplier id provided ('.$request->supplier_id.') is not registered with iValt.',
                404);
        }

        WebCardUser::where('supplier_id', $request->supplier_id)->update(['is_enrolled' => 1]);

        return $this->success($request, null, 'User enrolled successfully.');
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function webCardRegisteredUserDetails(Request $request): JsonResponse
    {
        if (! $request->has('imei')) {
            $message = $this->requiredFieldValidation($request, ['imei']);

            return $this->error($request,
                'Missing Required Parameters',
                $message,
                400);
        } else {
            /* Removing all the spaces from the imei number. */
            $imei = preg_replace('/\s+/', '', $request->imei);

            $webCardUserModel = WebCardUser::where('imei', $imei)->get();
            $webCardUserDetails = $webCardUserModel->where('is_enrolled', '=', 1)->first();

            if ($webCardUserDetails != null) {
                return $this->success($request, ['user' => $webCardUserDetails], 'User available.');
            } else {
                return $this->error($request,
                    'Not Found',
                    'The imei provided ('.$request->imei.') is not valid.',
                    404);
            }
        }
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function checkWebCardEnrollment(Request $request): JsonResponse
    {
        if (! $request->has('supplier_id')) {
            $message = $this->requiredFieldValidation($request, ['supplier_id']);

            return $this->error($request,
                'Missing Required Parameters',
                $message,
                400);
        } else {
            $webCardUserModel = WebCardUser::where('supplier_id', $request->supplier_id)->first();

            if (is_null($webCardUserModel)) {
                return $this->error($request,
                    'Not Found',
                    'The supplier id provided ('.$request->supplier_id.') is not valid.',
                    404);
            }

            return $this->success($request, [
                'enrollmentStatus' => $webCardUserModel->is_enrolled,
                'is_enrolled'      => $webCardUserModel->is_enrolled,
            ], 'User available.');
        }
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse|void
     */
    public function removeWebCardUser(Request $request)
    {
        if (! $request->has('supplier_id')) {
            $message = $this->requiredFieldValidation($request, ['supplier_id']);

            return $this->error($request,
                'Missing Required Parameters',
                $message,
                400);
        }

        $webCardUserModel = WebCardUser::where('supplier_id', $request->supplier_id)->first();

        if (is_null($webCardUserModel)) {
            return $this->error($request,
                'Not Found',
                'The supplier id provided ('.$request->supplier_id.') is not valid.',
                404);
        }

        /* Deleting the user and the user's device tokens. */
        $webCardUserDevicesModel = WebCardUserDeviceTokens::where('user_id', $webCardUserModel->id)->delete();

        /* Deleting the user and all the devices associated with the user. */
        if ($webCardUserDevicesModel) {
            if ($webCardUserModel->delete()) {
                return $this->success($request, null, 'User deleted successfully.');
            }
        }
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function webCardIsUserExist(Request $request): JsonResponse
    {
        $requiredParams = ['supplier_id', 'imei'];
        if (! $request->has($requiredParams)) {
            $message = $this->requiredFieldValidation($request, $requiredParams);

            return $this->error($request,
                'Missing Required Parameters',
                $message,
                400);
        } else {
            /* Removing all the spaces from the imei and supplier_id */
            $imei = preg_replace('/\s+/', '', $request->imei);
            $supplierId = preg_replace('/\s+/', '', $request->supplier_id);

            $webCardUser = WebCardUser::where(['imei' => $imei, 'supplier_id' => $supplierId])->get();
            $webCardUser = $webCardUser->where('is_enrolled', '=', 1)->first();

            if ($webCardUser != null) {
                return $this->success($request, ['user' => $webCardUser], 'User available.');
            } else {
                return $this->error($request,
                    'Not Found',
                    'The supplier id provided ('.$supplierId.') is not registered with iValt.',
                    404);
            }
        }
    }

    /**
     * @param Request $request
     *
     * @throws Exception
     *
     * @return JsonResponse
     */
    public function storeWebCardUser(Request $request)
    {
        $requiredParams = ['country_code', 'mobile', 'device_token', 'platform', 'email', 'imei', 'supplier', 'supplier_id', 'user_code'];

        if (! $request->has($requiredParams)) {
            $message = $this->requiredFieldValidation($request, $requiredParams);

            return $this->error($request,
                'Missing Required Parameters',
                $message,
                400);
        } else {
            if (! $this->isWebCardOtpValid($request)) {
                return $this->error($request,
                    'Invalid OTP',
                    'The OTP provided is not valid.',
                    400);
            }

            $platform = 'ios';

            if ($request->has('platform') && $request->platform == 'android') {
                $platform = 'android';
            }

            $model = DB::table('webcard_users');
            $data = $model->where(['mobile' => $request->mobile])->first();

            if ($data == null) {
                $insertArray = [
                    'is_enrolled'              => 0,
                    'country_code'             => $request->country_code,
                    'mobile'                   => $request->mobile,
                    'mobile_with_country_code' => $request->country_code.$request->mobile,
                    'device_token'             => $request->device_token,
                    'platform'                 => $platform,
                ];
                $insertArray = $this->getUserNameAndImeiIfExist($request, $insertArray);

                if ($request->has('email')) {
                    $insertArray['email'] = $request->email;

                    /* Sending an email to the user who just registered. */
                    $this->emailService->sendWebCardRegistrationSuccessEmail($request->email, $request->name);
                }

                $model = WebCardUser::insertGetId($insertArray);
                $lastInserted = WebCardUser::find($model);

                if ($model > 0) {
                    $userDeviceTokenModel = new WebCardUserDeviceTokens;
                    $userDeviceTokenModel->create([
                        'user_id'      => $model,
                        'device_token' => $request->device_token,
                        'imei'         => $request->imei,
                        'platform'     => $platform, ]);
                }

                return $this->success($request, [
                    'id'               => $model,
                    'mobile'           => $request->mobile,
                    'enrollmentStatus' => $lastInserted->is_enrolled,
                    'is_enrolled'      => $lastInserted->is_enrolled,
                ], 'User registered successfully.');
            } else {
                $userDeviceTokenModel = new WebCardUserDeviceTokens;
                $isExist = $userDeviceTokenModel->where(['user_id' => $data->id, 'imei' => $request->imei])->get();

                if ($isExist->count() == 0) {
                    $userDeviceTokenModel->create([
                        'user_id'      => $data->id,
                        'device_token' => $request->device_token,
                        'imei'         => $request->imei,
                        'platform'     => $platform, ]);
                }

                if ($request->has('email')) {
                    $insertArray = [
                        'country_code'             => $request->country_code,
                        'mobile'                   => $request->mobile,
                        'mobile_with_country_code' => $request->country_code.$request->mobile,
                        'email'                    => $request->email,
                        'is_enrolled'              => 0,
                        'device_token'             => $request->device_token,
                        'platform'                 => $platform,
                    ];

                    $insertArray = $this->getUserNameAndImeiIfExist($request, $insertArray);

                    $model->where([
                        'country_code' => $request->country_code,
                        'mobile'       => $request->mobile,
                    ])->update($insertArray);

                    /* Sending an email to the user who just registered. */
                    $this->emailService->sendWebCardRegistrationSuccessEmail($request->email, $request->name);
                }

                $userDeviceTokenModel->where(['user_id' => $data->id, 'imei' => $request->imei])->update(['device_token' => $request->device_token]);
                $data = $model->where(['mobile' => $request->mobile])->first();

                return $this->success($request, [
                    'id'               => $data->id,
                    'country_code'     => $request->country_code,
                    'mobile'           => $request->mobile,
                    'enrollmentStatus' => $data->is_enrolled,
                    'is_enrolled'      => $data->is_enrolled,
                ], 'User registered successfully.');
            }
        }
    }

    /**
     * It checks if the OTP sent to the user's mobile number is valid or not
     *
     * @param request The request object
     *
     * @return bool A boolean value.
     */
    public function isWebCardOtpValid($request): bool
    {
        $smsCode = $request->user_code;
        $countryCode = $request->country_code;
        $model = DB::table('register_otps');
        $results = $model->where(['mobile' => $countryCode.$request->mobile, 'otp' => $smsCode])->get();

        if ($results->count() > 0) {
            $model->where(['mobile' => $countryCode.$request->mobile, 'otp' => $smsCode])->delete();

            return true;
        } else {
            return false;
        }
    }

    /**
     * @param Request $request
     * @param array   $insertArray
     *
     * @return array
     */
    protected function getUserNameAndImeiIfExist(Request $request, array $insertArray): array
    {
        if ($request->has(['name', 'imei'])) {
            $insertArray['name'] = $request->name;
            $insertArray['imei'] = $request->imei;
        }

        if ($request->has(['supplier_id', 'supplier'])) {
            $insertArray['supplier_id'] = $request->supplier_id;
            $insertArray['supplier'] = $request->supplier;
        }

        return $insertArray;
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function globalAuthenticate(Request $request): JsonResponse
    {
        $requiredParams = ['mobile', 'status', 'country_code'];
        if (! $request->has($requiredParams)) {
            $message = $this->requiredFieldValidation($request, $requiredParams);

            return $this->error($request,
                'Missing Required Parameters',
                $message,
                400);
        } else {
            $webAuthModel = DB::table('web_auth');

            if ($request->status === true || $request->status === 'true' || $request->status === '1' || $request->status === 1) {
                $insertArray = [
                    'country_code'             => $request->country_code,
                    'mobile'                   => $request->mobile,
                    'mobile_with_country_code' => $request->country_code.$request->mobile,
                    'login_status'             => 1,
                ];

                if ($request->has(['latitude', 'longitude', 'address'])) {
                    $insertArray['latitude'] = $request->latitude;
                    $insertArray['longitude'] = $request->longitude;
                    $insertArray['address'] = $request->address;
                }

                $webAuthModel->insert($insertArray);

                return $this->success($request, null, 'Biometric Authentication Successful.');
            } else {
                $webAuthModel->insert([
                    'mobile'                   => $request->mobile,
                    'country_code'             => $request->country_code,
                    'mobile_with_country_code' => $request->country_code.$request->mobile,
                    'login_status'             => 0,
                ]);

                return $this->error($request,
                    'Authentication Failed',
                    'User not authenticated yet.',
                    400);
            }
        }
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function validateGlobalAuth(Request $request): JsonResponse
    {
        /* Checking if the request has a mobile number. If not, it will return an error. */
        if (! $request->has('mobile')) {
            return $this->error($request,
                'Bad Request',
                'Please provide a mobile number.',
                400);
        }

        $mobileNumber = $request->mobile;

        // find the user in the web_auth table in the last 120 seconds
        $webAuthModel = WebAuth::where(['mobile' => $mobileNumber])
            ->whereRaw('TIME_TO_SEC(TIMEDIFF(now(), created_at)) < 120')
            ->first();

        // if the login request was not found, stop now
        if (is_null($webAuthModel)) {
            // delete any records matching this mobile number just in case the number IS in the database but was added over 120 seconds ago
            $this->deleteWebAuthUser($mobileNumber);

            // return an error to the user
            return $this->error($request,
                'Not Found',
                'The mobile number provided ('.$mobileNumber.') was not found.',
                404);
        }

        // check if the user's status is valid.
        if ($webAuthModel->login_status == 0) {
            // delete the record so that it will be valid next time the user tries to request & auth
            $this->deleteWebAuthUser($mobileNumber);

            return $this->error(
                $request,
                'Unprocessable Request',
                'The mobile number ('.$mobileNumber.') was not in a valid state. Please initiate the Biometric Auth Request again before checking results.',
                422);
        }

        // get the user
        $userModel = $this->getUserModel($mobileNumber);
        if (is_null($userModel)) {
            // return an error to the user
            return $this->error(
                $request,
                'Not Found',
                'The mobile number provided ('.$mobileNumber.') was not found.',
                404);
        }

        /* Fetching the location of the user from the database and then using the latitude and longitude to get the address of the user. */
        $records = $this->fetchLocation($webAuthModel->latitude, $webAuthModel->longitude);

        /* Check to see if location data is present */
        if (isset($records['results'][0]['formatted'])) {
            $data = ['id' => $webAuthModel->id, 'name' => $userModel->name, 'imei' => $userModel->imei, 'mobile' => $userModel->mobile, 'email' => $userModel->email, 'address' => $records['results'][0]['formatted']];
        } else {
            $data = ['id' => $webAuthModel->id, 'name' => $userModel->name, 'imei' => $userModel->imei, 'mobile' => $userModel->mobile, 'email' => $userModel->email];
        }

        /* Deleting all the records from the web_auth table for this mobile */
        $this->deleteWebAuthUser($mobileNumber);

        /* Saving the user's mobile number and the action "Log In with Face Authentication" to the database. */
        saveAppLog($mobileNumber, 'Log In with Face Authentication');

        return $this->success($request, $data, 'Biometric Authentication successfully done.');
    }

    /**
     * @param $mobileNumber
     *
     * @return mixed
     */
    public function deleteWebAuthUser($mobileNumber)
    {
        return WebAuth::where(['mobile' => $mobileNumber])->delete();
    }

    /**
     * @param $mobileNumber
     *
     * @return mixed
     */
    private function getUserModel($mobileNumber)
    {
        // first check the webcard_users table.
        $userModel = WebCardUser::where(['mobile' => $mobileNumber])->first();

        // if not in webcard_users table, check the users table.  This means that the user is an iValt user, not webcard
        if (is_null($userModel)) {
            $userModel = DB::table('users')->where(['mobile' => $mobileNumber])->first();
        }

        return $userModel;
    }

    /**
     * @param $latitude
     * @param $longitude
     *
     * @return mixed
     */
    public function fetchLocation($latitude, $longitude)
    {
        /* The bellow code is using the OpenCage API to get the location of the user. */
        $ch = curl_init('https://api.opencagedata.com/geocode/v1/json?q='.$latitude.','.$longitude.'&key=1da5ec3afbc048eeb9e49c9d4aea012c');
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $result = curl_exec($ch);

        curl_close($ch);

        return json_decode($result, true);
    }
}
