<?php

namespace App\Http\Controllers;

use App\Services\AwsSecretsManagerService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ApiResponseController extends Controller
{
    /**
     * @param Request $request
     * @param array   $requiredParams
     *
     * @return bool
     */
    public function validateRequiredParams(Request $request, array $requiredParams): bool
    {
        foreach ($requiredParams as $param) {
            // Check if the parameter exists in the request and is a string
            if ((! $request->has($param))) {
                return false; // Return false if any required parameter is missing or invalid
            }

            if (is_array($request->input($param))) {
                if (count($request->input($param)) === 0) {
                    return false;
                }
            }

            if (($request->input($param) === '[]')) {
                return false;
            }

            if (is_string($request->input($param)) && trim($request->input($param)) === '') {
                return false;
            }
        }

        return true; // Return true if all required parameters are valid
    }

    /**
     * Gets the FCM API Key from the AWS Secrets Manager.
     *
     * @return string The FCM API Key.
     */
    protected function getFCMApiKey(): string
    {
        $secretsManager = new AwsSecretsManagerService;
        $secret = $secretsManager->getCredentials('GOOGLE_FCM');

        return $secret['FCM_SERVER_KEY'];
    }

    /**
     * Gets the iVALT FCM Web Card API Key from the environment.
     *
     * @return string The FCM Web Card API Key.
     */
    protected function getFCMWebCardApiKey(): string
    {
        $secretsManager = new AwsSecretsManagerService;
        $secret = $secretsManager->getCredentials('GOOGLE_FCM');

        return $secret['FCM_SERVER_WEBCARD_KEY'];
    }

    /**
     * Formats the success response to the user using the standard format.
     *
     * @param Request $request
     * @param         $data
     * @param         $message
     * @param bool    $status
     * @param int     $statusCode
     *
     * @return JsonResponse
     */
    protected function success(Request $request, $data = null, $message = null, bool $status = true, int $statusCode = 200): JsonResponse
    {
        // build response model
        $responseModel = [
            'data' => [
                'status'  => $status,
                'message' => $message,
                'details' => $data,
            ],
            'error' => null,
            'debug' => [
                'timestamp'  => now(),
                'activityId' => $request->headers->get('activityId'),
            ],
        ];

        // return to client
        return response()->json($responseModel, $statusCode);
    }

    /**
     * Formats the error response to the user using the standard Problem Details format.
     *
     * @param Request $request
     * @param string  $title      short error category that a client can reliably program against
     * @param string  $detail     descriptive message for the error details
     * @param int     $statusCode the http status code
     *
     * @return JsonResponse
     */
    protected function error(Request $request, string $title, string $detail, int $statusCode)
    {
        // build response model
        $responseModel = [
            'data'  => null,
            'error' => [
                'type'     => 'https://httpstatuses.com/'.$statusCode,
                'title'    => $title,
                'status'   => $statusCode,
                'detail'   => $detail,
                'instance' => request()->getRequestUri(),
            ],
            'debug' => [
                'timestamp'  => now(),
                'activityId' => $request->headers->get('activityId'),
            ],
        ];

        // return to client
        return response()->json($responseModel, $statusCode);
    }

    /**
     * @param Request $request
     * @param array   $requiredFieldsArray
     *
     * @return false|string
     */
    protected function requiredFieldValidation(Request $request, array $requiredFieldsArray): string|false
    {
        $errorBag = [];
        foreach ($requiredFieldsArray as $input) {
            if (! $request->has($input) || ($request->input($input) === '')) {
                $errorBag[] = "The $input field is required.";
            }

            if (($request->input($input) === '[]') || is_array($request->input($input))) {
                $errorBag[] = "The $input field is not valid.";
            }
        }

        return json_encode($errorBag, true);
    }
}
