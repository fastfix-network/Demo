<?php

namespace App\Http\Controllers\Organization;

use App\Http\Controllers\ApiResponseController;
use App\Models\Organization\Organization;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class OrganizationAuthApiController extends ApiResponseController
{
    private array $requiredParams;

    public function __construct()
    {
        $this->requiredParams = ['domain', 'client_id', 'client_secret', 'grant_type', 'audience'];
    }

    /**
     * @param $orgId
     *
     * @return JsonResponse
     */
    public function getApiCredentials($orgId): JsonResponse
    {
        $orgModel = $this->checkIsOrganizationExist($orgId);
        if (! $orgModel) {
            return $this->error(request(), 'Not Found', 'Organization not found', 404);
        }

        return $this->success(request(), $orgModel->authApiCreds, 'Organization auth0 credentials fetched successfully');
    }

    /**
     * @param $orgId
     *
     * @return Organization|null
     */
    public function checkIsOrganizationExist($orgId): ?Organization
    {
        return Organization::find($orgId);
    }

    /**
     * @param         $orgId
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function createOrUpdateApiCredentials($orgId, Request $request): JsonResponse
    {
        $orgModel = $this->checkIsOrganizationExist($orgId);
        if (! $orgModel) {
            return $this->error(request(), 'Not Found', 'Organization not found', 404);
        }

        if (! $request->has($this->requiredParams)) {
            $message = $this->requiredFieldValidation($request, $this->requiredParams);

            return $this->error($request, 'Missing Required Parameters', $message, 400);
        } else {
            if (is_null($orgModel->authApiCreds)) {
                $auth0ApiCredentials = $orgModel->authApiCredentials()->create($request->all() + ['api_token' => null]);
            } else {
                $auth0ApiCredentials = $orgModel->authApiCredentials()->update($request->all() + ['api_token' => null]);
            }

            return $this->success(request(), $auth0ApiCredentials, 'Org Auth0 Api Credentials Updated successfully.');
        }
    }
}
