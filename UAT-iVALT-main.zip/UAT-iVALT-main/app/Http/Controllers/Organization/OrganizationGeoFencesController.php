<?php

namespace App\Http\Controllers\Organization;

use App\Http\Controllers\ApiResponseController;
use App\Models\Organization\Organization;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class OrganizationGeoFencesController extends ApiResponseController
{
    private array $requiredParams;

    public function __construct()
    {
        $this->requiredParams = ['name', 'latitude', 'longitude', 'radius', 'is_active'];
    }

    /**
     * @param $orgId
     *
     * @return JsonResponse
     */
    public function getAllOrganizationGeoFences($orgId)
    {
        $orgModel = Organization::find($orgId);
        if (is_null($orgModel)) {
            return $this->error(request(), 'Not Found', 'Organization not found', 404);
        }

        $orgGeoFencesModel = $orgModel->geoGeoFences()->get();

        if ($orgGeoFencesModel->isEmpty()) {
            return $this->error(request(), 'Not Found', 'Geo fences not found for '.$orgModel->name, 404);
        }

        return $this->success(request(), $orgGeoFencesModel, 'Geo fences fetched successfully');
    }

    /**
     * @param $orgId
     * @param $geoFencesId
     *
     * @return JsonResponse
     */
    public function getOrganizationGeoFences($orgId, $geoFencesId)
    {
        $orgModel = $this->checkIsOrganizationExist($orgId);
        if (is_null($orgModel)) {
            return $this->error(request(), 'Not Found', 'Organization not found', 404);
        }
        $orgGeoFencesModel = $orgModel->geoGeoFences()->find($geoFencesId);
        if (is_null($orgGeoFencesModel)) {
            return $this->error(request(), 'Not Found', 'Geo Fences not found for '.$orgModel->name, 404);
        }

        return $this->success(request(), $orgGeoFencesModel, 'Users fetched successfully');
    }

    /**
     * @param $orgId
     *
     * @return Organization|null
     */
    public function checkIsOrganizationExist($orgId): ?Organization
    {
        return Organization::find($orgId);
    }

    /**
     * @param         $orgId
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function storeOrganizationGeoFences($orgId, Request $request): JsonResponse
    {
        $orgModel = $this->checkIsOrganizationExist($orgId);

        if (is_null($orgModel)) {
            return $this->error(request(), 'Not Found', 'Organization not found', 404);
        }

        if (! $request->has($this->requiredParams)) {
            $message = $this->requiredFieldValidation($request, $this->requiredParams);

            return $this->error($request, 'Missing Required Parameters', $message, 400);
        } else {
            $isGeoFencesCreated = $orgModel->geoGeoFences()->create($request->all() + ['organization_id' => $orgModel->id]);

            if ($isGeoFencesCreated) {
                return $this->success(request(), $isGeoFencesCreated, 'Geo fences created successfully.');
            }
        }

        return $this->error(request(), 'Not Found', 'Geo fences not created for '.$orgModel->name, 404);
    }

    /**
     * @param         $orgId
     * @param         $geoFencesId
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function updateOrganizationGeoFences($orgId, $geoFencesId, Request $request): JsonResponse
    {
        $orgModel = $this->checkIsOrganizationExist($orgId);

        if (is_null($orgModel)) {
            return $this->error(request(), 'Not Found', 'Organization not found', 404);
        }

        $orgGeoGeoFencesModel = $orgModel->geoGeoFences()->find($geoFencesId);

        if (is_null($orgGeoGeoFencesModel)) {
            return $this->error(request(), 'Not Found', 'Geo fences not found.', 404);
        }

        $updateArray = $this->filterRequestValues([
            'name'      => $request->name,
            'latitude'  => $request->latitude,
            'longitude' => $request->longitude,
            'radius'    => $request->radius,
            'is_active' => $request->is_active ? 1 : 0,
        ]);

        $isGeoFencesUpdated = $orgGeoGeoFencesModel->update($updateArray);

        if ($isGeoFencesUpdated) {
            return $this->success(request(), $isGeoFencesUpdated, 'Geo fences updated successfully.');
        }

        return $this->error(request(), 'Not Found', 'Geo fences not updated for '.$orgModel->name, 404);
    }

    /**
     * @param $requestValArray
     *
     * @return array
     */
    private function filterRequestValues($requestValArray): array
    {
        $tempArray = [];
        foreach ($requestValArray as $key => $val) {
            if (! is_null($val)) {
                $tempArray[$key] = $val;
            }
        }

        return $tempArray;
    }

    /**
     * @param $orgId
     * @param $geoFencesId
     *
     * @return JsonResponse
     */
    public function deleteOrganizationGeoFences($orgId, $geoFencesId): JsonResponse
    {
        $orgModel = $this->checkIsOrganizationExist($orgId);
        if (is_null($orgModel)) {
            return $this->error(request(), 'Not Found', 'Organization not found', 404);
        }
        $orgGeoGeoFencesModel = $orgModel->geoGeoFences()->find($geoFencesId);
        if (is_null($orgGeoGeoFencesModel)) {
            return $this->error(request(), 'Not Found', 'Geo fences not found.', 404);
        }
        $orgGeoGeoFencesModel->delete();

        return $this->success(request(), ['deleted_id' => $orgGeoGeoFencesModel->id], 'Geo fences deleted successfully.');
    }
}
