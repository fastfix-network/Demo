<?php

namespace App\Http\Controllers\Organization;

use App\Http\Controllers\Controller;
use App\Models\Organization\TimeSlot;
use Illuminate\Http\Request;

class TimeSlotController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return void
     */
    public function index(): void
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return void
     */
    public function create(): void
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param Request $request
     *
     * @return void
     */
    public function store(Request $request): void
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param TimeSlot $timeSlot
     *
     * @return void
     */
    public function show(TimeSlot $timeSlot): void
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param TimeSlot $timeSlot
     *
     * @return void
     */
    public function edit(TimeSlot $timeSlot): void
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param Request  $request
     * @param TimeSlot $timeSlot
     *
     * @return void
     */
    public function update(Request $request, TimeSlot $timeSlot): void
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param TimeSlot $timeSlot
     *
     * @return void
     */
    public function destroy(TimeSlot $timeSlot): void
    {
        //
    }
}
