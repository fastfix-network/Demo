<?php

namespace App\Http\Controllers\Organization;

use App\Http\Controllers\ApiResponseController;
use App\Models\Organization\Organization;
use App\Models\Organization\TimeSlot;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class OrganizationController extends ApiResponseController
{
    private array $requiredParams;

    public function __construct()
    {
        $this->requiredParams = ['name', 'organization_code', 'has_geo_fencing', 'is_active', 'number_geo_fencing'];
    }

    /**
     * @param $user_id
     * @param $org_slug
     *
     * @return JsonResponse
     */
    public function getOrganizationBySlugOrCode($user_id = null, $org_slug = null): JsonResponse
    {
        if (is_null($user_id) || is_null($org_slug) || $user_id === 'null' || $org_slug === 'null') {
            $message = $this->requiredFieldValidation(new Request(['org_slug' => $org_slug, 'user_id' => $user_id]), ['org_slug', 'user_id']);

            return $this->error(request(), 'Missing Required Parameters', $message, 400);
        }

        $orgModel = Organization::where('organization_code', $org_slug)->first();

        if (is_null($orgModel)) {
            return $this->error(request(), 'Organization not found', 'The organization with the provided slug does not exist.', 404);
        }

        $user = $orgModel->users()->find($user_id);

        if (is_null($user)) {
            return $this->error(request(), 'User not found', 'The user with the provided ID does not exist in this organization.', 404);
        }

        return $this->success(request(), $user, 'Organizations fetched successfully');
    }

    /**
     * @param $orgIdOrSlug
     *
     * @return JsonResponse
     */
    public function getOrganizationByIdOrSlug($orgIdOrSlug = null): JsonResponse
    {
        if (is_null($orgIdOrSlug)) {
            $message = $this->requiredFieldValidation(new Request(['orgIdOrSlug' => $orgIdOrSlug]), ['orgIdOrSlug']);

            return $this->error(request(), 'Missing Required Parameters', $message, 400);
        }
        $orgModel = Organization::where('id', $orgIdOrSlug)->orWhere('organization_code', $orgIdOrSlug)->first();
        if (is_null($orgModel)) {
            return $this->error(request(), 'Not Found', 'Organization not found', 404);
        }

        return $this->success(request(), $orgModel, 'Organizations fetched successfully');
    }

    /**
     * @return JsonResponse
     */
    public function getAllOrganizations(): JsonResponse
    {
        return $this->success(request(), Organization::get(), 'Organizations fetched successfully');
    }

    /**
     * @param $orgId
     *
     * @return JsonResponse
     */
    public function getOrganization($orgId): JsonResponse
    {
        $orgModel = $this->checkIsOrganizationExist($orgId);
        if (! is_null($orgModel)) {
            return $this->success(request(), $orgId, 'Organization fetched successfully');
        }

        return $this->error(request(), 'Not Found', 'Organization not found', 404);
    }

    /**
     * @param $orgIdOrSlug
     *
     * @return Organization|null
     */
    private function checkIsOrganizationExist($orgIdOrSlug): ?Organization
    {
        return Organization::find($orgIdOrSlug);
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function storeOrganization(Request $request): JsonResponse
    {
        if (! $request->has($this->requiredParams)) {
            $message = $this->requiredFieldValidation($request, $this->requiredParams);

            return $this->error($request, 'Missing Required Parameters', $message, 400);
        } else {
            $isOrgExist = Organization::where('name', $request->name)->orWhere('organization_code', $request->organization_code)->count();
            if ($isOrgExist > 0) {
                return $this->error(request(), 'Failed', 'Organization Already Exist.', 403);
            }
            $orgModal = Organization::create([
                'name'               => $request->name,
                'organization_code'  => $request->organization_code,
                'has_geo_fencing'    => $request->has_geo_fencing ? 1 : 0,
                'number_geo_fencing' => $request->number_geo_fencing,
                'is_active'          => $request->is_active ? 1 : 0,
            ]);

            if ($orgModal) {
                $clientID = $this->generateRandomString(16, true, true);
                $clientSecret = $this->generateRandomString(40);
                if ($orgModal->authCodes()->count() == 0) {
                    $isAuthCodesCreated = $orgModal->authCodes()->create([
                        'client_id'     => $clientID,
                        'client_secret' => $clientSecret,
                    ]);
                }

                return $this->success(request(), $orgModal, 'Organization user created successfully.');
            }

            return $this->error(request(), 'Operation failed', 'Something went wrong!', 404);
        }
    }

    /**
     * @param int  $length
     * @param bool $onlyCapsAndDigits
     * @param bool $insertHyphen
     *
     * @return string
     */
    protected function generateRandomString(int $length = 16, bool $onlyCapsAndDigits = false, bool $insertHyphen = false): string
    {
        $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        if (! $onlyCapsAndDigits) {
            $characters .= 'abcdefghijklmnopqrstuvwxyz';
        }
        $string = '';
        for ($i = 0; $i < $length; $i++) {
            if (($i > 0 && $i % 4 == 0) && $insertHyphen) {
                $string .= '-';
            }
            $string .= $characters[rand(0, strlen($characters) - 1)];
        }

        return $string;
    }

    /**
     * @param         $orgId
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function updateOrganization($orgId, Request $request): JsonResponse
    {

        if (! $request->has($this->requiredParams)) {
            $message = $this->requiredFieldValidation($request, $this->requiredParams);

            return $this->error($request, 'Missing Required Parameters', $message, 400);
        }

        $orgModel = $this->checkIsOrganizationExist($orgId);
        if (is_null($orgModel)) {
            return $this->error(request(), 'Not Found', 'Organization not found', 404);

        } else {
            $isOrgUpdated = $orgModel->update([
                'name'               => $request->name,
                'organization_code'  => $request->organization_code,
                'has_geo_fencing'    => $request->has_geo_fencing ? 1 : 0,
                'number_geo_fencing' => $request->number_geo_fencing,
                'is_active'          => $request->is_active ? 1 : 0,
            ]);
            if ($isOrgUpdated) {
                return $this->success(request(), $isOrgUpdated, 'Organization updated successfully.');
            }

            return $this->error(request(), 'Operation failed', 'Something went wrong!', 404);
        }
    }

    /**
     * @param $orgId
     *
     * @return JsonResponse
     */
    public function deleteOrganization($orgId): JsonResponse
    {
        $orgModel = $this->checkIsOrganizationExist($orgId);
        if (is_null($orgModel)) {
            return $this->error(request(), 'Not Found', 'Organization not found', 404);
        }
        if ($orgModel->users()->count() > 0) {
            $orgModel->users()->detach();
        }
        if ($orgModel->pendingUsers()->count() > 0) {
            $orgModel->pendingUsers()->detach();
        }
        $orgModel->users()->delete();
        $orgModel->pendingUsers()->delete();
        $orgModel->geoGeoFences()->delete();
        $isOrgDeleted = $orgModel->delete();
        if ($isOrgDeleted) {
            return $this->success(request(), $isOrgDeleted, 'Organization deleted successfully.');
        }

        return $this->error(request(), 'Operation failed', 'Something went wrong!', 404);
    }

    /**
     * @param $orgId
     *
     * @return JsonResponse
     */
    public function orgTimeslotsList($orgId): JsonResponse
    {
        $orgModel = $this->checkIsOrganizationExist($orgId);

        if (is_null($orgModel)) {
            return $this->error(request(), 'Not Found', 'Organization not found', 404);
        }
        $orgTimeslots = TimeSlot::where('org_id', $orgId)->latest()->get();
        if (is_null($orgTimeslots)) {
            return $this->error(request(), 'Not Found', 'Org timeslots not found', 404);
        }

        return $this->success(request(), $orgTimeslots, 'Org timeslots list.');
    }

    /**
     * @param         $orgId
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function addOrgTimeslots($orgId, Request $request): JsonResponse
    {
        $orgModel = $this->checkIsOrganizationExist($orgId);
        if (is_null($orgModel)) {
            return $this->error(request(), 'Not Found', 'Organization not found', 404);
        }

        $requiredParams = ['timezone', 'start_time', 'end_time', 'status'];
        if (! $request->has($requiredParams)) {
            $message = $this->requiredFieldValidation($request, $requiredParams);

            return $this->error(
                $request,
                'Missing Required Parameters',
                $message,
                400
            );
        }

        $timeslots = TimeSlot::create([
            'org_id'     => $orgModel->id,
            'timezone'   => json_encode($request->timezone),
            'start_time' => $request->start_time,
            'end_time'   => $request->end_time,
            'status'     => $request->status,
        ]);

        if ($timeslots) {
            return $this->success($request, $timeslots, 'Time Slot added to organization');
        } else {
            return $this->error(
                $request,
                'Unprocessable Request',
                'Time Slot did not add to organization',
                404
            );
        }
    }

    /**
     * @param         $timeslotID
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function updateOrgTimeslots($timeslotID, Request $request): JsonResponse
    {
        $timeslot = TimeSlot::find($timeslotID);
        if (is_null($timeslot)) {
            return $this->error(request(), 'Not Found', 'TimeSlot not found', 404);
        }
        $requiredParams = ['timezone', 'start_time', 'end_time', 'status'];
        if (! $request->has($requiredParams)) {
            $message = $this->requiredFieldValidation($request, $requiredParams);

            return $this->error(
                $request,
                'Missing Required Parameters',
                $message,
                400
            );
        }

        $timeslots = $timeslot->update([
            'timezone'   => $request->timezone,
            'start_time' => $request->start_time,
            'end_time'   => $request->end_time,
            'status'     => $request->status,
        ]);

        if ($timeslots) {
            return $this->success($request, TimeSlot::find($timeslotID), 'Time Slot has been updated');
        } else {
            return $this->error(
                $request,
                'Unprocessable Request',
                'Time Slot did not update',
                404
            );
        }
    }

    /**
     * @param         $timeslotId
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function deleteOrgTimeslots($timeslotId, Request $request): JsonResponse
    {
        $timeslotModel = TimeSlot::find($timeslotId);
        if (is_null($timeslotModel)) {
            return $this->error(request(), 'Not Found', 'TimeSlot not found', 404);
        }
        $timeslots = $timeslotModel->delete();
        if ($timeslots) {
            return $this->success($request, [], 'Time Slot has been deleted');
        } else {
            return $this->error(
                $request,
                'Unprocessable Request',
                'Time Slot did not delete yet',
                404
            );
        }
    }

    /**
     * @param $userId
     *
     * @return JsonResponse
     */
    public function userTimeslotsList($userId): JsonResponse
    {
        $userModel = User::find($userId);
        if (is_null($userModel)) {
            return $this->error(request(), 'Not Found', 'User not found', 404);
        }

        $userTimeslots = $userModel->orgTimeSlots;

        if (is_null($userTimeslots)) {
            return $this->error(request(), 'Not Found', 'User timeslots not found', 404);
        }

        return $this->success(request(), $userTimeslots, 'User timeslots list.');
    }

    /**
     * @param         $userId
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function userTimeslotsListUpdate($userId, Request $request): JsonResponse
    {
        $userModel = User::find($userId);
        if (is_null($userModel)) {
            return $this->error($request, 'Not Found', 'User not found', 404);
        }
        $requiredParams = ['timeslot_ids'];

        if (! $request->has($requiredParams)) {
            $message = $this->requiredFieldValidation($request, $requiredParams);

            return $this->error(
                $request,
                'Missing Required Parameters',
                $message,
                400
            );
        }
        $userModel->orgTimeSlots()->detach();
        $userModel->orgTimeSlots()->attach($request->timeslot_ids);
        $user_timeslots = $userModel->orgTimeSlots;

        return $this->success($request, $user_timeslots, 'Org timeslots list.');
    }

    /**
     * @param $userId
     *
     * @return JsonResponse
     */
    public function userGeoFenceList($userId): JsonResponse
    {
        $userModel = User::find($userId);
        if (is_null($userModel)) {
            return $this->error(request(), 'Not Found', 'User not found', 404);
        }
        $userOrgGeoFences = $userModel->orgGeoFences;
        if (is_null($userOrgGeoFences)) {
            return $this->error(request(), 'Not Found', 'User orgGeoFences not found', 404);
        }

        return $this->success(request(), $userOrgGeoFences, 'User orgGeoFences list.');
    }

    public function userGeoFenceListUpdate($userId, Request $request): JsonResponse
    {
        $userModel = User::find($userId);
        if (is_null($userModel)) {
            return $this->error($request, 'Not Found', 'User not found', 404);
        }
        $requiredParams = ['orgGeoFence_ids'];
        if (! $request->has($requiredParams)) {
            $message = $this->requiredFieldValidation($request, $requiredParams);

            return $this->error(
                $request,
                'Missing Required Parameters',
                $message,
                400
            );
        }
        $userModel->orgGeoFences()->detach();
        $userModel->orgGeoFences()->attach($request->orgGeoFence_ids);
        $userOrgGeoFences = $userModel->orgGeoFences;
        if (is_null($userOrgGeoFences)) {
            return $this->error($request, 'Not Found', 'User orgGeoFences not found', 404);
        }

        return $this->success($request, $userOrgGeoFences, 'Org orgGeoFences list.');
    }
}
