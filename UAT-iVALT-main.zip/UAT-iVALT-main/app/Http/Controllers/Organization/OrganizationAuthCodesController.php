<?php

namespace App\Http\Controllers\Organization;

use App\Http\Controllers\ApiResponseController;
use App\Models\Organization\Organization;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class OrganizationAuthCodesController extends ApiResponseController
{
    private array $requiredParams;

    public function __construct()
    {
        $this->requiredParams = ['client_id', 'client_secret'];
    }

    /**
     * @param $orgId
     *
     * @return JsonResponse
     */
    public function getOrgAuthCodes($orgId): JsonResponse
    {
        $orgModel = $this->checkIsOrganizationExist($orgId);
        if (is_null($orgModel)) {
            return $this->error(request(), 'Not Found', 'Organization not found', 404);
        }

        return $this->success(request(), $orgModel->authCodes(), 'Organization auth codes fetched successfully');
    }

    /**
     * @param $orgId
     *
     * @return Organization|null
     */
    public function checkIsOrganizationExist($orgId): ?Organization
    {
        return Organization::find($orgId);
    }

    /**
     * @param         $orgId
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function storeOrganizationAuthCodes($orgId, Request $request): JsonResponse
    {
        $orgModel = $this->checkIsOrganizationExist($orgId);
        if (is_null($orgModel)) {
            return $this->error(request(), 'Not Found', 'Organization not found', 404);
        }

        if (! $request->has($this->requiredParams)) {
            $message = $this->requiredFieldValidation($request, $this->requiredParams);

            return $this->error($request, 'Missing Required Parameters', $message, 400);
        } else {
            if ($orgModel->authCodes()->count() == 0) {
                $isAuthCodesCreated = $orgModel->authCodes()->create(array_merge($request->all(), ['organization_id' => $orgModel->id]));

                if ($isAuthCodesCreated) {
                    return $this->success(request(), $isAuthCodesCreated, 'Org Auth Code created successfully.');
                }
            }

            return $this->error(request(), 'Auth Code Exists!', 'Org Auth Code already exists.', 404);
        }
    }

    /**
     * @param         $orgId
     * @param         $authCodeId
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function updateOrganizationAuthCodes($orgId, $authCodeId, Request $request): JsonResponse
    {
        $orgModel = $this->checkIsOrganizationExist($orgId);
        if (is_null($orgModel)) {
            return $this->error(request(), 'Not Found', 'Organization not found', 404);
        }

        $orgAuthCodesModel = $orgModel->authCodes()->find($authCodeId);

        if (is_null($orgAuthCodesModel)) {
            return $this->error(request(), 'Not Found', 'Org Auth Code not found.', 404);
        }

        $updateArray = $this->filterRequestValues([
            'client_secret' => $request->client_secret,
        ]);

        $isOrgAuthCodesUpdated = $orgAuthCodesModel->update($updateArray);

        if ($isOrgAuthCodesUpdated) {
            return $this->success(request(), $orgModel->authCodes()->find($authCodeId), 'Org Auth Code updated successfully.');
        }

        return $this->error(request(), 'Not Found', 'Org Auth Code not updated.', 404);
    }

    /**
     * @param $requestValArray
     *
     * @return array
     */
    private function filterRequestValues($requestValArray): array
    {
        $tempArray = [];
        foreach ($requestValArray as $key => $val) {
            if (! is_null($val)) {
                $tempArray[$key] = $val;
            }
        }

        return $tempArray;
    }

    /**
     * @param $orgId
     * @param $authCodeId
     *
     * @return JsonResponse
     */
    public function deleteOrganizationAuthCodes($orgId, $authCodeId)
    {
        $orgModel = $this->checkIsOrganizationExist($orgId);
        if (is_null($orgModel)) {
            return $this->error(request(), 'Not Found', 'Organization not found', 404);
        }

        $orgAuthCodesModel = $orgModel->authCodes()->find($authCodeId);
        if (is_null($orgAuthCodesModel)) {
            return $this->error(request(), 'Not Found', 'Org Auth Code not found.', 404);
        }
        $orgAuthCodesModel->delete();

        return $this->success(request(), ['deleted_id' => $orgAuthCodesModel->id], 'Org Auth Code deleted successfully.');
    }
}
