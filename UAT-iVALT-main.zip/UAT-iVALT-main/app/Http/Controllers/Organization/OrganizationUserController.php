<?php

namespace App\Http\Controllers\Organization;

use App\Http\Controllers\ApiResponseController;
use App\Http\Controllers\Auth0\Auth0ApiController;
use App\Models\Organization\Organization;
use App\Models\Organization\OrganizationAuthCode;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class OrganizationUserController extends ApiResponseController
{
    private array $requiredParams;

    public function __construct()
    {
        $this->requiredParams = ['mobile', 'country_code', 'name', 'platform', 'email', 'imei', 'device_token', 'user_code', 'is_admin'];
    }

    /**
     * @param $orgId
     *
     * @return JsonResponse
     */
    public function getAllOrganizationUser($orgId): JsonResponse
    {
        $orgModel = $this->checkIsOrganizationExist($orgId);

        if (! is_null($orgModel)) {

            return $this->success(request(), $orgModel->users->load('timeSlots'), 'Users fetched successfully');
        }

        return $this->error(request(), 'Not Found', 'Organization not found', 404);
    }

    /**
     * @param $orgId
     *
     * @return Organization|null
     */
    public function checkIsOrganizationExist($orgId): ?Organization
    {
        return Organization::find($orgId);
    }

    /**
     * @param $orgId
     * @param $userId
     *
     * @return JsonResponse
     */
    public function getOrganizationUser($orgId, $userId): JsonResponse
    {
        $orgModel = $this->checkIsOrganizationExist($orgId);

        if (! $orgModel) {
            return $this->error(request(), 'Not Found', 'Organization not found', 404);
        }

        $organizationModel = Organization::where('id', $orgModel->id)->first();

        if (! is_null($organizationModel)) {
            $userModel = $organizationModel->users()->find($userId);

            if (is_null($userModel)) {
                return $this->error(request(), 'Not Found', 'User not found for '.$organizationModel->name, 404);
            }

            return $this->success(request(), $userModel, 'Users fetched successfully');
        }

        return $this->error(request(), 'Not Found', 'Organization not found', 404);
    }

    /**
     * @param         $orgId
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function storeOrganizationUser($orgId, Request $request): JsonResponse
    {
        $organizationModel = $this->checkIsOrganizationExist($orgId);
        if (is_null($organizationModel)) {
            return $this->error(request(), 'Not Found', 'Organization not found', 404);
        }

        if (! $request->has($this->requiredParams)) {
            $message = $this->requiredFieldValidation($request, $this->requiredParams);

            return $this->error($request, 'Missing Required Parameters', $message, 400);
        } else {
            // $organizationModel = Organization::find($orgModel);

            if (! is_null($organizationModel)) {
                $isUserCreated = $organizationModel->users()->create(
                    $request->except('is_admin'),
                    ['is_admin'  => $request->is_admin ? 1 : 0],
                    ['is_active' => 0]
                );

                $isUserExistOnAuth0 = Auth0ApiController::checkIfUserExistOnAuth0($organizationModel->id, $request->email);

                if (($isUserExistOnAuth0['statusCode'] === 404) && ($isUserExistOnAuth0['error'] === 'Not Found')) {
                    $response = Auth0ApiController::createUser($organizationModel->id, $isUserCreated, $request->auth0_user_password);
                } else {
                    $response = Auth0ApiController::updateUser($organizationModel->id, $request->country_code.$request->mobile, $isUserExistOnAuth0['user_id']);
                }

                $updateArray = [];

                if ((count($response) > 0) && ! is_null($response)) {
                    $updateArray['auth0_user_id'] = $response['user_id'];
                }

                if ($isUserCreated && count($updateArray) > 0) {
                    $isUserCreated->update($updateArray);

                    return $this->success(request(), $isUserCreated, 'User created successfully.');
                }

                return $this->error(request(), 'Operation failed', 'Something went wrong!', 404);
            }

            return $this->error(request(), 'Not Found', 'Organization not found', 404);
        }
    }

    /**
     * @param         $orgId
     * @param         $userId
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function updateOrganizationUser($orgId, $userId, Request $request): JsonResponse
    {
        $orgModel = $this->checkIsOrganizationExist($orgId);
        if (! $orgModel) {
            return $this->error(request(), 'Not Found', 'Organization not found', 404);
        }

        $orgUserModel = $orgModel->users()->find($userId);

        if (is_null($orgUserModel)) {
            return $this->error(request(), 'Not Found', 'User not found.', 404);
        }

        $updateArray = $this->filterRequestValues([
            'email'        => $request->email,
            'mobile'       => $request->mobile,
            'country_code' => $request->country_code,
            'name'         => $request->name,
        ]);

        $updateArray['verify_geo_fencing'] = 0;
        $updateArray['verify_timeslots'] = 0;

        if ($request->has('verify_geo_fencing') && $request->verify_geo_fencing === 'on') {
            $updateArray['verify_geo_fencing'] = 1;
        }

        if ($request->has('verify_timeslots') && $request->verify_timeslots === 'on') {
            $updateArray['verify_timeslots'] = 1;
        }

        $response = null;

        if ($request->has('create_auth0_user') && $request->create_auth0_user === 'on') {
            $this->requiredParams = ['auth0_user_password'];

            if (! $request->has($this->requiredParams)) {
                $message = $this->requiredFieldValidation($request, $this->requiredParams);

                return $this->error($request, 'Missing Required Parameters', $message, 400);
            } else {
                $isUserExistOnAuth0 = Auth0ApiController::checkIfUserExistOnAuth0($orgModel->id, $request->email);

                if ((isset($isUserExistOnAuth0['statusCode']) && $isUserExistOnAuth0['statusCode'] === 404) || count($isUserExistOnAuth0) == 0) {
                    $response = Auth0ApiController::createUser($orgModel->id, $request);
                } else {
                    $response = Auth0ApiController::updateUser($orgModel->id, $request->country_code.$request->mobile, $isUserExistOnAuth0[0]['user_id']);
                }

                if (isset($response['error'])) {
                    return $this->error(request(), $response['error'], $response['message'], $response['statusCode']);
                } else {
                    if (count($response)) {
                        $updateArray['auth0_user_id'] = isset($response['user_id']) ? $response['user_id'] : $response[2];
                    }
                }
            }
        }

        $isUserUpdated = $orgUserModel->update($updateArray);

        if ($isUserUpdated) {
            return $this->success(request(), [
                'ivalt_user'     => $orgUserModel,
                'auth0_response' => $response,
            ], 'User updated successfully.');
        }

        return $this->error(request(), 'Operation failed', 'Something went wrong!', 404);
    }

    /**
     * @param $requestValArray
     *
     * @return array
     */
    private function filterRequestValues($requestValArray): array
    {
        $tempArray = [];
        foreach ($requestValArray as $key => $val) {
            if (! is_null($val)) {
                $tempArray[$key] = $val;
            }
        }

        return $tempArray;
    }

    /**
     * @param $orgId
     * @param $userId
     *
     * @return JsonResponse
     */
    public function deleteOrganizationUser($orgId, $userId): JsonResponse
    {
        $orgModel = $this->checkIsOrganizationExist($orgId);

        if (! $orgModel) {
            return $this->error(request(), 'Not Found', 'Organization not found', 404);
        }

        $orgUserModel = $orgModel->users()->find($userId);

        if (is_null($orgUserModel)) {
            return $this->error(request(), 'Not Found', 'User not found.', 404);
        }

        $orgUserModel->delete();

        if ($orgModel->users()->detach($userId)) {
            return $this->success(request(), ['deleted_id' => $orgUserModel->id], 'User deleted successfully.');
        }

        return $this->error(request(), 'Operation failed', 'Something went wrong!', 404);
    }

    /**
     * @param $orgId
     *
     * @return JsonResponse
     */
    public function getAllOrganizationPendingUser($orgId): JsonResponse
    {
        $orgModel = $this->checkIsOrganizationExist($orgId);
        if (! $orgModel) {
            return $this->error(request(), 'Not Found', 'Organization not found', 404);
        }

        $pendingUsers = $orgModel->pendingUsers;

        if (is_null($pendingUsers)) {
            return $this->error(request(), 'Not Found', 'Pending Users not found.', 404);
        }

        return $this->success(request(), $pendingUsers, 'Pending Users fetched successfully');
    }

    /**
     * @param $orgId
     * @param $userId
     *
     * @return JsonResponse
     */
    public function acceptOrganizationUser($orgId, $userId): JsonResponse
    {
        $orgModel = $this->checkIsOrganizationExist($orgId);

        if (is_null($orgModel)) {
            return $this->error(request(), 'Not Found', 'Organization not found', 404);
        }

        $userModel = $orgModel->pendingUsers()->find($userId);

        if (is_null($userModel)) {
            return $this->error(request(), 'Not Found', 'User not found', 404);
        }

        $orgModel->pendingUsers()->detach($userModel->id);
        $orgModel->users()->attach($userModel->id);

        return $this->success(request(), ['user_id' => $userModel->id], 'Operation successfully completed.');
    }

    /**
     * @param $orgId
     * @param $userId
     *
     * @return JsonResponse
     */
    public function rejectOrganizationUser($orgId, $userId): JsonResponse
    {
        $orgModel = $this->checkIsOrganizationExist($orgId);
        if (is_null($orgModel)) {
            return $this->error(request(), 'Not Found', 'Organization not found', 404);
        }

        $isUserExist = $orgModel->pendingUsers()->find($userId);

        if (is_null($isUserExist)) {
            return $this->error(request(), 'Not Found', 'User not found', 404);
        }
        $orgModel->pendingUsers()->updateExistingPivot($userId, ['is_active' => 1], false);

        // $orgModel->pendingUsers()->detach($userId);
        // $isUserExist->delete();
        return $this->success(request(), ['user_id' => $userId], 'User rejected successfully.');
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function getUserOrganizations(Request $request): JsonResponse
    {
        $this->requiredParams = ['mobile_number'];
        if (! $request->has($this->requiredParams)) {
            $message = $this->requiredFieldValidation($request, $this->requiredParams);

            return $this->error($request, 'Missing Required Parameters', $message, 400);
        } else {
            $user = User::where('mobile_with_country_code', $request->mobile_number)->first();
            if (is_null($user)) {
                return $this->error(request(), 'Not Found', 'User not found', 404);
            }

            $organizations = [];
            foreach ($user->organizations->where('is_active', 1) as $org) {
                $organizations[] = [
                    'id'                => $org->id,
                    'name'              => $org->name,
                    'organization_code' => $org->organization_code,
                    'status'            => 'Accept',
                ];
            }

            foreach ($user->pendingOrganizations->where('is_active', 1) as $org) {
                $organizations[] = [
                    'id'                => $org->id,
                    'name'              => $org->name,
                    'organization_code' => $org->organization_code,
                    'status'            => $org->pivot->is_Active ? 'Reject' : 'Pending',
                ];
            }

            return $this->success($request, [
                'user'          => $user,
                'organizations' => $organizations,
            ], 'User Organizations fetched successfully.');
        }
    }

    /**
     * @param $orgId
     * @param $userId
     *
     * @return JsonResponse
     */
    public function setOrganizationUserPending($orgId, $userId): JsonResponse
    {
        $orgModel = $this->checkIsOrganizationExist($orgId);

        if (is_null($orgModel)) {
            return $this->error(request(), 'Not Found', 'Organization not found', 404);
        }

        if (is_null($orgModel->users()->find($userId))) {
            return $this->error(request(), 'Not Found', 'User not found', 404);
        }

        $orgModel->users()->detach($userId);

        if ($orgModel->pendingUsers()->where('id', $userId)->count() > 0) {
            $orgModel->pendingUsers()->detach($userId);
        }

        $orgModel->pendingUsers()->attach($userId);

        return $this->success(request(), ['user_id' => $userId], 'User status updated successfully.');
    }

    /**
     * Removes the organization user.
     *
     * @param Request $request The request object containing the required parameters: org_id, country_code, and mobile.
     *
     * @return JsonResponse The response from the function call. It returns an error response if the required parameters are missing or the user is not found. Otherwise, it returns a success response with the removed user details.
     */
    public function removeOrganizationUser(Request $request): JsonResponse
    {
        $this->requiredParams = ['org_id', 'country_code', 'mobile'];
        if (! $request->has($this->requiredParams)) {
            $message = $this->requiredFieldValidation($request, $this->requiredParams);

            return $this->error($request, 'Missing Required Parameters', $message, 400);
        } else {
            $orgModel = Organization::find($request->org_id);

            $user = $orgModel->users()->where(['country_code' => $request->country_code, 'mobile' => $request->mobile])->first();

            $pendingUser = $orgModel->pendingUsers()->where(['country_code' => $request->country_code, 'mobile' => $request->mobile])->first();

            if (! $user && ! $pendingUser) {
                return $this->error($request, 'Not Found', 'User not found', 404);
            }

            if (! is_null($user)) {
                $orgModel->users()->detach($user->id);
            }

            if ($pendingUser) {
                $orgModel->pendingUsers()->detach($pendingUser->id);
            }

            return $this->success(request(), [
                'country_code' => $request->country_code,
                'mobile'       => $request->mobile,
                'org_id'       => $request->org_id,
            ], 'User removed successfully.');
        }
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function getOrganizationUserDetails(Request $request): JsonResponse
    {
        $this->requiredParams = ['client_id'];

        if (! $request->has($this->requiredParams)) {
            $message = $this->requiredFieldValidation($request, $this->requiredParams);

            return $this->error($request, 'Missing Required Parameters', $message, 400);
        } else {
            $orgAuthCodeModel = OrganizationAuthCode::with('organization')->where([
                'client_id' => $request->client_id,
            ])->whereHas('organization')->first();

            if (! $orgAuthCodeModel) {
                return $this->error($request, 'Invalid details', 'Invalid client id', 400);
            } else {
                return $this->success($request, [
                    'organization' => $orgAuthCodeModel->organization->unsetRelation('users')->only([
                        'name', 'organization_code', 'is_active',
                    ]),
                    'client_id'     => $orgAuthCodeModel->client_id,
                    'client_secret' => $orgAuthCodeModel->client_secret,
                ], 'Details fetched successfully');
            }
        }
    }
}
