<?php

namespace App\Http\Controllers;

//define('API_URL','http://54.152.202.113:3000/api/');
define('API_URL', 'http://h5.copperwiresystems.com:3000/api/');
class HttpController extends Controller
{
    /**
     * @var string
     */

    /**
     * @param      $endPoint
     * @param      $data
     * @param null $userToken
     *
     * @return mixed
     */
    public static function get($endPoint, $data, $userToken = null)
    {
        if ($data !== null) {
            $response = self::apiRequest($endPoint, 'GET', $data, $userToken);
        } else {
            $response = self::apiRequest($endPoint, 'GET', $data, $userToken);
        }

        return $response;
    }

    /**
     * @param      $endPoint
     * @param      $data
     * @param null $userToken
     *
     * @return mixed
     */
    public static function post($endPoint, $data, $userToken = null)
    {
        return self::apiRequest($endPoint, 'POST', json_encode($data), $userToken);
    }

    /**
     * @param      $endPoint
     * @param      $id
     * @param null $userToken
     *
     * @return mixed
     */
    public static function delete($endPoint, $id, $userToken = null)
    {
        return self::apiRequest($endPoint, 'DELETE', $id, $userToken);
    }

    /**
     * @param      $endPoint
     * @param      $id
     * @param null $userToken
     *
     * @return mixed
     */
    public static function head($endPoint, $id, $userToken = null)
    {
        $data = ['id' => $id];

        return self::apiRequest($endPoint, 'HEAD', $data, $userToken);
    }

    /**
     * @param      $endPoint
     * @param      $data
     * @param null $userToken
     *
     * @return mixed
     */
    public static function put($endPoint, $data, $id = null)
    {
        return self::apiRequest($endPoint, 'PUT', json_encode($data), $id);
    }

    /**
     * @param      $endpoint
     * @param      $type
     * @param      $data
     * @param null $userToken
     *
     * @return mixed
     */
    public static function apiRequest($endpoint, $type, $data, $userToken = null)
    {
        $curl = curl_init();

        if (($type === 'GET' || $type === 'DELETE') && $data !== null) {
            $url = API_URL.$endpoint.'/'.$data;
        } elseif ($type === 'PUT' && $userToken != null) {
            $url = API_URL.$endpoint.'/'.$userToken;
        } else {
            $url = API_URL.$endpoint;
        }

        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_ENCODING, '');
        curl_setopt($curl, CURLOPT_MAXREDIRS, 10);
        curl_setopt($curl, CURLOPT_TIMEOUT, 0);
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($curl, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $type);

        if (($type === 'POST' || $type === 'PUT') && $data != null) {
            curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
            curl_setopt($curl, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        }

        return json_decode(curl_exec($curl), true);
    }
}
