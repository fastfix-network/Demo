<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use DB;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Contracts\View\Factory;
use Illuminate\Contracts\View\View;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Str;

class RESTController extends Controller
{
    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function authenticateUser(Request $request): JsonResponse
    {
        if ($request->has('client_id') && $request->has('client_secret')) {
            $db = DB::table('api_secrets');
            $result = $db->where(['client_key' => $request->client_id, 'secret_key' => $request->client_secret])->first();
            if ($result == null) {
                return response()->json(['status' => 'error', 'message' => 'unable to authenticate user!']);
            } else {
                $token = Str::random(100);
                //                $this->_deleteOldTokens($request->client_id);
                $db = DB::table('api_tokens');
                $db->insert([
                    'client_id'  => $request->client_id,
                    'auth_token' => $token,
                    'created_at' => Carbon::now(),
                    'updated_at' => Carbon::now(),
                ]);

                return response()->json(['status' => 'success', 'message' => 'user authenticate successfully!', 'auth_token' => $token]);
            }
        } else {
            return response()->json(['status' => 'error', 'message' => 'Required params are missing'], 403);
        }
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function loginUrl(Request $request): JsonResponse
    {
        if ($request->has('auth_token') && $request->has('success_url') && $request->has('cancel_url') && $request->has('user_mobile')) {
            $authToken = DB::table('api_tokens')->where('auth_token', $request->auth_token)->first();
            $userModel = DB::table('users')->where(['mobile' => $request->user_mobile])->first();
            if ($userModel == null) {
                return response()->json(['status' => 'error', 'message' => 'User not found with given mobile number.']);
            }
            if ($authToken == null) {
                return response()->json(['status' => 'error', 'message' => 'Unable to authenticate user!'], 403);
            }
            $minutesDiffer = Carbon::parse($authToken->updated_at)->diffInMinutes(Carbon::now());
            if ($minutesDiffer > 30) {
                $this->_deleteOldTokens($authToken->client_id);

                return response()->json(['status' => 'error', 'message' => 'Authentication has been expired!'], 403);
            }
            $this->_refreshTokenTime($request->auth_token);
            $this->_updateUrls($request);

            return response()->json(['status' => 'success', 'login_url' => route('api.user.auth',
                [
                    'auth_token'      => $request->auth_token,
                    'uid'             => base64_encode($userModel->id),
                    'redirect_url'    => route('update.success.faceauth', ['auth_token' => $request->auth_token]),
                    'redirect_cancel' => $authToken->cancel_url,
                ]),
            ]);
        } else {
            return response()->json(['status' => 'error', 'message' => 'Required params are missing'], 403);
        }
    }

    /**
     * @param $client_id
     *
     * @return bool
     */
    protected function _deleteOldTokens($client_id): bool
    {
        $db = DB::table('api_tokens');
        $db->where('client_id', $client_id)->delete();

        return true;
    }

    /**
     * @param $token
     *
     * @return bool
     */
    protected function _refreshTokenTime($token): bool
    {
        DB::table('api_tokens')->update(['updated_at' => Carbon::now()]);

        return true;
    }

    /**
     * @param $request
     *
     * @return bool
     */
    protected function _updateUrls($request): bool
    {
        DB::table('api_tokens')->where('auth_token', $request->auth_token)
            ->update(['success_url' => $request->success_url, 'cancel_url' => $request->cancel_url, 'user_mobile' => $request->user_mobile]);

        return true;
    }

    /**
     * @param $auth_token
     *
     * @return RedirectResponse|string
     */
    public function saveSuccessFaceAuth($auth_token)
    {
        $model = DB::table('api_tokens')->where(['auth_token' => $auth_token])->first();
        if ($model == null) {
            return 'Some thing went wrong please try again!';
        } else {
            $token = Str::random(30);
            DB::table('api_tokens')->where(['auth_token' => $auth_token])->update(['success_auth_token' => $token]);

            return redirect()->to($model->success_url.'/'.$token);
        }
    }

    /**
     * @param $auth_token
     *
     * @return Application|Factory|View|JsonResponse
     */
    public function authUser($auth_token)
    {
        $authToken = DB::table('api_tokens')->where('auth_token', $auth_token)->first();
        if ($authToken == null) {
            return response()->json(['status' => 'error', 'message' => 'Unable to authenticate user!'], 403);
        }
        $this->_refreshTokenTime($auth_token);

        return view('auth', ['auth_token' => $auth_token]);
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function validateUserFaceAuth(Request $request): JsonResponse
    {
        if ($request->has('auth_token') && $request->has('face_auth_token')) {
            $isAUthExists = DB::table('api_tokens')->where(['auth_token' => $request->auth_token, 'success_auth_token' => $request->face_auth_token])->first();
            if ($isAUthExists == null) {
                return response()->json(['status' => 'error', 'message' => 'Authentication not found!']);
            } else {
                DB::table('api_tokens')->where(['auth_token' => $request->auth_token])->update(['success_auth_token' => '']);

                return response()->json(['status' => 'success', 'message' => 'User authenticate successfully!']);
            }
        } else {
            return response()->json(['status' => 'error', 'message' => 'Required params are missing!']);
        }
    }

    /**
     * @param $auth_token
     * @param $mobile
     *
     * @return Application|Factory|View|RedirectResponse
     */
    public function redirectToMerchant($auth_token, $mobile)
    {
        $model = DB::table('web_auth')->where('mobile', 'like', '%'.$mobile.'%')->first();
        $authToken = DB::table('api_tokens')->where('auth_token', $auth_token)->first();
        if ($model != null) {
            DB::table('web_auth')->where('mobile', 'like', '%'.$mobile.'%')->delete();

            return view('redirect_success', ['mobile' => $mobile, 'authToken' => $authToken]);
        } else {
            return redirect()->to($authToken->cancel_url);
        }
    }
}
