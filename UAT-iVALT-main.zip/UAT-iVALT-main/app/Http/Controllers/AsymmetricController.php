<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Services\EncryptionService;
use Illuminate\Contracts\Filesystem\FileNotFoundException;
use Illuminate\Http\Request;

class AsymmetricController extends ApiResponseController
{
    private $encryptionService;

    /**
     * @param EncryptionService $encryptionService
     */
    public function __construct(EncryptionService $encryptionService)
    {
        $this->encryptionService = $encryptionService;
    }

    /**
     * @param $data
     *
     * @throws FileNotFoundException
     *
     * @return mixed
     */
    public function encryptData($data = null)
    {
        return $this->encryptionService->encrypt($data);
    }

    /**
     * @param $ciphertext
     *
     * @throws FileNotFoundException
     *
     * @return mixed
     */
    public function decryptData($ciphertext = null)
    {
        return $this->encryptionService->decrypt($ciphertext);
    }

    /**
     * @throws FileNotFoundException
     *
     * @return mixed
     */
    public function testing()
    {
        $data_json = [
            'country_code' => '+91',
            'mobile'       => '9530654704',
        ];

        $Ecobj = new EncryptionService;
        $data = json_encode($data_json, true);
        $ciphertext = $Ecobj->encrypt($data);
        $finaldata = base64_encode($ciphertext);
        $encrupted = 'SWhRaU5UMkc2WHJvZWl3dEJjc2p3RG1uOFl6TXlSdDVFWThqR09uTmdiclB4UmxPaHZMaVhnbkRUWkxBU2JYUFlWMmN2d2lZWlU5bU03M2VPd1dPVlNzemtMSG16cDJGTXhSa2dMaHluL2xISlpnRmgwL242MGkzeGdWMFpsZWY3QmowbUpoV0xhcS94SDRQYXBEQmJGbzBESnJGWE9sU2tPYms0M2EvQVRhdG5YZ1VvWGl3US8rRk5WU1FmTWFPWXVjc2VXdks2eFB2Q2FlQ281NS85eThSVWpLN2pKZ3J5a0pyV1JlTlluTW8vUUEvRlBseURkVzd1aFZJT0drbXRNWXZPUlFGTGh4S2d5cUxSczNZL0dmWWVleGhyUTdvTmdLYWJpR3JTTkVqUW8yNk52WkZVRktaeWV4N1U4SkdIV1d5YldNWmZlMFZqYWVkSldxTEVBPT0=';

        dd($Ecobj->decrypt(base64_decode($encrupted)));

        // return $plaintext;
    }

    public function verifyUser(Request $request)
    {
        $rsa = new EncryptionService;
        $userModal = User::where(['country_code' => $request->country_code, 'mobile' => $request->mobile])->first([
            'country_code', 'mobile', 'name', 'email', 'platform',
        ]);

        if ($userModal) {
            return $this->success($request, $rsa->encrypt($userModal->toArray()), 'User fetched Successfully', 200);
        } else {
            return $this->error(
                $request,
                'Not Found',
                'User  not found.',
                404
            );
        }

        // return json_encode($responseModel);
    }
}
