<?php

namespace App\Http\Controllers\App;

use App\Http\Controllers\ApiResponseController;
use App\Http\Controllers\SmsController;
use App\Models\User;
use App\Services\EmailService;
use App\Services\SmsService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use PHPMailer\PHPMailer\Exception;

class EmailController extends ApiResponseController
{
    private EmailService $emailService;

    /**
     * Constructor for the EmailController class.
     *
     * @param EmailService $emailService
     */
    public function __construct(EmailService $emailService)
    {
        $this->emailService = $emailService;
    }

    /**
     * @param Request $request
     *
     * @throws Exception
     * @throws Exception
     * @return JsonResponse|RedirectResponse
     */
    public function validateEmail(Request $request)
    {
        $userAgent = $request->header('User-Agent');
        $returnJson = str_contains($userAgent, 'Postman') || str_contains($userAgent, 'Insomnia') || $request->ajax() || $request->wantsJson() || str_contains($userAgent, 'Burp');
        $requiredParams = ['token', 'email'];

        if (! $this->validateRequiredParams($request, $requiredParams)) {
            return $this->error($request, 'Missing Required Parameters', $this->requiredFieldValidation($request, $requiredParams), 400);
        }

        $smsController = new SmsController(new SmsService);
        $userModel = User::where(['temp_email' => $request->email, 'email_verification_token' => $request->token])
            ->orWhere(['email' => $request->email, 'email_verification_token' => $request->token])->first();

        if (is_null($userModel)) {
            if ($returnJson) {
                return $this->error($request, 'Not Found', 'The email provided ('.$request->email.') is not registered with iVALT.', 404);
            }

            return redirect()->away(env('MAIL_VERIFICATION_FAILED_CALLBACK_URL'));
        }

        if (! is_null($userModel->temp_email) && $userModel->temp_email != $request->email) {
            return $this->sendWelcomeMailOnNewMail($smsController, $userModel, $request, $returnJson);
        }

        if ($userModel->email == $request->email) {
            return $this->sendWelcomeMailOnExistingMail($smsController, $userModel, $request, $returnJson);
        }

        return $this->error($request, 'Not Found', 'The email provided ('.$request->email.') is not registered with iVALT.', 404);
    }

    /**
     * @param $smsController
     * @param $userModel
     * @param $request
     * @param $returnJson
     * @throws Exception
     * @return JsonResponse|RedirectResponse
     */
    private function sendWelcomeMailOnNewMail($smsController, $userModel, $request, $returnJson)
    {
        $newMail = $userModel->temp_email;
        $oldEmail = $userModel->email;

        // Send email to the user with the new email
        $this->emailService->sendRegistrationSuccessEmail($newMail, $userModel->name);

        // Send email to the user with the old email
        $this->emailService->sendRegistrationSuccessOnOldEmail($userModel->email, $userModel->name);

        $userModel->update([
            'email_verification_token' => null,
            'is_email_verified'        => 1,
            'email'                    => $newMail,
            'temp_email'               => $oldEmail,
        ]);
        // Send SMS to the user with the new email
        $smsController->successReRegistrationSMS($userModel->mobile_with_country_code, $userModel->name);

        if ($returnJson) {
            return $this->success($request, [], 'Email verified successfully.');
        }

        return redirect()->away(env('MAIL_VERIFICATION_SUCCESS_CALLBACK_URL'));
    }

    /**
     * @param $smsController
     * @param $userModel
     * @param $request
     * @param $returnJson
     * @throws Exception
     * @return JsonResponse|RedirectResponse
     */
    public function sendWelcomeMailOnExistingMail($smsController, $userModel, $request, $returnJson)
    {
        $this->emailService->sendRegistrationSuccessEmail($userModel->email, $userModel->name);

        $userModel->update([
            'email_verification_token' => null,
            'is_email_verified'        => 1,
            'email'                    => $request->email,
        ]);

        $smsController->successRegistrationSMS($userModel->mobile_with_country_code, $userModel->name);

        if ($returnJson) {
            return $this->success($request, [], 'Email verified successfully.');
        }

        return redirect()->away(env('MAIL_VERIFICATION_SUCCESS_CALLBACK_URL'));
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function isEmailVerified(Request $request)
    {
        $requiredParams = ['country_code', 'mobile', 'platform', 'email'];
        if (! $this->validateRequiredParams($request, $requiredParams)) {
            $message = $this->requiredFieldValidation($request, $requiredParams);

            return $this->error(
                $request,
                'Missing Required Parameters',
                $message,
                400
            );
        }

        if ($request->mobile == '1234567890' && $request->country_code == '+1' && $request->email == 'test@ivalt.com') {
            return $this->success($request, [
                'id'                => 0,
                'email'             => $request->email,
                'is_email_verified' => 1,
                'email_verified_at' => now(),
            ], 'Email has been verified.');
        }

        if (! in_array($request->platform, ['android', 'iOS'])) {
            return $this->error(
                $request,
                'Bad Request',
                'Provided platform is not valid.',
                400
            );
        }

        $platform = ($request->platform == 'android') ? 'android' : 'ios';

        $userModel = User::where([
            'country_code' => $request->country_code,
            'mobile'       => $request->mobile,
            'platform'     => $platform,
        ])->first();

        if (is_null($userModel) || ($userModel->email !== $request->email && $userModel->temp_email !== $request->email)) {
            return $this->error(
                $request,
                'Not Found',
                'The email provided ('.$request->email.') was not found.',
                404
            );
        }

        if (($userModel->is_email_verified == 1 || $userModel->is_email_verified == '1') && is_null($userModel->email_verification_token)) {
            return $this->success($request, [
                'id'                => $userModel->id,
                'email'             => $request->email,
                'is_email_verified' => 1,
                'email_verified_at' => $userModel->updated_at,
            ], 'Email has been verified.');
        }

        return $this->error(
            $request,
            'Not Found',
            'The email provided ('.$request->email.') has not been verified.',
            404
        );

    }
}
