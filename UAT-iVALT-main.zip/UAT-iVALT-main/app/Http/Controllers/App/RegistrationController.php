<?php

namespace App\Http\Controllers\App;

use App\Http\Controllers\ApiResponseController;
use App\Models\RegisterOtp;
use App\Models\User;
use App\Models\UserDeviceTokens;
use App\Services\EmailService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use PHPMailer\PHPMailer\Exception;

class RegistrationController extends ApiResponseController
{
    private EmailService $emailService;

    /**
     * Constructor for the RegistrationController class.
     *
     * @param EmailService $emailService
     */
    public function __construct(EmailService $emailService)
    {
        $this->emailService = $emailService;
    }

    /**
     * @param Request $request
     *
     * @throws Exception
     * @return JsonResponse
     */
    public function confirmRegistration(Request $request): JsonResponse
    {
        $requiredParams = ['mobile', 'user_code', 'country_code'];
        if (! $this->validateRequiredParams($request, $requiredParams)) {
            $message = $this->requiredFieldValidation($request, $requiredParams);

            return $this->error(
                $request,
                'Missing Required Parameters',
                $message,
                400
            );
        } else {
            $mobile = $request->mobile;
            $countryCode = $request->country_code;

            if ($request->country_code == '+1' && $request->mobile == '123456789' && $request->user_code == '1234') {
                return $this->registerUser($request, true);
            }

            $isOTPValid = RegisterOtp::where(['mobile' => $countryCode.$mobile, 'otp' => $request->user_code])->count();

            if ($isOTPValid > 0) {
                RegisterOtp::where(['mobile' => $countryCode.$mobile])->delete();

                return $this->registerUser($request, false);
            } else {
                return $this->error(
                    $request,
                    'Invalid OTP',
                    'The OTP provided is not valid.',
                    422
                );
            }
        }
    }

    /**
     * @param Request $request
     * @param bool $isDummyAccount
     * @throws Exception
     * @return JsonResponse
     */
    public function registerUser(Request $request, bool $isDummyAccount = false): JsonResponse
    {
        $requiredParams = ['mobile', 'country_code', 'name', 'platform', 'email', 'imei', 'device_token', 'user_code'];
        if (! $this->validateRequiredParams($request, $requiredParams)) {
            $message = $this->requiredFieldValidation($request, $requiredParams);

            return $this->error(
                $request,
                'Missing Required Parameters',
                $message,
                400
            );
        } else {
            $platform = 'ios';
            if ($request->has('platform') && $request->platform == 'android') {
                $platform = 'android';
            }

            return $this->storeIValtUser($request, $platform, $isDummyAccount);
        }
    }

    /**
     * @param $request
     * @param $platform
     * @param $isDummyAccount
     * @throws Exception
     * @return JsonResponse
     */
    public function storeIValtUser($request, $platform, $isDummyAccount): JsonResponse
    {
        $chainId = null;
        $emailVerificationToken = $this->randomString(36);

        $userModel = new User;

        $userData = $userModel->where(['country_code' => $request->country_code, 'mobile' => $request->mobile])->first();

        if ($userData == null) {
            $insertArray = [
                'country_code'             => $request->country_code,
                'mobile'                   => $request->mobile,
                'name'                     => $request->name,
                'imei'                     => $request->imei,
                'email'                    => $request->email,
                'mobile_with_country_code' => $request->country_code.$request->mobile,
                'device_token'             => $request->device_token,
                'platform'                 => $platform,
                'chain_id'                 => $chainId,
                'temp_email'               => null,
                'is_email_verified'        => $isDummyAccount ? 1 : 0,
                'email_verification_token' => $isDummyAccount ? null : $emailVerificationToken,
                'created_at'               => now(),
                'updated_at'               => now(),
            ];

            if ($request->has(['supplier_id', 'supplier'])) {
                $insertArray['supplier_id'] = $request->supplier_id;
                $insertArray['supplier'] = $request->supplier;
            }
            if (! $isDummyAccount) {
                $this->emailService->sendMobileAppVerificationEmail($request->name, $request->email, $this->hideMobileNumber($request->mobile), $emailVerificationToken);
            }

            $lastInsertId = $userModel->insertGetId($insertArray);

            if ($lastInsertId > 0 && $lastInsertId != null) {
                $userDeviceTokenModel = new UserDeviceTokens;
                $userDeviceTokenModel->create(['user_id' => $lastInsertId, 'device_token' => $request->device_token, 'imei' => $request->imei, 'platform' => $platform]);
            }

            return $this->success(
                $request,
                ['id' => $lastInsertId, 'mobile' => $request->mobile, 'is_account_exist' => 0],
                'User registered successfully.',
                200
            );
        } else {
            $userDeviceTokenModel = new UserDeviceTokens;
            $userDeviceTokenModel->where(['user_id' => $userData->id, 'imei' => $userData->imei])->delete();

            $userDeviceTokenModel->create([
                'user_id'      => $userData->id,
                'device_token' => $request->device_token,
                'imei'         => $request->imei,
                'platform'     => $platform,
            ]);

            $oldEmail = $userData->email;

            $updateArray = [
                'country_code'             => $request->country_code,
                'mobile_with_country_code' => $request->country_code.$request->mobile,
                'name'                     => $request->name,
                'imei'                     => $request->imei,
                'device_token'             => $request->device_token,
                'platform'                 => $platform,
                'is_email_verified'        => $isDummyAccount ? 1 : 0,
                'email_verification_token' => $isDummyAccount ? null : $emailVerificationToken,
            ];

            if ($request->email !== $oldEmail) {
                $updateArray['temp_email'] = $request->email;
            }

            if ($request->has(['supplier_id', 'supplier'])) {
                $updateArray['supplier_id'] = $request->supplier_id;
                $updateArray['supplier'] = $request->supplier;
            }

            $userModel->where(['mobile_with_country_code' => $request->country_code.$request->mobile])->update($updateArray);

            $userData = $userModel->where(['mobile' => $request->mobile])->first();
            if (! $isDummyAccount) {
                $this->emailService->sendMobileAppVerificationEmail($request->name, $oldEmail, $this->hideMobileNumber($request->mobile), $emailVerificationToken);
            }
            if ($request->email !== $oldEmail) {
                return $this->success(
                    $request,
                    ['id' => $userData->id, 'mobile' => $request->mobile, 'old_email' => $oldEmail, 'is_account_exist' => 1],
                    'Welcome back! '.$userData->name.'. Please verify your old email ('.$oldEmail.') to continue using iValt.',
                    200
                );
            } else {
                return $this->success(
                    $request,
                    ['id' => $userData->id, 'mobile' => $request->mobile, 'is_account_exist' => 0],
                    'Welcome! '.$userData->name.'. Please verify your email to continue using iVALT.',
                    200
                );
            }
        }
    }

    /**
     * Generate a random string of a given length.
     *
     * @param int $length
     *
     * @return string
     */
    protected function randomString(int $length): string
    {
        $keys = array_merge(range(0, 9), range('a', 'z'), range('A', 'Z'));

        $key = '';
        for ($i = 0; $i < $length; $i++) {
            $key .= $keys[mt_rand(0, count($keys) - 1)];
        }

        return $key;
    }

    /**
     * Hide part of the mobile number for privacy.
     *
     * @param string $mobileNumber
     *
     * @return string
     */
    protected function hideMobileNumber(string $mobileNumber): string
    {
        return
            substr($mobileNumber, 0, 2).
            str_repeat('*', strlen($mobileNumber) - 6).
            substr($mobileNumber, -4);
    }

    /**
     * @param Request $request
     * @return JsonResponse
     */
    public function checkImei(Request $request): JsonResponse
    {
        $requiredParams = ['imei'];
        if (! $this->validateRequiredParams($request, $requiredParams)) {
            $message = $this->requiredFieldValidation($request, $requiredParams);

            return $this->error(
                $request,
                'Missing Required Parameters',
                $message,
                400
            );
        }
        $imeiExists = User::where('imei', $request->imei)->exists();

        if ($imeiExists) {
            return $this->success($request, ['exists' => $imeiExists], 'IMEI exists.');
        }

        return $this->error($request, 'Not Found', 'IMEI does not exist.', 403);
    }
}
