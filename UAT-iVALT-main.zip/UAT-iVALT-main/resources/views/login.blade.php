<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<style>
    /* body */
body {
  	font-family: 'Poppins', sans-serif;
  display: grid;
  padding: 50px;
  color: #4f546c;
  font-size: 0.9rem;
  background-color: #eef0f4;
}
/* card */
.signUp {
  margin-top: 50px !important;
  width: 500px;
  padding: 28px 36px 28px 30px;
  border-radius: 5px;
  border: solid 1px #efeff1;
  background-color: #ffffff;
  margin: auto;
}
/* form css*/
.signUp h1 {
  color: #2b6d8c;
  margin-top:0px;
}
.signUp p {
  margin-bottom: 25px;
  color: #777777;
  font-size: 12px;
}

.signUp input {
  width: 100%;
  display: block;
  margin: 20px 0;
  padding: 10px 0px;
  border: none;
  outline: none;
  border-bottom: 1px solid #ccc;
}

.signUp .input-control {
  width: 100%;
  position: relative;
}
.signUp .input-control.active label {
  top: 0;
  left: 0;
  transform: translate(0, -50%) scale(0.75);
  color: #008c9e;
}
.signUp .input-control.active:after {
  width: 100%;
}
.signUp .input-control:after {
  content: "";
  display: block;
  width: 0;
  height: 1px;
  background: #008c9e;
  position: absolute;
  bottom: 0;
  transition: 0.15s ease-in-out;
}
.signUp .input-control label {
  color: #ccc;
  font-size: 15px;
  position: absolute;
  top: 50%;
  left: 0;
  transform: translate(0, -50%);
  transition: 0.15s ease-in-out;
  cursor: text;
  transform-origin: center left;
}

.signUp button {
  padding: 16px;
  width: 100%;
  background: #2b6d8c;
  outline: none;
  border: none;
  border-radius: 5px;
  color: white;
  font-weight: bold;
}

</style>
</head>
<div class='signUp'>
    <div align="center">
        
    <img src="https://ivalt.com/images/logo.png" width="200px" >
    </div>
  <h2>Login</h2>
@if(isset($error))
  <p style="color:red">{{ $error }}</p>
@endif
  <form action="{{ route('blackchain.users.login')  }}" method="post">
    <!-- email address -->
    <div class='input-control'>
      <label for='emailaddress'>Email Address</label>
      <input type='email' name="email" required/>
    </div>
    <!-- /email address -->

    <!-- password -->
    <div class='input-control'>
      <label for='password'>Password</label>
      <input type='password' name="password" required/>
    </div>
    <!-- /password -->

    <!-- button -->
    <button type="submit">LOGIN</button>
    <!-- /button -->

  </form>
</div>
<script>
    $(".input-control")
  .find("input")
  .on("focus", function () {
    $(this).parent(".input-control").addClass("active");
  });
$(".input-control")
  .find("input")
  .on("blur", function () {
    if ($(this).val().length == 0) {
      $(this).parent(".input-control").removeClass("active");
    }
  });

</script>