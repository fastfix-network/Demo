<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
    <title>Document</title>
</head>
<body onload="document.frm1.submit()">
    <form method="GET" action="{{ $authToken->success_url }}" name="frm1">
        <input type="hidden" name="mobile" value="{{ $mobile }}"/>
        <input type="hidden" name="auth_status" value="true" />
        <input type="hidden" name="message" value="User authenticate successfully!" />
    </form>
</body>
</html>
