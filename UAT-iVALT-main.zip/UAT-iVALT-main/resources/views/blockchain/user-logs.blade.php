@extends('blockchain.layout.main')
@section('content')
    <div class="container-fluid">
        <h3 class="mt-4">iValt Users Logs</h3>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
            <li class="breadcrumb-item">Blockchain Users</li>
        </ol>
        <div class="row mt-2">
            <div class="col-md-12">
                <table class="table table-sm table-striped table-bordered myTable" style="width:100%" id="customers">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Details</th>
                            <th>Created At</th>
                        </tr>

                    </thead>
                    <tbody>
                        @forelse ($logs as $key => $log)
                        <tr>
                            <td>{{ ++$key }}</td>
                            <td>{{ $log->detail }}</td>
                            <td>{{ $log->created_at }}</td>
                        </tr>
                        @empty
                            <tr align="center">
                                <td colspan="3">No Logs Available</td>
                            </tr>
                        @endforelse 
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection
