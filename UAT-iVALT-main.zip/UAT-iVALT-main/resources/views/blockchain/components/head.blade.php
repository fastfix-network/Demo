<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
<meta name="description" content="" />
<meta name="author" content="" />
<title>Dashboard::Admin</title>
<link href="https://baldevkrishan.com/ivalt_v1/public/css/styles.css" rel="stylesheet" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet"
    crossorigin="anonymous" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">

{{-- <link href="https://cdn.datatables.net/1.10.23/css/jquery.dataTables.min.css">
<link href="https://cdn.datatables.net/buttons/1.6.5/css/buttons.dataTables.min.css">


<link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
<link href="https://cdn.datatables.net/1.10.23/css/dataTables.bootstrap4.min.css">
<link href="https://cdn.datatables.net/fixedheader/3.1.8/css/fixedHeader.bootstrap4.min.css"> --}}

<style>
    label {
        font-size: 20px;
        font-weight: 700;
        margin-left: 33px;
    }

    label:hover {
        cursor: pointer;
    }

    @keyframes blink {
        50% {
            opacity: 0.0;
        }
    }

    @-webkit-keyframes blink {
        50% {
            opacity: 0.0;
        }
    }

    .blink {
        animation: blink 1s step-start 0s infinite;
        -webkit-animation: blink 1s step-start 0s infinite;
    }

    /* .table-bordered thead th, .table-bordered thead td {
        border-bottom-width: 2px;
    }
    .table thead th {
        vertical-align: bottom;
        border-bottom: 2px solid #dee2e6;
    }
    .table-bordered th, .table-bordered td {
        border: 1px solid #dee2e6;
    }
    .table th, .table td {
        padding: 0.40rem !important;
        vertical-align: top;
        border-top: 1px solid #dee2e6;
    } */

    button:not(:disabled),
    [type=button]:not(:disabled),
    [type=reset]:not(:disabled),
    [type=submit]:not(:disabled) {
        cursor: pointer;
        padding: 0.25rem 0.5rem;
        font-size: 0.875rem;
        line-height: 1.5;
        border-radius: 0.2rem;
    }
    #clock {
        display: -ms-flexbox;
        display: flex;
        -ms-flex-wrap: wrap;
        flex-wrap: wrap;
        justify-content: center;
        width: 100%;
        margin-left: 0px !important;
    }

    .group {
        font-size: 45px !important;
        font-weight: bolder !important;
        color: white !important;
    }

    .groupA {
        background-color: red !important;
    }

    .groupB {
        background-color: dodgerblue !important;
    }

    .groupC {
        background-color: rgb(24, 141, 0) !important;
    }

    @media (min-width: 576px) {
        .modal-dialog {
            max-width: 880px !important;
            margin: 1.75rem auto !important;
        }
    }

    .modal-backdrop {
        background-color: transparent !important;
    }

</style>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');


        #customers {
            font-family: Arial, Helvetica, sans-serif;
            border-collapse: collapse;
            width: 100%;
        }

        #customers td,
        #customers th {
            border: 1px solid #ddd;
        }

        #customers tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        #customers tr:hover {
            background-color: #ddd;
        }

        #customers th {

            text-align: left;
            background-color: #2b6d8c;
            color: white;
        }

        .btn {
            background-color: #4CAF50;
            border: none;
            color: white;
            padding: 8px 21px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 14px;
            margin: 4px 2px;
            cursor: pointer;
        }

        .btn-blue {
            background-color: #008CBA;
        }

        /* Blue */
        .btn-red {
            background-color: #f44336;
        }

        /* Red */
        .btn-grey {
            background-color: #e7e7e7;
            color: black;
        }

        /* Gray */
        .btn-black {
            background-color: #555555;
        }

        /* Black */

    </style>