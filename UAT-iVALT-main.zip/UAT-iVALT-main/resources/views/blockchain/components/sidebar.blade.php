<nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
    <div class="sb-sidenav-menu">
        <div class="nav">
            <div class="sb-sidenav-menu-heading">ivalt Api Users</div>
            {{--  <a class="nav-link" href="#">
                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                Dashboard
            </a>  --}}


            <a class="nav-link " href="{{ route('all.users') }}">
                <div class="sb-nav-link-icon"><i class="fas fa-file"></i></div>
                All User
            </a>
            <a class="nav-link" href="{{ route('blackchain.users') }}">
                <div class="sb-nav-link-icon"><i class="fas fa-file"></i></div>
                Blockchain Users
            </a>
        </div>
    </div>
    <div class="sb-sidenav-footer">
        <div class="small">Logged in as:</div>
        Admin
    </div>
</nav>
