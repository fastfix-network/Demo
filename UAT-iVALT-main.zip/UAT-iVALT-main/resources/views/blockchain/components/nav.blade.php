<nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
    <a class="navbar-brand" href="">
    {{-- <img src="{{ asset('images/lottery-logo.png') }}" alt="" width="50"> --}}
        iValt
    </a>
    <button class="btn btn-link btn-sm order-1 order-lg-0" id="sidebarToggle" href="#"><i class="fas fa-bars"></i></button>
    <!-- Navbar Search-->
    <form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">
        <div class="input-group">
        </div>
    </form>
    <!-- Navbar-->
    <ul class="navbar-nav ml-auto ml-md-0">
        <a href="{{ route('logout') }}" onclick="return confirm('Are you sure to logout ?')" class="btn btn-danger">Logout</a>
    </ul>
</nav>
