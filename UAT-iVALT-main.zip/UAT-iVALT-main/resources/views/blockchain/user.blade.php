@extends('blockchain.layout.main')
@section('content')
    <div class="container-fluid">
        <h3 class="mt-4">Blockchain User Details</h3>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
            <li class="breadcrumb-item">Blockchain User Details</li>
        </ol>
        <div class="row mt-2">
            <div class="col-md-12">
                <table class="table table-sm table-striped table-bordered myTable" style="width:100%" id="customers">
                    @foreach ($user as $key => $value)
                        <tr>
                            <th><?= $key ?></th>
                            <td><?php print_r($value); ?></td>
                        </tr>
                    @endforeach
                </table>
            </div>
        </div>
    </div>
@endsection
