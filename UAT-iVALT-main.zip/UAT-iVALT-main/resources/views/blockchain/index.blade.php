@extends('blockchain.layout.main')
@section('content')
    <div class="container-fluid">
        <h3 class="mt-4">Blockchain Users</h3>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
            <li class="breadcrumb-item">Blockchain Users</li>
        </ol>
        <div class="row mt-2">
            <div class="col-md-12">
                <table class="table table-sm table-striped table-bordered myTable" style="width:100%" id="customers">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Mobile</th>
                            <th>Device platform</th>
                            <th>Blockchain Id</th>
                            <th>Action</th>
                        </tr>

                    </thead>
                    <tbody>
                        @foreach ($users as $key => $user)
                            <tr>
                                <td>{{ ++$key }}</td>
                                <td>{{ $user->name }}</td>
                                <td>{{ $user->email }}</td>
                                <td>{{ $user->mobile }}</td>
                                <td>{{ $user->platform }}</td>
                                <td>{{ $user->chain_id }}</td>
                                <td>
                                    <form action="{{ route('blackchain.users.find') }}" method="POST">
                                        <input type="hidden" name="id" value="{{ $user->chain_id }}" />
                                        <button type="submit" class="btn btn-info">View</button>
                                    </form>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection
