@extends('blockchain.layout.main')
@section('content')
    <div class="container-fluid">
        <h3 class="mt-4">iValt Users</h3>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
            <li class="breadcrumb-item">Blockchain Users</li>
        </ol>
        <div class="row mt-2">
            <div class="col-md-12">
                <table class="table table-sm table-striped table-bordered myTable" style="width:100%" id="customers">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Mobile</th>
                            <th>Device platform</th>
                            <th width="100px">Action</th>
                        </tr>

                    </thead>
                    <tbody>
                        @forelse ($users as $key => $user)
                            <tr>
                                <td>{{ ++$key }}</td>
                                <td>{{ $user->name }}</td>
                                <td>{{ $user->email }}</td>
                                <td>{{ $user->mobile }}</td>
                                <td>{{ $user->platform }}</td>
                                <td>
                                    <form action="{{ route('user.logs') }}" method="POST">
                                        <input type="hidden" name="mobile" value="{{ $user->mobile }}" />
                                        <button type="submit" class="btn btn-info">View Logs</button>
                                    </form>
                                </td>
                            </tr>
                        @empty
                            <tr align="center">
                                <td colspan="6">
                                    Record not Available
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection
