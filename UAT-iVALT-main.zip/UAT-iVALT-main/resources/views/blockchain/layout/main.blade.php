<!DOCTYPE html>
<html lang="en">
<head>
    @include('blockchain.components.head')
</head>
<body class="sb-nav-fixed">
@include('blockchain.components.nav')
<div id="layoutSidenav">
    <div id="layoutSidenav_nav">
        @include('blockchain.components.sidebar')
    </div>
    <div id="layoutSidenav_content">
        <main>
            @yield('content')
        </main>
        <footer class="py-4 bg-light mt-auto">
            <div class="container-fluid">
                <div class="d-flex align-items-center justify-content-between small">
                    <div class="text-muted">Copyright &copy; ivalt.com</div>
                    <div>
                        <a href="#">Privacy Policy</a>
                        &middot;
                        <a href="#">Terms &amp; Conditions</a>
                    </div>
                </div>
            </div>
        </footer>
    </div>
</div>
@include('blockchain.components.scripts')
</body>
</html>
