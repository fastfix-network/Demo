<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
          integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous"/>
    <style type="text/css">
        @import url("https://fonts.googleapis.com/css2?family=Ubuntu:wght@400;500;700&display=swap");

        .my-10 {
            margin-top: 1rem;
            margin-bottom: 1rem;
        }

        .bg-newgr {
            background: #292e2f9c;
        }

        .img-small {
            width: 60%;
        }

        p, h2, h3, h4 {
            font-family: "Ubuntu", sans-serif;
        }

        .arrow-wh::after {
            content: "";
            width: 200px;
            height: 300px;
            position: absolute;
            top: 8.8rem;
            right: 4rem;
            z-index: -1;
            transform: rotate(0deg);
            background: url(images/enter-arrow.png) no-repeat;
            background-size: 23%;
            opacity: 0.4;
        }

        .arrow-wh-new::after {
            content: "";
            width: 200px;
            height: 300px;
            position: absolute;
            top: -1.5rem;
            right: 26rem;
            transform: rotate(90deg);
            background-size: 23%;
            opacity: 0.4;
        }

        .font-size-lg {
            font-size: 22px;
        }

        .hover-data {
            position: relative;
        }

        .hover-data-show {
            display: none;
            transition: height 2s;
            cursor: pointer;
        }

        .hover-data:hover .hover-data-show {
            display: block;
        }

        .radius-1 {
            border-radius: 10px;
            border: 1px solid #000;
            width: 210px;
        }
    </style>

    <title>Authenticator Demo</title>

</head>

<body class="bg-main bg-light">
<div class="container">
    <div class="row my-3">
        <div class="col-md-3"></div>
    </div>
</div>
<div class="container mt-2 mb-5 p-4 rounded bg-light">
    <div class="row mb-4 mt-0 text-light ">
        <div class="col-md-12">
            <h3 class="text-center" style="font-size: xx-large;">Identify Anyone, From Anywhere for Any Application</h3>
        </div>
    </div>

    <div class="row my-4">
        <div class="col-md-3 col-xs-12 "></div>
        <div class="col-md-5 ml-3 col-sm-12 text-center bg-white py-4 position-relative shadow-lg"
             style="border-radius: 10px;">
            <div class="text-center py-4">
                <img src="https://ivalt.com/images/logo.png" alt="ivalt logo"
                     srcset="https://ivalt.com/images/logo.png">
            </div>
            <h3 class="text-center text-primary py-2">Biometric ID Verification</h3>
            <div class="row">
                <div class="col">
                    <div class="form-group">
                        <input type="text" class="form-control" placeholder="Enter User's Mobile Number" maxlength="11"
                               name="mobile"/>
                        <span class="help-block text-danger error-details" style="display: none">
              </span>
                    </div>
                </div>
            </div>

            <div class="form-group text-center">
                <input type="submit" name="scan" value="Send Request" class="btn btn-dark btn-block"/>
            </div>

        </div>

        <div class="col-md-3 col-xs-12"></div>

    </div>

    <div class="row my-5">

        <div class="col-md-3 col-xs-12"></div>

        <div class="col-md-5 ml-3 col-sm-12 text-center">
        </div>
        <div class="col-md-3 ">
        </div>
    </div>
</div>

<div class="container my-4">
    <div class="row">
        <div class="col-md-3 col-xs-12"></div>
        <div class="col-md-5 col-xs-12 text-center">
        </div>
        <div class="col-md-3 col-xs-12"></div>
    </div>
</div>
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
     aria-hidden="true">

    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Please wait...</h5>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-12 text-center">
                        <img src="images/loader.gif" style="width: 80px"/>
                        <h4 class="status-text">Sending notification....</h4>
                        <p>
                            On your phone registered with ON DEMAND ID, please look for
                            authentication request and follow the steps. Once
                            authenticated, you will have access to the site.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</footer>

<script src="https://code.jquery.com/jquery-3.5.1.min.js" type="text/javascript"></script>

<!-- Optional JavaScript -->

<!-- jQuery first, then Popper.js, then Bootstrap JS -->

<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"
        integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN"
        crossorigin="anonymous"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"
        integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV"
        crossorigin="anonymous"></script>


<script>
    $(function () {

        window.ivaltNotificationErrorStatus = false;

        window.webCardNotificationErrorStatus = false;

        //      window.api = "https://baldevkrishan.com/ivalt_v1/public/";
        // window.api = "https://ivalt.com/services/ivalt_backend/public/";
        window.api = "{{ url('/') }}/";
        $("input[name=scan]").click(function () {
            if ($("input[name=mobile]").val().trim() === "") {
                alert("Please fill all the fields");
                return false;
            }
            $("#exampleModal").modal({
                keyboard: false,
                backdrop: "static",
            });


            $("input").prop("disabled", true);
            $(this).val("Please wait...");
            let elem = $(this);

            $(".loader-row").show();
            $(".status-text").html("Sending notification...");
            $(".error-details").html("").hide();


            //Send notification to iValt
            $.ajax({
                type: "POST",
                url: window.api + "send/global/notification",
                data: {
                    mobile: $("input[name=mobile]").val()
                },
                success: function (result) {
                    window.ivaltNotificationErrorStatus = false;
                    $(".status-text").html("Waiting for authentication..");
                    validateAuth();
                },
                error: function (result) {
                    window.ivaltNotificationErrorStatus = true;
                    displayError(result.responseJSON.message, elem);
                },
            });

            //Send notification to Webcard
            $.ajax({
                type: "POST",
                url: window.api + "webcard/send/global/notification",
                data: {
                    mobile: $("input[name=mobile]").val()
                },
                success: function (result) {
                    window.webCardNotificationErrorStatus = false;
                    $(".status-text").html("Waiting for authentication..");
                    validateAuth();
                },
                error: function (result) {
                    window.webCardNotificationErrorStatus = true;
                    displayError(result.responseJSON.message, elem);
                },
            });
        });
    });

    function displayError(errorMessage, element) {
        if (window.ivaltNotificationErrorStatus && window.webCardNotificationErrorStatus) {
            setTimeout(() => {
                $("#exampleModal").modal("hide");
                $(".error-details").html(errorMessage).show();
                element.val("Send Notification");
                $("input").prop("disabled", false);
            }, 2000);
        }
    }


    function validateAuth() {

        $.ajax({
            type: "POST",
            url: window.api + "validate/global/auth",
            data: {
                mobile: $("input[name=mobile]").val()
            },
            success: function (result) {
                console.log(result)
                if (result.status == "error") {
                    setTimeout(function () {
                        validateAuth('validate/global/auth');
                    }, 1000);
                } else if (result.status == "failed") {
                    $(".status-text").html("Authenticate Failed, Please try again!");
                    $("input").prop("disabled", false);
                    $("input[name=scan]").val("Send Notification");
                    $(".loader-row").hide();
                } else {
                    $(".status-text").html(
                        "Authenticate Successfully, redirecting..."
                    );
                    localStorage.removeItem("userDetails");
                    localStorage.setItem("auth_status", true);
                    localStorage.setItem("userDetails", JSON.stringify(result));
                    setTimeout(function () {
                        window.location.href = "success.php";
                    }, 3000);
                }
            },
        });
    }
</script>
</body>
</html>
